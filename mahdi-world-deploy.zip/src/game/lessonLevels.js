// Level layouts for the book-lesson stages. Design pixels (1920x1080 view). Ground is y=900.
// Every gap is bridged by floating platforms reachable with a normal jump; every wall can also be passed with the ninja double jump.
const G = 900;
const gap = [
  { x: 1430, y: 830, w: 120, h: 26, kind: 'plat' },
  { x: 1580, y: 770, w: 120, h: 26, kind: 'plat' },
];

export const LEVELS = {
  // 1 — الحديقة: فجوة بمنصات + منصات استكشاف
  garden: {
    width: 5600,
    solids: [
      { x: 0, y: G, w: 1400, h: 200, kind: 'ground' }, ...gap,
      { x: 1720, y: G, w: 3880, h: 200, kind: 'ground' },
      { x: 2400, y: 770, w: 150, h: 26, kind: 'plat' }, { x: 3300, y: 740, w: 170, h: 26, kind: 'plat' },
      { x: 4300, y: 770, w: 150, h: 26, kind: 'plat' }, { x: 4520, y: 650, w: 150, h: 26, kind: 'plat' },
    ],
    crates: [], climb: [],
    checkpoints: [{ x: 1790, y: G }, { x: 3000, y: G }, { x: 4200, y: G }],
    start: { x: 140, y: G },
    sparks: [{ id: 'sp1', x: 1635, y: 690 }, { id: 'sp2', x: 2475, y: 690 }, { id: 'sp3', x: 3385, y: 660 }, { id: 'sp4', x: 4375, y: 690 }, { id: 'sp5', x: 4595, y: 570 }],
    stations: [2000, 3500, 4800], door: 5350,
    hints: [{ x: 500, text: 'امشِ بالأسهم · اقفز بزر المسافة' }, { x: 1250, text: 'اقفز فوق المنصات' }],
  },
  // 2 — المفترق: صندوق وجدار (لغز حركة) ثم فجوة
  crossroads: {
    width: 5600,
    solids: [
      { x: 0, y: G, w: 2900, h: 200, kind: 'ground' },
      { x: 1200, y: 650, w: 70, h: 250, kind: 'wall' },
      { x: 2930, y: 830, w: 120, h: 26, kind: 'plat' }, { x: 3080, y: 770, w: 120, h: 26, kind: 'plat' },
      { x: 3220, y: G, w: 2380, h: 200, kind: 'ground' },
      { x: 2300, y: 770, w: 150, h: 26, kind: 'plat' }, { x: 4300, y: 770, w: 150, h: 26, kind: 'plat' }, { x: 4520, y: 650, w: 150, h: 26, kind: 'plat' },
    ],
    crates: [{ x: 640, y: G - 130, w: 130, h: 130 }], climb: [],
    checkpoints: [{ x: 1500, y: G }, { x: 3300, y: G }, { x: 4200, y: G }],
    start: { x: 140, y: G },
    sparks: [{ id: 'sp1', x: 1235, y: 575 }, { id: 'sp2', x: 2375, y: 690 }, { id: 'sp3', x: 3005, y: 750 }, { id: 'sp4', x: 4375, y: 690 }, { id: 'sp5', x: 4595, y: 570 }],
    stations: [2000, 3800, 4800], door: 5350,
    hints: [{ x: 640, text: 'ادفع الصندوق نحو الجدار ثم اقفز عليه' }],
  },
  // 3 — البرج: تسلق رف السلم إلى شرفة + فجوة
  tower: {
    width: 5600,
    solids: [
      { x: 0, y: G, w: 2500, h: 200, kind: 'ground' },
      { x: 1640, y: 560, w: 330, h: 30, kind: 'plat' },
      { x: 2530, y: 830, w: 120, h: 26, kind: 'plat' }, { x: 2680, y: 770, w: 120, h: 26, kind: 'plat' },
      { x: 2820, y: G, w: 2780, h: 200, kind: 'ground' },
      { x: 3300, y: 740, w: 170, h: 26, kind: 'plat' }, { x: 4300, y: 770, w: 150, h: 26, kind: 'plat' }, { x: 4520, y: 650, w: 150, h: 26, kind: 'plat' },
    ],
    crates: [], climb: [{ x: 1500, y: 540, w: 110, h: 360, exitDir: 1 }],
    checkpoints: [{ x: 1100, y: G }, { x: 2800, y: G }, { x: 4200, y: G }],
    start: { x: 140, y: G },
    sparks: [{ id: 'sp1', x: 1720, y: 490 }, { id: 'sp2', x: 1900, y: 490 }, { id: 'sp3', x: 3385, y: 660 }, { id: 'sp4', x: 4375, y: 690 }, { id: 'sp5', x: 4595, y: 570 }],
    stations: [2200, 3700, 4800], door: 5350,
    hints: [{ x: 1380, text: 'اضغط قفز عند رف الكتب لتتسلق' }],
  },
  // 4 — التل: درج حجري صاعد ثم نازل
  hill: {
    width: 5600,
    solids: [
      { x: 0, y: G, w: 5600, h: 200, kind: 'ground' },
      { x: 2100, y: 820, w: 260, h: 80, kind: 'step' }, { x: 2360, y: 740, w: 260, h: 160, kind: 'step' },
      { x: 2620, y: 660, w: 360, h: 240, kind: 'step' },
      { x: 2980, y: 740, w: 260, h: 160, kind: 'step' }, { x: 3240, y: 820, w: 260, h: 80, kind: 'step' },
      { x: 4300, y: 770, w: 150, h: 26, kind: 'plat' }, { x: 4520, y: 650, w: 150, h: 26, kind: 'plat' },
    ],
    crates: [], climb: [],
    checkpoints: [{ x: 1700, y: G }, { x: 3600, y: G }, { x: 4200, y: G }],
    start: { x: 140, y: G },
    sparks: [{ id: 'sp1', x: 2230, y: 750 }, { id: 'sp2', x: 2490, y: 670 }, { id: 'sp3', x: 2800, y: 590 }, { id: 'sp4', x: 4375, y: 690 }, { id: 'sp5', x: 4595, y: 570 }],
    stations: [1500, 3900, 4800], door: 5350,
    hints: [{ x: 1950, text: 'اصعد الدرج الحجري' }],
  },
};
