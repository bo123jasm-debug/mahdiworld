import { GRAVITY } from './world.js';
import { clamp } from '../engine/util.js';

const TARGET_H = 190; // on-screen height of the standing character, in design pixels

// animation tables: f = frame-set name, i = fixed frame indices, fps = playback speed
const ANIMS = {
  normal: {
    idle:  { f: 'n_idle', i: [3] },
    walk:  { f: 'n_walk', fps: 11 },
    run:   { f: 'n_run', fps: 12 },
    rise:  { f: 'n_jump', i: [1] },
    apex:  { f: 'n_jump', i: [2] },
    fall:  { f: 'n_jump', i: [3] },
    climb: { f: 'n_climb', fps: 6 },
    push:  { f: 'n_interact', i: [0, 1], fps: 4 },
    read:  { f: 'n_interact', i: [3] },
    slide: { f: 'n_jump', i: [5] },
  },
  ninja: {
    idle:  { f: 's_idle', i: [0] },
    walk:  { f: 's_run', fps: 9 },
    run:   { f: 's_run', fps: 13 },
    rise:  { f: 's_jump', i: [0] },
    apex:  { f: 's_jump', i: [1] },
    fall:  { f: 's_jump', i: [3] },
    climb: { f: 's_jump', i: [0, 1, 2, 1], fps: 8 },
    push:  { f: 's_run', fps: 5 },
    read:  { f: 's_idle', i: [0] },
    slide: { f: 's_slide', i: [0, 1, 2], fps: 10 },
  },
};

export class Player {
  constructor(assets, audio) {
    this.frames = assets.frames;
    this.audio = audio;
    this.w = 58; this.h = 168;
    this.mode = 'normal';
    this.locked = false;
    this.pose = null;
    this.doubleJumpUnlocked = false;
    this.speedMul = 1; this.jumpMul = 1; this.alpha = 1; this.fx = null; this.canSlide = true;
    this.scale = {
      normal: TARGET_H / (this.frames.n_walk[0].naturalHeight || 150),
      ninja: TARGET_H / (this.frames.s_idle[0].naturalHeight || 150),
    };
    this.respawn(0, 0);
  }

  respawn(x, y) {
    this.x = x; this.y = y; this.vx = 0; this.vy = 0;
    this.facing = 1; this.onGround = false;
    this.climbing = false; this.climbCd = 0; this.slideT = 0;
    this.coyote = 0; this.jumpBuf = 0; this.landT = 0; this.djAvail = false;
    this.pushing = false; this.autoT = 0; this.anim = 'idle'; this.animT = 0; this.lastStep = -1;
  }

  setMode(m) { this.mode = m; }
  /** One-shot action animation (sword/throw/hurt/defend) played from the ninja frame sets. */
  playFx(name, dur) { this.fx = { name, dur, t: 0 }; }
  rect() { return { x: this.x - this.w / 2, y: this.y - this.h, w: this.w, h: this.h }; }

  update(dt, input, world) {
    const ninja = this.mode === 'ninja';
    const locked = this.locked;
    const L = !locked && input.held('left');
    const R = !locked && input.held('right');
    this.autoT = Math.max(0, (this.autoT || 0) - dt);
    const dir = this.autoT > 0 ? this.autoDir : (R ? 1 : 0) - (L ? 1 : 0);
    const upHeld = !locked && (input.held('up') || input.held('jump'));
    const downHeld = !locked && input.held('down');
    this.climbCd = Math.max(0, this.climbCd - dt);
    this.landT = Math.max(0, this.landT - dt);

    const r = this.rect();
    const zone = world.climbZoneAt(r);

    // ---- climbing ----
    if (!this.climbing && zone && !locked && this.climbCd === 0 && upHeld && this.slideT <= 0) {
      this.climbing = true; this.vx = 0; this.vy = 0;
      this.x = clamp(this.x, zone.x + this.w / 2, zone.x + zone.w - this.w / 2);
      this.jumpBuf = 0;
    }
    if (this.climbing) {
      if (!zone) { this.climbing = false; }
      else {
        this.vy = upHeld ? -300 : downHeld ? 300 : 0;
        this.vx = dir * 90;
        if (dir) this.facing = dir;
        const rr = this.rect();
        r.x = rr.x; r.y = rr.y;
        world.moveX(this, r, this.vx * dt);
        const hit = world.moveY(this, r, this.vy * dt);
        this.x = r.x + r.w / 2; this.y = r.y + r.h;
        if (hit === 'ground' && downHeld) { this.climbing = false; this.onGround = true; }
        if (this.y < zone.y + 40 && upHeld) { // reached the top: hop onto the ledge
          this.climbing = false; this.climbCd = 0.6;
          this.vy = -640; this.vx = (zone.exitDir || 1) * 230; this.facing = zone.exitDir || 1;
          this.autoT = 0.5; this.autoDir = zone.exitDir || 1; // carry forward onto the ledge
        }
        if (!zone || (!upHeld && !downHeld && dir && !world.climbZoneAt(this.rect()))) this.climbing = false;
        this.animate(dt);
        return;
      }
    }

    // ---- horizontal ----
    if (this.slideT > 0) {
      this.slideT -= dt;
      this.vx = this.facing * (560 + 320 * (this.slideT / 0.45));
    } else {
      const max = (ninja ? 520 : 400) * (this.pushing ? 0.55 : 1) * this.speedMul;
      const accel = this.onGround ? 3400 : 2300;
      const target = dir * max;
      if (this.vx < target) this.vx = Math.min(target, this.vx + accel * dt);
      else if (this.vx > target) this.vx = Math.max(target, this.vx - accel * dt);
      if (dir) this.facing = dir;
      if (ninja && this.canSlide && this.onGround && !locked && input.pressed('down') && Math.abs(this.vx) > 150) {
        this.slideT = 0.45; this.audio.play('slide');
      }
    }

    // ---- jump ----
    if (!locked && (input.pressed('jump') || input.pressed('up'))) this.jumpBuf = 0.12;
    this.jumpBuf = Math.max(0, this.jumpBuf - dt);
    this.coyote = this.onGround ? 0.1 : Math.max(0, this.coyote - dt);
    const J = (ninja ? 1130 : 1050) * this.jumpMul;
    if (this.jumpBuf > 0 && this.coyote > 0) {
      this.vy = -J; this.coyote = 0; this.jumpBuf = 0; this.onGround = false;
      this.djAvail = this.doubleJumpUnlocked; this.audio.play('jump');
    } else if (this.jumpBuf > 0 && !this.onGround && this.djAvail) {
      this.vy = -J * 0.9; this.djAvail = false; this.jumpBuf = 0; this.audio.play('jump');
    }
    if (!upHeld && this.vy < -J * 0.82) this.vy = -J * 0.82; // a quick tap still gives a useful hop

    // ---- integrate ----
    this.vy = Math.min(this.vy + GRAVITY * dt, 1700);
    const rr = this.rect(); r.x = rr.x; r.y = rr.y;
    this.pushing = world.moveX(this, r, this.vx * dt);
    const wasAir = !this.onGround;
    const hit = world.moveY(this, r, this.vy * dt);
    this.onGround = hit === 'ground';
    if (this.onGround && wasAir) { this.landT = 0.12; this.audio.play('land'); this.djAvail = false; }
    this.x = clamp(r.x + r.w / 2, this.w / 2, world.width - this.w / 2);
    this.y = r.y + r.h;
    this.animate(dt);
  }

  animate(dt) {
    const ninja = this.mode === 'ninja';
    if (this.fx) { this.fx.t += dt; if (this.fx.t >= this.fx.dur) this.fx = null; }
    let name;
    if (this.locked && this.pose) name = this.pose;
    else if (this.climbing) name = 'climb';
    else if (this.slideT > 0) name = 'slide';
    else if (!this.onGround) name = this.vy < -120 ? 'rise' : this.vy > 160 ? 'fall' : 'apex';
    else if (this.pushing && Math.abs(this.vx) > 10) name = 'push';
    else if (Math.abs(this.vx) > 20) name = Math.abs(this.vx) > (ninja ? 450 : 330) ? 'run' : 'walk';
    else name = 'idle';
    if (name !== this.anim) { this.anim = name; this.animT = 0; }
    this.animT += dt * (name === 'walk' || name === 'run' ? clamp(Math.abs(this.vx) / (ninja ? 420 : 340), 0.6, 1.3) : 1);
    // footstep sound on foot-down frames
    if (this.onGround && (name === 'walk' || name === 'run')) {
      const a = ANIMS[this.mode][name];
      const idx = Math.floor(this.animT * a.fps) % this.frames[a.f].length;
      if (idx !== this.lastStep && idx % 2 === 0) this.audio.play('step');
      this.lastStep = idx;
    }
  }

  currentImage() {
    if (this.fx) {
      const map = { sword: 's_sword', throw: 's_throw', hurt: 's_hurt', defend: 's_defend' };
      const set = this.frames[map[this.fx.name]];
      if (set) return set[Math.min(set.length - 1, Math.floor((this.fx.t / this.fx.dur) * set.length))];
    }
    const a = ANIMS[this.mode][this.anim] || ANIMS[this.mode].idle;
    const set = this.frames[a.f];
    let idx;
    if (a.i && !a.fps) idx = a.i[0];
    else if (a.i) idx = a.i[Math.floor(this.animT * a.fps) % a.i.length];
    else idx = Math.floor(this.animT * a.fps) % set.length;
    return set[idx] || set[0];
  }

  draw(ctx, camX, camY = 0) {
    const img = this.currentImage();
    if (!img || !img.naturalWidth) return;
    const s = this.scale[this.mode];
    const w = img.naturalWidth * s, h = img.naturalHeight * s;
    const sx = this.x - camX, sy = this.y - camY;
    // soft shadow
    ctx.save();
    ctx.globalAlpha = this.onGround ? 0.35 : 0.18;
    ctx.fillStyle = '#000';
    ctx.beginPath(); ctx.ellipse(sx, sy + 2, 50, 10, 0, 0, Math.PI * 2); ctx.fill();
    ctx.restore();
    ctx.save();
    ctx.globalAlpha = this.alpha;
    ctx.translate(sx, sy);
    const squash = this.landT > 0 ? 1 - this.landT * 1.2 : 1;
    ctx.scale(this.facing, squash);
    ctx.drawImage(img, -w / 2, -h, w, h);
    ctx.restore();
  }
}
