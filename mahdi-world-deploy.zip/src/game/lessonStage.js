import { World } from './world.js';
import { Player } from './player.js';
import { LEVELS } from './lessonLevels.js';
import { getTheme, drawThemePortrait, drawThemeSolid } from './themes.js';
import * as R from './render.js';
import { clamp, lerp, sleep, el } from '../engine/util.js';
import { runMemory } from '../puzzles/memory.js';
import { runClassify } from '../puzzles/classify.js';
import { runReview } from '../puzzles/review.js';
import { runHidden } from '../puzzles/hidden.js';
import { runMatch } from '../puzzles/match.js';
import { runOrder } from '../puzzles/order.js';
import { runChoose } from '../puzzles/choose.js';

const W = 1080, H = 1920, GROUND_Y = 900, Z = 1.7, WV = W / Z, HV = H / Z;
const ICON = { hidden: '🔍', match: '🧩', order: '🔢', choose: '🪧', classify: '🗂️', memory: '🧠' };
export const BADGE_NAMES = {
  focus: 'شارة التركيز', persist: 'شارة المثابرة', thinker: 'شارة التفكير', explorer: 'شارة المستكشف',
  seeker: 'شارة الباحث عن المعرفة',
};

/**
 * One book lesson as a side-scrolling adventure. Everything (story, 3 challenge stations, quiz) comes from data/book.json.
 * Flow: story intro → explore level → 3 stations (each gives a knowledge key) → door (needs 3 keys) → outro → final quiz → result.
 */
export class LessonStage {
  constructor(game) {
    this.g = game;
    this.player = new Player(game.assets, game.audio);
    this.particles = new R.Particles();
    this.t = 0; this.camX = 0; this.camY = 0; this.cool = 0; this.poof = 0;
    this.scene = 'none'; this.cine = null;
    this.state = this.fresh();
  }

  fresh() { return { keys: new Set(), sparks: new Set(), done: new Set(), checkpoint: null, doorOpen: 0, doorOpening: false, finished: false, retried: false }; }

  async begin({ lessonId }) {
    const g = this.g;
    const lesson = g.bookLessons[lessonId];
    this.lesson = lesson; this.adv = lesson.adventure;
    this.level = LEVELS[this.adv.level];
    this.theme = getTheme(this.adv.theme);
    this.state = this.fresh();
    this.world = new World(this.level);
    this.player.respawn(this.level.start.x, this.level.start.y);
    this.player.setMode('ninja');
    this.player.doubleJumpUnlocked = !!g.save.stage('stage1').done;
    this.player.locked = false; this.player.pose = null;
    this.camX = 0; this.camY = this.level.start.y - HV * 0.62; this.cine = null; this.cool = 0.4;
    g.ui.setMode('lesson'); g.ui.setStageName(''); g.audio.music(false);
    this.state.checkpoint = { ...this.level.start };
    this.interactables = [
      ...this.adv.stations.map((st, i) => ({ id: 'st' + i, x: this.level.stations[i], label: st.label, st })),
      { id: 'door', x: this.level.door, label: 'افتح البوابة' },
    ];
    this.scene = 'play';
    g.refreshHud(); g.ui.showHud(true); g.ui.setKeys(0); g.ui.glowTransform(false);
    g.ui.setGoal('');
    g.ui.hide();
    await g.ui.dialog('', this.adv.story.intro);
    await g.ui.dialog('', this.adv.story.guardian);
    this.setGoal(this.adv.story.mission);
  }

  setGoal(t) { this.g.ui.setGoal(t); }

  // ------------------------------------------------------------------ update
  update(dt) {
    const g = this.g, p = this.player, s = this.state;
    this.t += dt;
    this.particles.update(dt);
    this.poof = Math.max(0, this.poof - dt);
    if (this.scene !== 'play') return;
    if (s.doorOpening) s.doorOpen = Math.min(1, s.doorOpen + dt * 0.7);

    this.world.updateCrates(dt);
    p.update(dt, g.input, this.world);

    const targetX = clamp(p.x - WV * (p.facing > 0 ? 0.38 : 0.62), 0, Math.max(0, this.world.width - WV));
    this.camX = lerp(this.camX, targetX, 1 - Math.pow(0.0005, dt));
    this.camY = lerp(this.camY, p.y - HV * 0.62, 1 - Math.pow(0.002, dt));

    for (const c of this.level.checkpoints) if (p.x > c.x && (!s.checkpoint || c.x > s.checkpoint.x)) s.checkpoint = { ...c };
    for (const sp of this.level.sparks) {
      if (s.sparks.has(sp.id)) continue;
      if (Math.hypot(sp.x - p.x, sp.y - (p.y - 90)) < 80) {
        s.sparks.add(sp.id); g.audio.play('collect');
        this.particles.burst(sp.x, sp.y, 14, { color: '#9ff', speed: 260, life: 0.7 });
        g.save.data.sparks = Math.max(g.save.data.sparks, s.sparks.size); g.save.commit();
        g.refreshHud();
      }
    }
    if (p.y > 1400) {
      const c = s.checkpoint || this.level.start;
      p.respawn(c.x, c.y - 4); s.retried = true; g.audio.play('wrong');
      this.setGoal('لا بأس! عدنا إلى آخر نقطة آمنة. حاول من جديد.');
      setTimeout(() => this.setGoal(this.goalText()), 2600);
    }

    let near = null;
    if (!p.locked && g.input.enabled) {
      for (const it of this.interactables) {
        if (Math.abs(it.x - p.x) < 140 && (!near || Math.abs(it.x - p.x) < Math.abs(near.x - p.x))) near = it;
      }
    }
    this.near = near;
    if (near) g.ui.setPrompt(`${near.label}${document.body.classList.contains('is-touch') ? '' : '  (E)'}`, (near.x - this.camX) * Z, (GROUND_Y - 300 - this.camY) * Z); else g.ui.setPrompt(null);

    this.cool = Math.max(0, this.cool - dt);
    if (near && this.cool === 0 && g.input.pressed('interact')) this.interact(near);
    if (g.input.pressed('transform') && !p.locked && this.cool === 0) this.togglePoof();
  }

  goalText() {
    const n = this.state.keys.size, total = this.adv.stations.length;
    return n >= total ? 'عندك المفاتيح كلها! اذهب إلى البوابة الكبيرة.' : `مفاتيح المعرفة: ${n} من ${total}. ${this.adv.story.mission}`;
  }

  /** Quick Mahdi ⇄ ninja change (the full 3.2 s cinematic stays in the prologue). */
  togglePoof() {
    const p = this.player;
    p.setMode(p.mode === 'ninja' ? 'normal' : 'ninja');
    this.g.audio.play('transform');
    this.particles.burst(p.x, p.y - 90, 40, { color: '#7fb6ff', speed: 420, life: 0.8 });
    this.poof = 0.5; this.cool = 0.8;
  }

  // ------------------------------------------------------------------ interactions
  async interact(it) {
    try { await this.doInteract(it); } finally { this.cool = 0.5; }
  }

  async doInteract(it) {
    const g = this.g, s = this.state, p = this.player;
    if (p.locked) return;
    g.audio.unlock();
    if (it.id === 'door') {
      if (s.doorOpening) return;
      const total = this.adv.stations.length;
      p.locked = true; p.vx = 0;
      if (s.keys.size < total) {
        await g.ui.dialog('مهدي', [`البوابة تحتاج إلى ${total} مفاتيح. معي ${s.keys.size} فقط.`, 'سأبحث عن محطات رفيق المعرفة.']);
        p.locked = false;
      } else {
        s.doorOpening = true; g.audio.play('door');
        this.particles.burst(it.x, GROUND_Y - 200, 60, { color: '#ffd873', speed: 500, life: 1.4 });
        await sleep(1800);
        await g.ui.dialog('', this.adv.story.outro);
        await this.finish();
      }
      return;
    }
    const st = it.st;
    p.locked = true; p.vx = 0;
    if (s.done.has(st.id)) {
      await g.ui.dialog(st.npc, ['أحسنت! أخذتَ مفتاح هذه المحطة من قبل. تابع طريقك يا مهدي.']);
      p.locked = false; return;
    }
    await g.ui.dialog(st.npc, st.intro);
    const ok = await this.runChallenge(st);
    p.locked = false;
    if (ok) {
      s.done.add(st.id); g.save.addXp(25);
      this.collectKey(st.id, it.x, GROUND_Y - 230);
    }
  }

  runChallenge(st) {
    const g = this.g, L = this.lesson, c = st.challenge;
    const base = { ...c, id: `${L.id}:${st.id}`, reviewStatus: L.reviewStatus, pageRef: L.pageRef };
    switch (c.type) {
      case 'hidden': return runHidden(g, base);
      case 'match': return runMatch(g, base);
      case 'order': return runOrder(g, base);
      case 'choose': return runChoose(g, base);
      case 'classify': return runClassify(g, { ...base, puzTitle: c.title, lessonTitle: c.title, simpleExplanation: c.prompt, answerExplanation: c.explain, childExample: c.example });
      case 'memory': return runMemory(g, { ...base, lessonTitle: c.title, answerExplanation: c.explain });
      default: return Promise.resolve(true);
    }
  }

  collectKey(id, x, y) {
    const s = this.state, g = this.g;
    g.audio.play('key');
    this.particles.burst(x, y, 40, { color: '#ffd873', speed: 420, life: 1.1, size: 7 });
    g.ui.setKeys(s.keys.add(id).size);
    this.setGoal(this.goalText());
  }

  // ------------------------------------------------------------------ finish: quiz, stars, unlock
  async finish() {
    const g = this.g, s = this.state, L = this.lesson;
    await g.ui.fade(() => { this.scene = 'end'; g.ui.showHud(false); g.ui.setPrompt(null); });
    const items = this.adv.quiz;
    const { mistakes } = await runReview(g, items, { ...L, quizTitle: 'الاختبار النهائي' });
    const q = g.save.lesson(L.id + ':quiz'); q.wrong += mistakes; g.save.attempt(L.id + ':quiz', true);

    let stars = 1;                                          // lesson completed
    if (mistakes <= items.length) stars++;                  // understood the quiz (a retry per question is fine)
    if (s.sparks.size >= this.level.sparks.length) stars++; // explored everything
    const first = !g.save.stage(L.id).done;
    const earned = g.save.stage(L.id);
    earned.done = true; earned.stars = Math.max(earned.stars, stars);
    g.save.data.stars = Object.values(g.save.data.stages).reduce((a, b) => a + b.stars, 0);
    g.save.addXp(50);
    g.save.addBadge('seeker');
    if (mistakes > 0 || s.retried) g.save.addBadge('persist');
    if (s.sparks.size >= this.level.sparks.length) g.save.addBadge('explorer');
    g.save.commit();
    s.finished = true; this.firstTime = first;
    g.audio.play('success');
    this.showResult(stars);
  }

  showResult(stars) {
    const g = this.g, L = this.lesson;
    const lessons = g.bookList;
    const idx = lessons.findIndex((l) => l.id === L.id);
    const next = lessons[idx + 1];
    const badges = g.save.data.badges.map((b) => BADGE_NAMES[b]).filter(Boolean);
    const mk = (n) => el('div', { class: 'stars' }, [1, 2, 3].map((i) => el('span', { class: i <= n ? 'on' : '' }, '★')));
    g.ui.show(g.ui.panel(
      el('h1', {}, 'أحسنت يا مهدي!'),
      el('p', {}, `أكملتَ درس «${L.lessonTitle}»`),
      mk(stars),
      el('p', { class: 'sub' }, `نقاط الخبرة: ${g.save.data.xp} · شرارات المعرفة في هذا الدرس: ${this.state.sparks.size} من ${this.level.sparks.length}`),
      el('p', {}, L.coreConcept),
      el('p', { class: 'sub' }, `${L.source} — بانتظار المراجعة العلمية.`),
      badges.length ? el('div', { class: 'badges' }, badges.map((b) => el('span', { class: 'badge' }, b))) : null,
      next
        ? el('p', {}, this.firstTime ? `فُتح درس جديد: «${next.lessonTitle}»` : '')
        : el('p', {}, 'أنهيتَ دروس «الفصل الأول: وجوب المعرفة». الفصول التالية قيد البناء (انظر خريطة المغامرة).'),
      el('div', {},
        next ? el('button', { class: 'btn', onclick: () => g.startLesson(next.id) }, 'الدرس التالي') : null,
        el('button', { class: next ? 'btn ghost' : 'btn', onclick: () => g.openMap() }, 'خريطة المغامرة'),
        el('button', { class: 'btn ghost', onclick: () => g.startLesson(L.id) }, 'العب الدرس مرة أخرى'),
      ),
    ));
  }

  // ------------------------------------------------------------------ render
  render(ctx) {
    ctx.clearRect(0, 0, W, H);
    if (this.scene !== 'play') { ctx.fillStyle = '#0b1230'; ctx.fillRect(0, 0, W, H); return; }
    const s = this.state, t = this.t, cam = this.camX, th = this.theme;
    drawThemePortrait(ctx, th, cam, this.camY);
    ctx.save(); ctx.scale(Z, Z); ctx.translate(0, -this.camY);
    for (const z of this.world.climb) R.drawClimbZone(ctx, z, cam);
    this.level.checkpoints.forEach((c) => R.drawCheckpoint(ctx, c, cam, t, s.checkpoint && s.checkpoint.x === c.x));
    for (const so of this.world.solids) drawThemeSolid(ctx, th, so, cam);
    for (const c of this.world.crates) R.drawCrate(ctx, c, cam);
    this.adv.stations.forEach((st, i) => this.drawStation(ctx, st, this.level.stations[i], cam, t, s.done.has(st.id)));
    R.drawDoor(ctx, this.level.door, cam, s.doorOpen, t);
    this.drawSockets(ctx, cam);
    for (const sp of this.level.sparks) if (!s.sparks.has(sp.id)) R.drawSpark(ctx, sp, cam, t);
    ctx.save(); ctx.font = '700 30px "Segoe UI",Tahoma,sans-serif'; ctx.direction = 'rtl'; ctx.textAlign = 'center';
    for (const h of this.level.hints) {
      const x = h.x - cam; if (x < -400 || x > WV + 400) continue;
      ctx.fillStyle = 'rgba(0,0,0,.35)'; ctx.fillText(h.text, x + 2, GROUND_Y - 238);
      ctx.fillStyle = 'rgba(255,248,210,.95)'; ctx.fillText(h.text, x, GROUND_Y - 240);
    }
    ctx.restore();
    this.player.draw(ctx, cam, 0);
    this.particles.draw(ctx, cam);
    ctx.restore();
    ctx.save(); ctx.globalCompositeOperation = 'lighter';
    for (let i = 0; i < 24; i++) {
      const x = ((i * 211 + t * (10 + (i % 5) * 4) - cam * 0.7) % (W + 100) + W + 100) % (W + 100) - 50;
      const y = 300 + ((i * 97) % 900) + Math.sin(t + i) * 18;
      ctx.fillStyle = `rgba(${th.mote},${0.16 + 0.1 * Math.sin(t * 2 + i)})`; ctx.beginPath(); ctx.arc(x, y, 3 + (i % 3), 0, 7); ctx.fill();
    }
    ctx.restore();
    if (this.poof > 0) { ctx.fillStyle = `rgba(160,210,255,${this.poof * 0.5})`; ctx.fillRect(0, 0, W, H); }
  }

  drawStation(ctx, st, x, cam, t, done) {
    const sx = x - cam; if (sx < -200 || sx > W + 200) return;
    const sy = GROUND_Y - 200 + Math.sin(t * 2 + x) * 10;
    const g = ctx.createRadialGradient(sx, sy, 6, sx, sy, 120);
    g.addColorStop(0, done ? 'rgba(160,255,200,.7)' : 'rgba(160,220,255,.85)'); g.addColorStop(1, 'rgba(160,220,255,0)');
    ctx.fillStyle = g; ctx.beginPath(); ctx.arc(sx, sy, 120, 0, 7); ctx.fill();
    ctx.fillStyle = done ? '#d9ffe9' : '#d8f1ff'; ctx.beginPath(); ctx.arc(sx, sy, 52, 0, 7); ctx.fill();
    ctx.strokeStyle = done ? '#55c88a' : '#7ab8ff'; ctx.lineWidth = 5; ctx.beginPath(); ctx.ellipse(sx, sy, 72, 22, t, 0, 7); ctx.stroke();
    ctx.font = '54px "Segoe UI Emoji","Apple Color Emoji","Noto Color Emoji",sans-serif'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
    ctx.fillText(done ? '✅' : ICON[st.challenge.type] || '❔', sx, sy + 3);
    ctx.textBaseline = 'alphabetic';
    ctx.fillStyle = '#6a4a2a'; ctx.fillRect(sx - 60, GROUND_Y - 100, 120, 100);
    ctx.fillStyle = '#8a6a3a'; ctx.fillRect(sx - 72, GROUND_Y - 112, 144, 16);
  }

  /** Three key sockets above the final door: they light up as keys are collected. */
  drawSockets(ctx, cam) {
    const sx = this.level.door - cam, y = GROUND_Y - 520, n = this.adv.stations.length;
    if (sx < -300 || sx > W + 300) return;
    for (let i = 0; i < n; i++) {
      const x = sx + (i - (n - 1) / 2) * 90, on = i < this.state.keys.size;
      ctx.fillStyle = on ? '#ffd873' : 'rgba(20,10,50,.7)'; ctx.beginPath(); ctx.arc(x, y, 30, 0, 7); ctx.fill();
      ctx.strokeStyle = '#c9a25a'; ctx.lineWidth = 5; ctx.stroke();
      if (on) R.drawKeyShape(ctx, x + 6, y, 0.5);
    }
  }
}
