import { rng } from '../engine/util.js';

const W = 1920, H = 1080, TW = 1280;
const cv = (w, h) => { const c = document.createElement('canvas'); c.width = w; c.height = h; return c; };

// Procedural stylised backgrounds — placeholders for hand-painted art (see docs/STAGE_PLAN.md).
const THEMES = {
  garden: {
    sky: ['#7ec8ff', '#ffe6b0', '#ffc98a'], ground: ['#6fcf62', '#3b8d3f', '#244f26'], line: '#a8f28f',
    plat: ['#b07a42', '#6a4524'], mote: '255,240,170', shade: 'rgba(255,255,255,0)',
    far(g, r) {
      g.fillStyle = '#fff3c4'; g.beginPath(); g.arc(1450, 230, 90, 0, 7); g.fill();
      g.fillStyle = 'rgba(255,243,196,.3)'; g.beginPath(); g.arc(1450, 230, 150, 0, 7); g.fill();
      g.fillStyle = 'rgba(255,255,255,.85)';
      for (let i = 0; i < 6; i++) { const x = r() * W, y = 90 + r() * 260; for (let k = 0; k < 4; k++) { g.beginPath(); g.arc(x + k * 46, y + (k % 2) * -14, 40 + r() * 20, 0, 7); g.fill(); } }
      g.fillStyle = '#8cc76b'; g.beginPath(); g.moveTo(0, 760); for (let x = 0; x <= W; x += 60) g.lineTo(x, 640 + Math.sin(x / 190) * 70); g.lineTo(W, H); g.lineTo(0, H); g.fill();
    },
    mid(g, r) {
      for (let i = 0; i < 5; i++) {
        const x = 120 + i * 250 + r() * 60;
        g.fillStyle = '#6a4524'; g.fillRect(x - 14, 600, 28, 300);
        g.fillStyle = i % 2 ? '#3f9a48' : '#4fae52'; g.beginPath(); g.arc(x, 560, 110, 0, 7); g.arc(x - 70, 620, 80, 0, 7); g.arc(x + 70, 620, 80, 0, 7); g.fill();
        g.fillStyle = '#ff7a8a'; for (let k = 0; k < 5; k++) { g.beginPath(); g.arc(x - 60 + r() * 120, 520 + r() * 130, 8, 0, 7); g.fill(); }
      }
    },
  },
  crossroads: {
    sky: ['#2b2a6b', '#d9647a', '#ffb36b'], ground: ['#b58a52', '#7a5a30', '#432f18'], line: '#e0b878',
    plat: ['#9a6a3a', '#5a3a1a'], mote: '255,200,150', shade: 'rgba(40,10,40,.15)',
    far(g, r) {
      g.fillStyle = '#ffd9a0'; g.beginPath(); g.arc(1300, 600, 120, 0, 7); g.fill();
      g.fillStyle = '#5a2a5a'; g.beginPath(); g.moveTo(0, 700); for (let x = 0; x <= W; x += 80) g.lineTo(x, 620 + Math.sin(x / 140) * 50 + (x % 240 ? 0 : 20)); g.lineTo(W, H); g.lineTo(0, H); g.fill();
      for (let i = 0; i < 50; i++) { g.fillStyle = `rgba(255,255,255,${0.2 + r() * 0.5})`; g.fillRect(r() * W, r() * 300, 2, 2); }
    },
    mid(g, r) {
      for (let i = 0; i < 4; i++) {
        const x = 130 + i * 320;
        g.fillStyle = '#3a2418'; g.fillRect(x - 8, 560, 16, 340);
        g.fillStyle = '#7a5230';
        const dir = i % 2 ? 1 : -1;
        g.beginPath(); g.moveTo(x, 590); g.lineTo(x + dir * 150, 590); g.lineTo(x + dir * 185, 625); g.lineTo(x + dir * 150, 660); g.lineTo(x, 660); g.fill();
        g.fillStyle = '#e8d9a8'; g.fillRect(x + (dir > 0 ? 20 : -130), 610, 110, 8); g.fillRect(x + (dir > 0 ? 20 : -130), 630, 80, 8);
      }
    },
  },
  tower: {
    sky: ['#070420', '#1d1250', '#2c1c6a'], ground: ['#7a86c0', '#454e82', '#1e2347'], line: '#b8c4ff',
    plat: ['#6a76b0', '#343b6c'], mote: '190,210,255', shade: 'rgba(5,5,30,.25)',
    far(g, r) {
      for (let i = 0; i < 160; i++) { g.fillStyle = `rgba(255,255,255,${0.2 + r() * 0.7})`; const s = 2 + r() * 3; g.fillRect(r() * W, r() * 700, s, s); }
      g.fillStyle = '#fff6d6'; g.beginPath(); g.arc(1500, 220, 80, 0, 7); g.fill();
      g.fillStyle = '#070420'; g.beginPath(); g.arc(1530, 200, 72, 0, 7); g.fill();
      g.fillStyle = 'rgba(255,246,214,.18)'; g.beginPath(); g.arc(1500, 220, 140, 0, 7); g.fill();
      g.fillStyle = '#17123c';
      [[150, 520, 140], [420, 440, 120], [980, 500, 160], [1500, 460, 130]].forEach(([x, y, w]) => { g.fillRect(x, y, w, H - y); g.beginPath(); g.moveTo(x - 10, y); g.lineTo(x + w / 2, y - 100); g.lineTo(x + w + 10, y); g.fill(); });
    },
    mid(g, r) {
      for (let i = 0; i < 4; i++) {
        const x = 40 + i * 320;
        g.fillStyle = '#23285a'; g.fillRect(x, 300, 260, 600);
        g.beginPath(); g.arc(x + 130, 300, 130, Math.PI, 0); g.fill();
        g.fillStyle = '#ffd873'; g.beginPath(); g.roundRect(x + 85, 380, 90, 170, [45, 45, 0, 0]); g.fill();
        g.strokeStyle = '#14173a'; g.lineWidth = 6; g.beginPath(); g.moveTo(x + 130, 380); g.lineTo(x + 130, 550); g.moveTo(x + 85, 460); g.lineTo(x + 175, 460); g.stroke();
      }
    },
  },
  hill: {
    sky: ['#5ab4ff', '#b5e1ff', '#eaf7ff'], ground: ['#e3c777', '#b08a46', '#6a4f24'], line: '#fff0b0',
    plat: ['#c9a25a', '#7a5a2a'], mote: '255,255,255', shade: 'rgba(255,255,255,0)',
    far(g, r) {
      g.fillStyle = '#fffbe0'; g.beginPath(); g.arc(300, 200, 80, 0, 7); g.fill();
      g.fillStyle = '#a8c8e8'; g.beginPath(); g.moveTo(0, 700); [[200, 380], [500, 620], [800, 300], [1150, 640], [1450, 360], [1800, 600], [W, 520]].forEach(([x, y]) => g.lineTo(x, y)); g.lineTo(W, H); g.lineTo(0, H); g.fill();
      g.fillStyle = '#fff'; [[200, 380], [800, 300], [1450, 360]].forEach(([x, y]) => { g.beginPath(); g.moveTo(x, y); g.lineTo(x - 70, y + 110); g.lineTo(x + 70, y + 110); g.fill(); });
      g.fillStyle = 'rgba(255,255,255,.9)';
      for (let i = 0; i < 5; i++) { const x = r() * W, y = 120 + r() * 200; for (let k = 0; k < 4; k++) { g.beginPath(); g.arc(x + k * 44, y + (k % 2) * -12, 36 + r() * 16, 0, 7); g.fill(); } }
    },
    mid(g, r) {
      g.fillStyle = '#8fbf6a'; g.beginPath(); g.moveTo(0, 800); for (let x = 0; x <= TW; x += 40) g.lineTo(x, 640 + Math.sin(x / 120) * 60); g.lineTo(TW, H); g.lineTo(0, H); g.fill();
      for (let i = 0; i < 6; i++) { const x = 60 + i * 210 + r() * 40; g.fillStyle = '#6a8a4a'; g.beginPath(); g.moveTo(x, 800); g.lineTo(x - 22, 860); g.lineTo(x + 22, 860); g.fill(); }
    },
  },
};

const cache = {};
export function getTheme(name) {
  if (cache[name]) return cache[name];
  const T = THEMES[name] || THEMES.garden;
  const far = cv(W, H), g = far.getContext('2d');
  const sky = g.createLinearGradient(0, 0, 0, H);
  T.sky.forEach((c, i) => sky.addColorStop(i / (T.sky.length - 1), c));
  g.fillStyle = sky; g.fillRect(0, 0, W, H);
  T.far(g, rng(11));
  const mid = cv(TW, H), m = mid.getContext('2d');
  T.mid(m, rng(29));
  if (T.shade !== 'rgba(255,255,255,0)') { m.fillStyle = T.shade; m.fillRect(0, 0, TW, H); }
  return (cache[name] = { ...T, farImg: far, midImg: mid, name });
}

export function drawThemeBackground(ctx, th, camX) {
  const fx = -((camX * 0.12) % W);
  ctx.drawImage(th.farImg, fx, 0); ctx.drawImage(th.farImg, fx + W, 0);
  const mx = -((camX * 0.45) % TW);
  for (let x = mx; x < W; x += TW) ctx.drawImage(th.midImg, x, 0);
}

export function drawThemeSolid(ctx, th, s, camX) {
  const x = s.x - camX;
  if (x > W + 50 || x + s.w < -50) return;
  if (s.kind === 'ground' || s.kind === 'step') {
    const h = Math.max(s.h, 200);
    const g = ctx.createLinearGradient(0, s.y, 0, s.y + 200);
    g.addColorStop(0, th.ground[0]); g.addColorStop(0.1, th.ground[1]); g.addColorStop(1, th.ground[2]);
    ctx.fillStyle = g; ctx.fillRect(x, s.y, s.w, h);
    ctx.fillStyle = th.line; ctx.fillRect(x, s.y, s.w, 7);
    ctx.fillStyle = 'rgba(0,0,0,.18)'; for (let tx = Math.floor(camX / 160) * 160; tx < camX + W + 160; tx += 160) { if (tx > s.x && tx < s.x + s.w) ctx.fillRect(tx - camX, s.y + 8, 3, h); }
  } else if (s.kind === 'wall') {
    ctx.fillStyle = th.ground[1]; ctx.fillRect(x, s.y, s.w, s.h);
    ctx.strokeStyle = th.ground[2]; ctx.lineWidth = 3;
    for (let by = s.y; by < s.y + s.h; by += 50) ctx.strokeRect(x, by, s.w, 50);
    ctx.fillStyle = th.line; ctx.fillRect(x, s.y, s.w, 6);
  } else { // plat
    ctx.fillStyle = th.plat[0]; ctx.fillRect(x, s.y, s.w, s.h);
    ctx.fillStyle = th.plat[1]; ctx.fillRect(x, s.y + s.h - 8, s.w, 8);
    ctx.strokeStyle = th.plat[1]; ctx.lineWidth = 2;
    for (let px = x + 30; px < x + s.w; px += 30) { ctx.beginPath(); ctx.moveTo(px, s.y); ctx.lineTo(px, s.y + s.h - 8); ctx.stroke(); }
    ctx.fillStyle = 'rgba(255,255,255,.5)'; ctx.fillRect(x, s.y, s.w, 4);
  }
}

/** Portrait (1080x1920) background: sky fill + the far/mid layers anchored to the horizon, drawn in screen space. */
export function drawThemePortrait(ctx, th, camX, camY) {
  const PW = 1080, PH = 1920, hz = 1190 - camY * 0.2 * 1.35;
  const g = ctx.createLinearGradient(0, 0, 0, hz - 800); g.addColorStop(0, th.sky[0]); g.addColorStop(1, th.sky[1] || th.sky[0]);
  ctx.fillStyle = th.sky[0]; ctx.fillRect(0, -700, PW, 720);
  ctx.fillStyle = g; ctx.fillRect(0, 0, PW, PH);
  const y0 = hz - 860;
  const fx = -((camX * 1.35 * 0.12) % W);
  ctx.drawImage(th.farImg, fx, y0); ctx.drawImage(th.farImg, fx + W, y0);
  const mx = -((camX * 1.35 * 0.45) % TW);
  for (let x = mx; x < PW; x += TW) ctx.drawImage(th.midImg, x, y0);
}
