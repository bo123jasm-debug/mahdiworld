import { rng } from '../engine/util.js';
import { GROUND_Y } from './levels.js';

const W = 1920, H = 1080;
const BOOK_COLORS = ['#7a2230', '#2b4c8c', '#2f6b4a', '#8a6a1f', '#5a2a7a', '#9a4a22', '#1f5f6f', '#6a2a3a'];

function canvas(w, h) { const c = document.createElement('canvas'); c.width = w; c.height = h; return c; }

// --------------------------------------------------------------------------------------------
// Pre-rendered parallax layers for the library (procedural, stylised — placeholder for painted art)
// --------------------------------------------------------------------------------------------
export function makeLibraryFar() {
  const c = canvas(W, H), g = c.getContext('2d');
  const sky = g.createLinearGradient(0, 0, 0, H);
  sky.addColorStop(0, '#0e0830'); sky.addColorStop(0.55, '#33206b'); sky.addColorStop(1, '#1a1040');
  g.fillStyle = sky; g.fillRect(0, 0, W, H);
  const r = rng(7);
  for (let i = 0; i < 90; i++) { // stars
    g.fillStyle = `rgba(255,255,255,${0.2 + r() * 0.6})`;
    g.fillRect(r() * W, r() * 520, 2 + r() * 2, 2 + r() * 2);
  }
  // three tall gothic windows
  [[200, 90, 380, 640], [770, 60, 380, 680], [1340, 90, 380, 640]].forEach(([x, y, w, h], i) => {
    g.save();
    g.beginPath(); g.moveTo(x, y + h); g.lineTo(x, y + w / 2); g.arc(x + w / 2, y + w / 2, w / 2, Math.PI, 0); g.lineTo(x + w, y + h); g.closePath();
    const wg = g.createLinearGradient(0, y, 0, y + h);
    wg.addColorStop(0, '#9a62e0'); wg.addColorStop(0.6, '#c488e8'); wg.addColorStop(1, '#6d4ac0');
    g.fillStyle = wg; g.fill(); g.clip();
    if (i === 1) { g.fillStyle = '#fff6d6'; g.beginPath(); g.arc(x + w / 2, y + 230, 70, 0, 7); g.fill();
      g.fillStyle = 'rgba(255,246,214,.25)'; g.beginPath(); g.arc(x + w / 2, y + 230, 120, 0, 7); g.fill(); }
    g.strokeStyle = 'rgba(30,16,70,.85)'; g.lineWidth = 10;
    for (let k = 1; k < 3; k++) { g.beginPath(); g.moveTo(x + (w / 3) * k, y); g.lineTo(x + (w / 3) * k, y + h); g.stroke(); }
    for (let k = 1; k < 5; k++) { g.beginPath(); g.moveTo(x, y + (h / 5) * k + 40); g.lineTo(x + w, y + (h / 5) * k + 40); g.stroke(); }
    g.restore();
    g.strokeStyle = '#3a2870'; g.lineWidth = 14;
    g.beginPath(); g.moveTo(x, y + h); g.lineTo(x, y + w / 2); g.arc(x + w / 2, y + w / 2, w / 2, Math.PI, 0); g.lineTo(x + w, y + h); g.stroke();
  });
  return c;
}

export function makeLibraryMid() {
  const TW = 1280, c = canvas(TW, H), g = c.getContext('2d');
  const r = rng(21);
  const shelfW = 320;
  for (let s = 0; s < TW / shelfW; s++) {
    const x0 = s * shelfW;
    g.fillStyle = '#2a1a4a'; g.fillRect(x0 + 6, 250, shelfW - 12, 700);
    g.fillStyle = '#3b2766'; g.fillRect(x0 + 6, 250, 14, 700); g.fillRect(x0 + shelfW - 20, 250, 14, 700);
    for (let row = 0; row < 7; row++) {
      const ry = 290 + row * 90;
      let x = x0 + 24;
      while (x < x0 + shelfW - 30) {
        const bw = 14 + r() * 18, bh = 52 + r() * 26;
        g.fillStyle = BOOK_COLORS[(r() * BOOK_COLORS.length) | 0];
        g.fillRect(x, ry + (84 - bh), bw, bh);
        g.fillStyle = 'rgba(255,255,255,.12)'; g.fillRect(x + 2, ry + (84 - bh) + 6, bw - 4, 3);
        x += bw + 2;
      }
      g.fillStyle = '#4a3480'; g.fillRect(x0 + 20, ry + 84, shelfW - 40, 8);
    }
  }
  g.fillStyle = 'rgba(12,6,40,.45)'; g.fillRect(0, 0, TW, H); // atmospheric depth
  return c;
}

// --------------------------------------------------------------------------------------------
// Library drawing
// --------------------------------------------------------------------------------------------
export function drawLibraryBackground(ctx, far, mid, camX, t) {
  const fx = -((camX * 0.12) % W);
  ctx.drawImage(far, fx, 0); ctx.drawImage(far, fx + W, 0);
  const TW = 1280, mx = -((camX * 0.45) % TW);
  for (let x = mx; x < W; x += TW) ctx.drawImage(mid, x, 0);
  // light shafts
  ctx.save(); ctx.globalCompositeOperation = 'lighter';
  for (let i = 0; i < 4; i++) {
    const x = ((i * 640 - camX * 0.3) % 2560 + 2560) % 2560 - 300;
    const g = ctx.createLinearGradient(x, 0, x + 260, 800);
    g.addColorStop(0, 'rgba(190,150,255,.14)'); g.addColorStop(1, 'rgba(190,150,255,0)');
    ctx.fillStyle = g;
    ctx.beginPath(); ctx.moveTo(x, 0); ctx.lineTo(x + 160, 0); ctx.lineTo(x + 380, 900); ctx.lineTo(x + 120, 900); ctx.fill();
  }
  ctx.restore();
}

export function drawSolid(ctx, s, camX) {
  const x = s.x - camX;
  if (x > W + 50 || x + s.w < -50) return;
  if (s.kind === 'ground' || s.kind === 'floor') {
    const g = ctx.createLinearGradient(0, s.y, 0, s.y + 180);
    g.addColorStop(0, '#4a3678'); g.addColorStop(0.08, '#2e2058'); g.addColorStop(1, '#150d33');
    ctx.fillStyle = g; ctx.fillRect(x, s.y, s.w, 180);
    ctx.fillStyle = '#7a62b8'; ctx.fillRect(x, s.y, s.w, 6);
    ctx.fillStyle = 'rgba(0,0,0,.28)';
    for (let tx = Math.floor((camX) / 160) * 160; tx < camX + W + 160; tx += 160) {
      if (tx < s.x || tx > s.x + s.w) continue;
      ctx.fillRect(tx - camX, s.y + 6, 3, 174);
    }
    ctx.fillRect(x, s.y + 70, s.w, 3);
  } else if (s.kind === 'wall') {
    ctx.fillStyle = '#4b3a78'; ctx.fillRect(x, s.y, s.w, s.h);
    ctx.strokeStyle = '#2a1d50'; ctx.lineWidth = 3;
    for (let by = s.y; by < s.y + s.h; by += 50) {
      ctx.strokeRect(x, by, s.w, 50);
      ctx.beginPath(); ctx.moveTo(x + (((by - s.y) / 50) % 2 ? s.w * 0.3 : s.w * 0.7), by); ctx.lineTo(x + (((by - s.y) / 50) % 2 ? s.w * 0.3 : s.w * 0.7), by + 50); ctx.stroke();
    }
    ctx.fillStyle = '#8f78d0'; ctx.fillRect(x, s.y, s.w, 6);
  } else if (s.kind === 'books') {
    const r = rng(s.seed || 1);
    let bx = x;
    while (bx < x + s.w) {
      const bw = Math.min(16 + r() * 16, x + s.w - bx);
      ctx.fillStyle = BOOK_COLORS[(r() * BOOK_COLORS.length) | 0];
      ctx.fillRect(bx, s.y, bw, s.h);
      ctx.fillStyle = 'rgba(255,255,255,.25)'; ctx.fillRect(bx + 2, s.y + 6, bw - 4, 3);
      ctx.fillStyle = '#e8d9a8'; ctx.fillRect(bx, s.y + s.h - 4, bw, 4);
      bx += bw;
    }
    ctx.fillStyle = 'rgba(255,255,255,.55)'; ctx.fillRect(x, s.y, s.w, 4);
  }
}

export function drawCrate(ctx, c, camX) {
  const x = c.x - camX, y = c.y;
  ctx.fillStyle = '#9a6a3a'; ctx.fillRect(x, y, c.w, c.h);
  ctx.strokeStyle = '#5a3a1a'; ctx.lineWidth = 6; ctx.strokeRect(x + 3, y + 3, c.w - 6, c.h - 6);
  ctx.beginPath(); ctx.moveTo(x + 6, y + 6); ctx.lineTo(x + c.w - 6, y + c.h - 6); ctx.moveTo(x + c.w - 6, y + 6); ctx.lineTo(x + 6, y + c.h - 6); ctx.stroke();
  ctx.fillStyle = 'rgba(255,255,255,.18)'; ctx.fillRect(x, y, c.w, 5);
}

export function drawClimbZone(ctx, z, camX) {
  const x = z.x - camX;
  ctx.fillStyle = '#3a2766'; ctx.fillRect(x, z.y, z.w, z.h);
  ctx.fillStyle = '#4e3590'; ctx.fillRect(x, z.y, 10, z.h); ctx.fillRect(x + z.w - 10, z.y, 10, z.h);
  ctx.fillStyle = '#c9a25a';
  for (let y = z.y + 24; y < z.y + z.h; y += 46) ctx.fillRect(x + 10, y, z.w - 20, 8);
  const r = rng(5);
  for (let y = z.y + 10; y < z.y + z.h - 20; y += 46) {
    for (let bx = x + 14; bx < x + z.w - 14; bx += 14) { ctx.fillStyle = BOOK_COLORS[(r() * 8) | 0]; ctx.fillRect(bx, y + 8, 10, 34 - r() * 8); }
  }
}

export function drawSpark(ctx, s, camX, t) {
  const x = s.x - camX, y = s.y + Math.sin(t * 3 + s.x) * 8;
  const g = ctx.createRadialGradient(x, y, 2, x, y, 36);
  g.addColorStop(0, 'rgba(255,255,255,1)'); g.addColorStop(0.35, 'rgba(150,240,255,.9)'); g.addColorStop(1, 'rgba(150,240,255,0)');
  ctx.fillStyle = g; ctx.beginPath(); ctx.arc(x, y, 36, 0, 7); ctx.fill();
}

export function drawKey(ctx, k, camX, t) {
  const x = k.x - camX, y = k.y + Math.sin(t * 2.4) * 10;
  const g = ctx.createRadialGradient(x, y, 4, x, y, 90);
  g.addColorStop(0, 'rgba(255,225,120,.9)'); g.addColorStop(1, 'rgba(255,225,120,0)');
  ctx.fillStyle = g; ctx.beginPath(); ctx.arc(x, y, 90, 0, 7); ctx.fill();
  drawKeyShape(ctx, x, y, 1.1);
}

export function drawKeyShape(ctx, x, y, s = 1) {
  ctx.save(); ctx.translate(x, y); ctx.scale(s, s); ctx.rotate(-0.5);
  ctx.fillStyle = '#ffd873'; ctx.strokeStyle = '#8a5a10'; ctx.lineWidth = 4;
  ctx.beginPath(); ctx.arc(-22, 0, 20, 0, 7); ctx.fill(); ctx.stroke();
  ctx.fillStyle = '#2a1a4a'; ctx.beginPath(); ctx.arc(-22, 0, 8, 0, 7); ctx.fill();
  ctx.fillStyle = '#ffd873'; ctx.fillRect(-4, -6, 52, 12); ctx.strokeRect(-4, -6, 52, 12);
  ctx.fillRect(30, 6, 8, 16); ctx.strokeRect(30, 6, 8, 16); ctx.fillRect(42, 6, 8, 12); ctx.strokeRect(42, 6, 8, 12);
  ctx.restore();
}

export function drawTablet(ctx, x, camX, t, solved) {
  const sx = x - camX;
  ctx.fillStyle = '#5a4a8a'; ctx.beginPath(); ctx.roundRect(sx - 80, GROUND_Y - 260, 160, 260, [80, 80, 0, 0]); ctx.fill();
  ctx.strokeStyle = '#2a1d50'; ctx.lineWidth = 6; ctx.stroke();
  const glow = solved ? 0.25 : 0.55 + Math.sin(t * 3) * 0.25;
  ctx.fillStyle = `rgba(150,240,255,${glow})`;
  [[-34, -190], [34, -190], [-34, -120], [34, -120]].forEach(([dx, dy], i) => {
    ctx.beginPath(); ctx.arc(sx + dx, GROUND_Y + dy, 14 + (i % 2) * 2, 0, 7); ctx.fill();
  });
  if (solved) { ctx.fillStyle = '#ffd873'; ctx.font = '700 46px sans-serif'; ctx.textAlign = 'center'; ctx.fillText('✓', sx, GROUND_Y - 40); }
}

export function drawCompanion(ctx, x, camX, t, done) {
  const sx = x - camX, sy = GROUND_Y - 190 + Math.sin(t * 2) * 12;
  const g = ctx.createRadialGradient(sx, sy, 6, sx, sy, 110);
  g.addColorStop(0, 'rgba(160,220,255,.85)'); g.addColorStop(1, 'rgba(160,220,255,0)');
  ctx.fillStyle = g; ctx.beginPath(); ctx.arc(sx, sy, 110, 0, 7); ctx.fill();
  ctx.fillStyle = '#d8f1ff'; ctx.beginPath(); ctx.arc(sx, sy, 46, 0, 7); ctx.fill();
  ctx.strokeStyle = '#7ab8ff'; ctx.lineWidth = 5; ctx.beginPath(); ctx.ellipse(sx, sy, 66, 20, t, 0, 7); ctx.stroke();
  ctx.fillStyle = '#14203f';
  ctx.beginPath(); ctx.ellipse(sx - 15, sy - 4, 7, done ? 3 : 10, 0, 0, 7); ctx.ellipse(sx + 15, sy - 4, 7, done ? 3 : 10, 0, 0, 7); ctx.fill();
  ctx.beginPath(); ctx.arc(sx, sy + 12, 10, 0.1 * Math.PI, 0.9 * Math.PI); ctx.lineWidth = 4; ctx.strokeStyle = '#14203f'; ctx.stroke();
  // little lectern
  ctx.fillStyle = '#6a4a2a'; ctx.fillRect(sx - 60, GROUND_Y - 100, 120, 100);
  ctx.fillStyle = '#8a6a3a'; ctx.fillRect(sx - 72, GROUND_Y - 112, 144, 16);
}

export function drawDoor(ctx, x, camX, open, t) {
  const sx = x - camX, top = GROUND_Y - 420;
  ctx.fillStyle = '#2a1d50'; ctx.beginPath(); ctx.roundRect(sx - 150, top - 30, 300, 450, [150, 150, 0, 0]); ctx.fill();
  ctx.strokeStyle = '#c9a25a'; ctx.lineWidth = 10; ctx.stroke();
  // inner light
  const g = ctx.createLinearGradient(0, top, 0, GROUND_Y);
  g.addColorStop(0, '#fff3c4'); g.addColorStop(1, '#ffb347');
  ctx.save(); ctx.beginPath(); ctx.roundRect(sx - 120, top, 240, 420, [120, 120, 0, 0]); ctx.clip();
  if (open > 0) { ctx.fillStyle = g; ctx.fillRect(sx - 120, top, 240, 420); }
  // two leaves sliding apart
  const lw = 120 * (1 - open);
  ctx.fillStyle = '#4a3480'; ctx.fillRect(sx - 120, top, lw, 420); ctx.fillRect(sx + 120 - lw, top, lw, 420);
  ctx.strokeStyle = '#c9a25a'; ctx.lineWidth = 5;
  for (let i = 0; i < 4; i++) { ctx.strokeRect(sx - 120 + 8, top + 30 + i * 96, Math.max(0, lw - 16), 80); ctx.strokeRect(sx + 120 - lw + 8, top + 30 + i * 96, Math.max(0, lw - 16), 80); }
  ctx.restore();
  // three key sockets
  return { sx, top };
}

export function drawCheckpoint(ctx, c, camX, t, active) {
  const x = c.x - camX;
  ctx.fillStyle = '#6a5a9a'; ctx.fillRect(x - 5, GROUND_Y - 120, 10, 120);
  ctx.fillStyle = active ? '#ffd873' : '#7a6aa8';
  ctx.beginPath(); ctx.moveTo(x + 5, GROUND_Y - 120); ctx.lineTo(x + 60, GROUND_Y - 100 + Math.sin(t * 3) * 3); ctx.lineTo(x + 5, GROUND_Y - 80); ctx.fill();
}

// --------------------------------------------------------------------------------------------
// Room (home library) drawing
// --------------------------------------------------------------------------------------------
export function makeRoomBack() {
  const c = canvas(W, H), g = c.getContext('2d');
  const wall = g.createLinearGradient(0, 0, 0, GROUND_Y);
  wall.addColorStop(0, '#f1e2bf'); wall.addColorStop(1, '#d9c192');
  g.fillStyle = wall; g.fillRect(0, 0, W, GROUND_Y);
  g.fillStyle = '#c4a876'; g.fillRect(0, 130, W, 14); // crown moulding
  g.fillStyle = '#7a5230'; g.fillRect(0, 700, W, 200); // wainscot
  g.fillStyle = '#946438'; g.fillRect(0, 700, W, 14);
  g.strokeStyle = 'rgba(0,0,0,.25)'; g.lineWidth = 3;
  for (let x = 0; x < W; x += 180) g.strokeRect(x + 14, 730, 152, 150);
  const fl = g.createLinearGradient(0, GROUND_Y, 0, H);
  fl.addColorStop(0, '#a8743f'); fl.addColorStop(1, '#6a4524');
  g.fillStyle = fl; g.fillRect(0, GROUND_Y, W, H - GROUND_Y);
  g.strokeStyle = 'rgba(0,0,0,.22)'; g.lineWidth = 2;
  for (let x = 0; x < W; x += 150) { g.beginPath(); g.moveTo(x, GROUND_Y); g.lineTo(x - 60, H); g.stroke(); }
  g.fillStyle = 'rgba(255,255,255,.2)'; g.fillRect(0, GROUND_Y, W, 5);
  // window with morning sky
  const wx = 300, wy = 200, ww = 300, wh = 420;
  const sky = g.createLinearGradient(0, wy, 0, wy + wh);
  sky.addColorStop(0, '#7fb6f0'); sky.addColorStop(1, '#ffe2a8');
  g.fillStyle = '#6a4524'; g.fillRect(wx - 16, wy - 16, ww + 32, wh + 32);
  g.fillStyle = sky; g.fillRect(wx, wy, ww, wh);
  g.fillStyle = '#fff3c0'; g.beginPath(); g.arc(wx + 210, wy + 300, 52, 0, 7); g.fill();
  g.fillStyle = '#6a4524'; g.fillRect(wx + ww / 2 - 6, wy, 12, wh); g.fillRect(wx, wy + wh / 2 - 6, ww, 12);
  // sun rays on floor/wall
  g.fillStyle = 'rgba(255,240,180,.22)';
  g.beginPath(); g.moveTo(wx, wy + wh); g.lineTo(wx + ww, wy + wh); g.lineTo(wx + ww + 280, GROUND_Y); g.lineTo(wx - 40, GROUND_Y); g.fill();
  // rug
  g.fillStyle = '#7a2230'; g.beginPath(); g.ellipse(840, GROUND_Y + 60, 340, 44, 0, 0, 7); g.fill();
  g.strokeStyle = '#e8c36a'; g.lineWidth = 6; g.beginPath(); g.ellipse(840, GROUND_Y + 60, 310, 34, 0, 0, 7); g.stroke();
  // reading desk (behind the player)
  g.fillStyle = '#6a4524'; g.fillRect(700, 760, 280, 20);
  g.fillRect(716, 780, 20, 120); g.fillRect(944, 780, 20, 120);
  g.fillStyle = '#9a6a3a'; g.fillRect(700, 752, 280, 12);
  // lamp + books on desk
  g.fillStyle = '#e8c36a'; g.beginPath(); g.moveTo(900, 752); g.lineTo(950, 752); g.lineTo(938, 690); g.lineTo(912, 690); g.fill();
  g.fillStyle = '#2b4c8c'; g.fillRect(730, 722, 90, 30); g.fillStyle = '#7a2230'; g.fillRect(738, 696, 74, 26);
  g.fillStyle = '#f4ecd0'; g.fillRect(826, 736, 56, 16);
  // small wall shelf for the old book
  g.fillStyle = '#6a4524'; g.fillRect(1180, 640, 220, 18);
  g.fillStyle = '#2f6b4a'; g.fillRect(1190, 590, 24, 50); g.fillStyle = '#8a6a1f'; g.fillRect(1216, 600, 22, 40);
  return c;
}

export function drawRoomDynamic(ctx, t, open, bookGlow) {
  // old book on shelf
  const bx = 1300, by = 640;
  ctx.save();
  if (bookGlow) {
    const g = ctx.createRadialGradient(bx, by - 25, 5, bx, by - 25, 110);
    g.addColorStop(0, `rgba(255,225,120,${0.55 + Math.sin(t * 4) * 0.25})`); g.addColorStop(1, 'rgba(255,225,120,0)');
    ctx.fillStyle = g; ctx.beginPath(); ctx.arc(bx, by - 25, 110, 0, 7); ctx.fill();
  }
  ctx.fillStyle = '#5a2a7a'; ctx.fillRect(bx - 34, by - 56, 68, 56);
  ctx.fillStyle = '#e8c36a'; ctx.fillRect(bx - 34, by - 56, 68, 6); ctx.fillRect(bx - 34, by - 6, 68, 6);
  ctx.fillStyle = '#ffd873'; ctx.beginPath(); ctx.arc(bx, by - 28, 12, 0, 7); ctx.fill();
  ctx.restore();

  // big bookcase on the right with the secret panel
  const cx = 1500, cw = 380, top = 150;
  ctx.fillStyle = '#5a3a1a'; ctx.fillRect(cx, top, cw, GROUND_Y - top);
  // passage behind the sliding panel
  const px = 1600, pw = 180, ptop = 470;
  const gl = ctx.createLinearGradient(0, ptop, 0, GROUND_Y);
  gl.addColorStop(0, '#0b1230'); gl.addColorStop(1, '#2a5cc4');
  ctx.fillStyle = gl; ctx.beginPath(); ctx.roundRect(px, ptop, pw, GROUND_Y - ptop, [90, 90, 0, 0]); ctx.fill();
  if (open > 0.05) {
    ctx.save(); ctx.globalAlpha = open * (0.5 + Math.sin(t * 3) * 0.15); ctx.fillStyle = '#7fb6ff';
    ctx.beginPath(); ctx.roundRect(px + 20, ptop + 40, pw - 40, GROUND_Y - ptop - 40, [70, 70, 0, 0]); ctx.fill(); ctx.restore();
  }
  // shelves (with the sliding panel lifting up)
  const r = rng(33);
  const shelves = (y0, y1, x0, x1, off) => {
    ctx.save(); ctx.beginPath(); ctx.rect(x0, y0, x1 - x0, y1 - y0); ctx.clip(); ctx.translate(0, off);
    for (let row = 0; row < 8; row++) {
      const ry = top + 14 + row * 92;
      ctx.fillStyle = '#7a5230'; ctx.fillRect(x0, ry + 78, x1 - x0, 12);
      let x = x0 + 8;
      while (x < x1 - 14) { const bw = 14 + r() * 16, bh = 46 + r() * 28; ctx.fillStyle = BOOK_COLORS[(r() * 8) | 0]; ctx.fillRect(x, ry + 78 - bh, bw, bh); x += bw + 2; }
    }
    ctx.restore();
  };
  ctx.fillStyle = '#7a5230';
  shelves(top, GROUND_Y, cx + 10, px, 0);
  shelves(top, GROUND_Y, px + pw, cx + cw - 10, 0);
  shelves(top, ptop, px, px + pw, 0);
  // sliding panel: covers the passage until opened
  const slide = open * (GROUND_Y - ptop + 20);
  ctx.save(); ctx.beginPath(); ctx.rect(px, ptop - slide * 0, pw, GROUND_Y - ptop); ctx.clip();
  ctx.translate(0, -slide);
  ctx.fillStyle = '#5a3a1a'; ctx.fillRect(px, ptop, pw, GROUND_Y - ptop);
  for (let row = 0; row < 5; row++) {
    const ry = ptop + row * 92 + 6; ctx.fillStyle = '#7a5230'; ctx.fillRect(px, ry + 78, pw, 12);
    let x = px + 6; while (x < px + pw - 14) { const bw = 14 + r() * 14, bh = 46 + r() * 26; ctx.fillStyle = BOOK_COLORS[(r() * 8) | 0]; ctx.fillRect(x, ry + 78 - bh, bw, bh); x += bw + 2; }
  }
  ctx.restore();
  ctx.strokeStyle = '#3a220c'; ctx.lineWidth = 8; ctx.strokeRect(cx, top, cw, GROUND_Y - top);
}

export function drawRuneBig(ctx, cx, cy, size, t, color = '#ffd873') {
  ctx.save(); ctx.translate(cx, cy); ctx.strokeStyle = color; ctx.lineWidth = size * 0.05; ctx.lineCap = 'round';
  ctx.shadowColor = color; ctx.shadowBlur = 30;
  ctx.beginPath(); ctx.arc(0, 0, size, 0, 7); ctx.stroke();
  ctx.beginPath(); ctx.arc(0, 0, size * 0.62, 0, 7); ctx.stroke();
  ctx.rotate(t * 0.5);
  for (let i = 0; i < 6; i++) { ctx.rotate(Math.PI / 3); ctx.beginPath(); ctx.moveTo(0, -size * 0.62); ctx.lineTo(size * 0.18, -size * 0.35); ctx.lineTo(0, -size * 0.08); ctx.stroke(); }
  ctx.restore();
}

// --------------------------------------------------------------------------------------------
// Particles
// --------------------------------------------------------------------------------------------
export class Particles {
  constructor() { this.list = []; }
  burst(x, y, n, { color = '#9ff', speed = 300, life = 0.8, size = 6, grav = 300 } = {}) {
    for (let i = 0; i < n; i++) {
      const a = Math.random() * Math.PI * 2, s = speed * (0.3 + Math.random() * 0.7);
      this.list.push({ x, y, vx: Math.cos(a) * s, vy: Math.sin(a) * s, life, max: life, color, size: size * (0.5 + Math.random()), grav });
    }
  }
  update(dt) {
    for (const p of this.list) { p.life -= dt; p.vy += p.grav * dt; p.x += p.vx * dt; p.y += p.vy * dt; }
    this.list = this.list.filter((p) => p.life > 0);
  }
  draw(ctx, camX = 0) {
    ctx.save(); ctx.globalCompositeOperation = 'lighter';
    for (const p of this.list) { ctx.globalAlpha = Math.max(0, p.life / p.max); ctx.fillStyle = p.color; ctx.beginPath(); ctx.arc(p.x - camX, p.y, p.size, 0, 7); ctx.fill(); }
    ctx.restore();
  }
}
