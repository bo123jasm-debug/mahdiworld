import { World } from './world.js';
import { Player } from './player.js';
import { ROOM, LIBRARY, GROUND_Y } from './levels.js';
import * as R from './render.js';
import { clamp, lerp, sleep } from '../engine/util.js';
import { runMemory } from '../puzzles/memory.js';
import { runClassify } from '../puzzles/classify.js';
import { runReview } from '../puzzles/review.js';

const W = 1920, H = 1080;

/**
 * Stage 1 «سر المكتبة القديمة» — six scenes:
 * 1 room intro · 2 old book + secret door · 3 transform & enter · 4 three challenges · 5 keys + final door · 6 review + star
 */
export class Stage1 {
  constructor(game) {
    this.g = game;
    this.curr = game.curriculum;
    this.lessons = Object.fromEntries(this.curr.lessons.map((l) => [l.id, l]));
    this.far = R.makeLibraryFar();
    this.mid = R.makeLibraryMid();
    this.roomBack = R.makeRoomBack();
    this.particles = new R.Particles();
    this.player = new Player(game.assets, game.audio);
    this.t = 0;
    this.camX = 0;
    this.scene = 'none';
    this.cine = null;
    this.state = this.freshState();
  }

  freshState() {
    return {
      read: false, bookOpened: false, passageOpen: 0, passageTarget: 0, transformed: false,
      keys: new Set(), sparks: new Set(), tabletSolved: false, companionDone: false,
      doorOpen: 0, doorOpening: false, checkpoint: null, finished: false, reviewMistakes: 0,
      retried: false, entered: false,
    };
  }

  // ------------------------------------------------------------------ lifecycle
  async begin({ fresh }) {
    const g = this.g;
    this.state = this.freshState();
    this.g.refreshHud();
    this.setupRoom();
    g.ui.showHud(true);
    g.ui.setKeys(0);
    g.ui.hide();
    if (fresh) {
      await g.ui.dialog('', this.curr.story.intro);
    }
    this.setGoal('اذهب إلى مكتب القراءة، ثم اضغط «تفاعل».');
  }

  setupRoom() {
    this.scene = 'room';
    this.world = new World(ROOM);
    this.barrier = { x: ROOM.barrierX, y: 0, w: 40, h: GROUND_Y };
    this.world.solids.push(this.barrier);
    this.player.respawn(ROOM.start.x, ROOM.start.y);
    this.player.setMode(this.state.transformed ? 'ninja' : 'normal');
    this.player.locked = false; this.player.pose = null;
    this.camX = 0;
    this.interactables = ROOM.interactables;
  }

  setupLibrary() {
    this.scene = 'library';
    this.world = new World(LIBRARY);
    this.player.respawn(LIBRARY.start.x, LIBRARY.start.y);
    this.player.setMode('ninja');
    this.player.doubleJumpUnlocked = !!this.g.save.stage('stage1').done;
    this.player.locked = false; this.player.pose = null;
    this.camX = 0;
    this.interactables = LIBRARY.interactables;
    this.state.checkpoint = { ...LIBRARY.start };
    this.state.entered = true;
    this.g.ui.setKeys(this.state.keys.size);
    this.setGoal('استكشف الممرات وابحث عن 3 مفاتيح للمعرفة.');
  }

  setGoal(t) { this.g.ui.setGoal(t); }

  // ------------------------------------------------------------------ update
  update(dt) {
    const g = this.g;
    this.t += dt;
    this.particles.update(dt);

    if (this.cine) { this.updateCine(dt); return; }

    // passage animation in room
    const s = this.state;
    if (this.scene === 'room') {
      s.passageOpen = lerp(s.passageOpen, s.passageTarget, 1 - Math.pow(0.02, dt));
      if (s.passageTarget === 1 && this.barrier && s.passageOpen > 0.95) {
        this.world.solids = this.world.solids.filter((x) => x !== this.barrier); this.barrier = null;
      }
    }
    if (this.scene === 'library' && s.doorOpening) s.doorOpen = Math.min(1, s.doorOpen + dt * 0.7);

    this.world.updateCrates(dt);
    this.player.update(dt, g.input, this.world);
    const p = this.player;

    // camera
    const targetX = clamp(p.x - W / 2 + p.facing * 120, 0, Math.max(0, this.world.width - W));
    this.camX = lerp(this.camX, targetX, 1 - Math.pow(0.0005, dt));

    if (this.scene === 'room') this.updateRoom(dt);
    else if (this.scene === 'library') this.updateLibrary(dt);

    // nearest interactable prompt
    let near = null;
    if (!p.locked && g.input.enabled) {
      for (const it of this.interactables) {
        if (!this.isInteractable(it)) continue;
        if (Math.abs(it.x - p.x) < 140 && (!near || Math.abs(it.x - p.x) < Math.abs(near.x - p.x))) near = it;
      }
    }
    this.near = near;
    if (near) g.ui.setPrompt(`${near.label}  (E)`, near.x - this.camX, GROUND_Y - 270);
    else if (this.scene === 'room' && s.passageOpen > 0.95 && !s.transformed) g.ui.setPrompt(null);
    else g.ui.setPrompt(null);

    this.cool = Math.max(0, (this.cool || 0) - dt);
    if (near && this.cool === 0 && g.input.pressed('interact')) this.interact(near);
    g.ui.glowTransform(this.scene === 'room' && s.passageTarget === 1 && !s.transformed);
    if (g.input.pressed('transform')) this.tryTransform();
  }

  isInteractable(it) {
    const s = this.state;
    if (this.scene === 'room') {
      if (it.id === 'oldbook') return s.read && !s.bookOpened;
      return true;
    }
    if (it.id === 'tablet') return !s.tabletSolved;
    if (it.id === 'companion') return !s.companionDone;
    return true;
  }

  updateRoom() {
    const p = this.player, s = this.state;
    if (s.transformed && s.passageOpen > 0.95 && p.x > ROOM.passageX && !s.entering) {
      s.entering = true;
      this.enterLibrary();
    }
  }

  async enterLibrary() {
    const g = this.g;
    g.ui.setPrompt(null);
    this.player.locked = true;
    await g.ui.fade(() => { this.setupLibrary(); this.state.entering = false; });
    await g.ui.dialog('حارس الأوهام', this.curr.story.guardian.slice(0, 1));
    await g.ui.dialog('مهدي', this.curr.story.guardian.slice(1));
  }

  updateLibrary(dt) {
    const p = this.player, s = this.state;
    // checkpoints
    for (const c of LIBRARY.checkpoints) if (p.x > c.x && (!s.checkpoint || c.x > s.checkpoint.x)) s.checkpoint = { ...c };
    // sparks
    for (const sp of LIBRARY.sparks) {
      if (s.sparks.has(sp.id)) continue;
      if (Math.hypot(sp.x - p.x, sp.y - (p.y - 90)) < 80) {
        s.sparks.add(sp.id); this.g.audio.play('collect');
        this.particles.burst(sp.x, sp.y, 14, { color: '#9ff', speed: 260, life: 0.7 });
        this.g.save.data.sparks = Math.max(this.g.save.data.sparks, s.sparks.size); this.g.save.commit();
        this.g.refreshHud();
      }
    }
    // key 1
    for (const k of LIBRARY.keys) {
      if (s.keys.has(k.id)) continue;
      if (Math.hypot(k.x - p.x, k.y - (p.y - 90)) < 90) this.collectKey(k.id, k.x, k.y, k.lesson);
    }
    // falling
    if (p.y > 1400) {
      const c = s.checkpoint || LIBRARY.start;
      p.respawn(c.x, c.y - 4);
      s.retried = true;
      this.g.audio.play('wrong');
      this.g.ui.setGoal('لا بأس! عدنا إلى آخر نقطة آمنة. حاول من جديد.');
      setTimeout(() => this.setGoal('استكشف الممرات وابحث عن 3 مفاتيح للمعرفة.'), 2600);
    }
  }

  collectKey(id, x, y, lessonId) {
    const s = this.state, g = this.g;
    if (s.keys.has(id)) return;
    s.keys.add(id);
    g.audio.play('key');
    this.particles.burst(x ?? this.player.x, y ?? this.player.y - 100, 40, { color: '#ffd873', speed: 420, life: 1.1, size: 7 });
    g.ui.setKeys(s.keys.size);
    g.save.addXp(20);
    if (lessonId === 's1-movement') { g.save.attempt('s1-movement', true); }
    this.setGoal(s.keys.size >= 3 ? 'عندك المفاتيح الثلاثة! اذهب إلى الباب الكبير.' : `مفاتيح المعرفة: ${s.keys.size} من 3`);
  }

  // ------------------------------------------------------------------ interactions
  async interact(it) {
    try { await this.doInteract(it); } finally { this.cool = 0.5; }
  }

  async doInteract(it) {
    const g = this.g, s = this.state, p = this.player;
    if (p.locked) return;
    g.audio.unlock();
    if (this.scene === 'room') {
      if (it.id === 'desk' && !s.read) {
        p.locked = true; p.pose = 'read'; p.vx = 0;
        await g.ui.dialog('مهدي', this.curr.story.deskRead);
        p.locked = false; p.pose = null; s.read = true;
        this.setGoal('افحص الكتاب القديم الذي يلمع على الرف.');
      } else if (it.id === 'desk') {
        await g.ui.dialog('مهدي', ['«بداية المعرفة»... كتاب يفتح أبواب التفكير.']);
      } else if (it.id === 'oldbook') {
        p.locked = true; p.vx = 0;
        await this.runeScene();
        s.bookOpened = true; s.passageTarget = 1;
        g.audio.play('door');
        await sleep(1400);
        await g.ui.dialog('مهدي', this.curr.story.oldBook.slice(1));
        p.locked = false;
        this.setGoal(this.curr.story.transformHint);
        g.ui.glowTransform(true);
      }
      return;
    }
    // library
    if (it.id === 'tablet') {
      p.locked = true; p.vx = 0;
      const ok = await runMemory(g, this.lessons['s1-memory']);
      p.locked = false;
      if (ok) {
        s.tabletSolved = true; g.save.addXp(25); g.save.addBadge('focus');
        if (this.lessons['s1-memory'] && g.save.lesson('s1-memory').wrong > 0) { g.save.addBadge('persist'); }
        this.collectKey('key2', it.x, GROUND_Y - 220);
      }
    } else if (it.id === 'companion') {
      p.locked = true; p.vx = 0;
      await g.ui.dialog('رفيق المعرفة', ['مرحباً يا مهدي! عندي لغز صغير لك.', 'كل جملة تحتاج مكاناً. هيا نرتّبها معاً!']);
      const ok = await runClassify(g, this.lessons['s1-observe']);
      p.locked = false;
      if (ok) {
        s.companionDone = true; g.save.addXp(30); g.save.addBadge('thinker');
        if (g.save.lesson('s1-observe').wrong > 0) g.save.addBadge('persist');
        this.collectKey('key3', it.x, GROUND_Y - 220);
      }
    } else if (it.id === 'door') {
      if (s.doorOpening) return;
      if (s.keys.size < 3) {
        p.locked = true; p.vx = 0;
        await g.ui.dialog('مهدي', [`الباب يحتاج إلى 3 مفاتيح. معي ${s.keys.size} فقط.`, 'سأواصل البحث عن مفاتيح المعرفة.']);
        p.locked = false;
      } else {
        p.locked = true; p.vx = 0; s.doorOpening = true;
        g.audio.play('door');
        this.particles.burst(it.x, GROUND_Y - 200, 60, { color: '#ffd873', speed: 500, life: 1.4 });
        await sleep(2000);
        await this.finish();
      }
    }
  }

  async runeScene() {
    const g = this.g;
    const t0 = this.t;
    this.cine = { type: 'rune', t: 0, dur: 2.4 };
    g.audio.play('key');
    g.ui.setPrompt(null);
    while (this.cine) await sleep(50);
    await g.ui.dialog('مهدي', this.curr.story.oldBook.slice(0, 1));
  }

  // ------------------------------------------------------------------ transform
  tryTransform() {
    const s = this.state, g = this.g;
    if (this.cine || this.player.locked) return;
    if (this.scene !== 'room' || this.player.mode === 'ninja') return;
    if (!s.bookOpened) { g.ui.setGoal('اكتشف سرّ الكتاب القديم أولاً.'); return; }
    g.audio.unlock();
    this.player.locked = true; this.player.vx = 0;
    g.ui.setPrompt(null);
    g.audio.play('transform');
    this.cine = { type: 'transform', t: 0, dur: 3.2 };
  }

  updateCine(dt) {
    const c = this.cine;
    c.t += dt;
    if (c.type === 'transform') {
      if (Math.random() < 0.7) {
        const a = Math.random() * Math.PI * 2;
        this.particles.burst(W / 2 + Math.cos(a) * 280, H / 2 + Math.sin(a) * 280, 1, { color: '#7fb6ff', speed: 120, life: 1.0, size: 6, grav: -60 });
      }
      if (c.t >= c.dur) {
        this.cine = null;
        this.player.setMode('ninja'); this.player.locked = false;
        this.state.transformed = true;
        this.particles.burst(this.player.x, this.player.y - 90, 50, { color: '#7fb6ff', speed: 500, life: 0.9 });
        this.setGoal('ادخل الممر السري على اليمين.');
      }
    } else if (c.type === 'rune' && c.t >= c.dur) {
      this.cine = null;
    }
  }

  // ------------------------------------------------------------------ finish & review
  async finish() {
    const g = this.g, s = this.state;
    await g.ui.fade(() => { this.scene = 'end'; g.ui.showHud(false); g.ui.setPrompt(null); });
    const items = this.curr.review;
    const { mistakes } = await runReview(g, items);
    s.reviewMistakes = mistakes;

    // stars reward learning & perseverance, not speed
    let stars = 1;                                   // completed the stage
    if (mistakes <= items.length) stars++;           // understood the review (a retry per question is fine)
    if (s.sparks.size >= LIBRARY.sparks.length) stars++; // explored everything
    const earned = g.save.stage('stage1');
    this.newSkill = !earned.done;
    earned.done = true; earned.stars = Math.max(earned.stars, stars);
    g.save.data.stars = Object.values(g.save.data.stages).reduce((a, b) => a + b.stars, 0);
    g.save.addXp(40);
    if (s.sparks.size >= LIBRARY.sparks.length) g.save.addBadge('explorer');
    g.save.commit();
    s.finished = true;
    g.audio.play('success');
    this.showResult(stars);
  }

  showResult(stars) {
    const g = this.g;
    const names = { focus: 'شارة التركيز', persist: 'شارة المثابرة', thinker: 'شارة التفكير', explorer: 'شارة المستكشف' };
    const badges = g.save.data.badges.map((b) => names[b]).filter(Boolean);
    const worlds = this.curr.worlds.map((w) => {
      const cls = w.status === 'current' ? 'world cur' : 'world lock';
      return el_('div', { class: cls }, `${w.status === 'current' ? '★ ' : ''}${w.name}`, el_('small', {}, w.status === 'current' ? 'مكتمل' : 'مغلق — قريباً'));
    });
    const mk = (n) => el_('div', { class: 'stars' }, [1, 2, 3].map((i) => el_('span', { class: i <= n ? 'on' : '' }, '★')));
    const box = g.ui.panel(
      el_('h1', {}, 'أحسنت يا مهدي!'),
      el_('p', {}, 'فتحت الباب بمفاتيح المعرفة الثلاثة.'),
      mk(stars),
      el_('p', { class: 'sub' }, `نقاط الخبرة: ${g.save.data.xp} · شرارات المعرفة: ${this.state.sparks.size} من ${LIBRARY.sparks.length}`),
      badges.length ? el_('div', { class: 'badges' }, badges.map((b) => el_('span', { class: 'badge' }, b))) : null,
      el_('p', {}, 'خريطة العوالم'),
      el_('div', { class: 'worlds' }, worlds),
      this.newSkill ? el_('p', {}, 'مهارة جديدة مفتوحة: القفز المزدوج للنينجا! (اضغط قفز مرة ثانية في الهواء)') : null,
      el_('p', { class: 'sub' }, 'العوالم التالية ستُبنى على فصول الكتاب بعد قراءته وتوثيقه.'),
      el_('div', {},
        el_('button', { class: 'btn', onclick: () => { g.openMap(); } }, 'خريطة المغامرة'),
        el_('button', { class: 'btn ghost', onclick: () => { g.toTitle(); } }, 'القائمة الرئيسية'),
        el_('button', { class: 'btn ghost', onclick: () => { g.startStage({ fresh: false }); } }, 'العب المرحلة مرة أخرى'),
      ),
    );
    g.ui.show(box);
  }

  // ------------------------------------------------------------------ render
  render(ctx) {
    const s = this.state, t = this.t;
    ctx.clearRect(0, 0, W, H);
    if (this.scene === 'room') this.renderRoom(ctx);
    else if (this.scene === 'library') this.renderLibrary(ctx);
    else { ctx.fillStyle = '#0b1230'; ctx.fillRect(0, 0, W, H); }
    if (this.cine) this.renderCine(ctx);
  }

  renderRoom(ctx) {
    const s = this.state;
    ctx.drawImage(this.roomBack, 0, 0);
    R.drawRoomDynamic(ctx, this.t, s.passageOpen, s.read && !s.bookOpened);
    this.player.draw(ctx, 0);
    this.particles.draw(ctx, 0);
    // soft vignette
    const g = ctx.createRadialGradient(W / 2, H / 2, 500, W / 2, H / 2, 1200);
    g.addColorStop(0, 'rgba(0,0,0,0)'); g.addColorStop(1, 'rgba(20,10,0,.35)');
    ctx.fillStyle = g; ctx.fillRect(0, 0, W, H);
  }

  renderLibrary(ctx) {
    const s = this.state, t = this.t, cam = this.camX;
    R.drawLibraryBackground(ctx, this.far, this.mid, cam, t);
    for (const z of this.world.climb) R.drawClimbZone(ctx, z, cam);
    LIBRARY.checkpoints.forEach((c) => R.drawCheckpoint(ctx, c, cam, t, s.checkpoint && s.checkpoint.x === c.x));
    for (const so of this.world.solids) R.drawSolid(ctx, so, cam);
    for (const c of this.world.crates) R.drawCrate(ctx, c, cam);
    R.drawTablet(ctx, 4000, cam, t, s.tabletSolved);
    R.drawCompanion(ctx, 4980, cam, t, s.companionDone);
    R.drawDoor(ctx, 5800, cam, s.doorOpen, t);
    for (const sp of LIBRARY.sparks) if (!s.sparks.has(sp.id)) R.drawSpark(ctx, sp, cam, t);
    for (const k of LIBRARY.keys) if (!s.keys.has(k.id)) R.drawKey(ctx, k, cam, t);
    // floor hint text
    ctx.save(); ctx.font = '700 34px "Segoe UI",Tahoma,sans-serif'; ctx.direction = 'rtl'; ctx.textAlign = 'center';
    for (const h of LIBRARY.hints) {
      const x = h.x - cam; if (x < -300 || x > W + 300) continue;
      ctx.fillStyle = 'rgba(255,236,170,.85)'; ctx.fillText(h.text, x, GROUND_Y - 240);
    }
    ctx.restore();
    this.player.draw(ctx, cam);
    this.particles.draw(ctx, cam);
    // ambient motes
    ctx.save(); ctx.globalCompositeOperation = 'lighter';
    for (let i = 0; i < 26; i++) {
      const x = ((i * 211 + t * (10 + (i % 5) * 4) - cam * 0.7) % (W + 100) + W + 100) % (W + 100) - 50;
      const y = 120 + ((i * 97) % 700) + Math.sin(t + i) * 18;
      ctx.fillStyle = `rgba(200,170,255,${0.18 + 0.12 * Math.sin(t * 2 + i)})`; ctx.beginPath(); ctx.arc(x, y, 3 + (i % 3), 0, 7); ctx.fill();
    }
    ctx.restore();
  }

  renderCine(ctx) {
    const c = this.cine, t = this.t;
    if (c.type === 'rune') {
      const k = Math.min(1, c.t / 0.5) * (c.t > c.dur - 0.4 ? (c.dur - c.t) / 0.4 : 1);
      ctx.fillStyle = `rgba(5,8,26,${0.75 * k})`; ctx.fillRect(0, 0, W, H);
      ctx.save(); ctx.globalAlpha = k; R.drawRuneBig(ctx, W / 2, H / 2, 240 * (0.8 + 0.2 * k), t); ctx.restore();
      return;
    }
    // transform: darkened screen, glowing rings, bust frames in sequence
    const k = c.t / c.dur;
    ctx.fillStyle = `rgba(5,8,40,${Math.min(0.85, c.t * 1.5)})`; ctx.fillRect(0, 0, W, H);
    const glow = ctx.createRadialGradient(W / 2, H / 2, 20, W / 2, H / 2, 560);
    glow.addColorStop(0, `rgba(120,180,255,${0.35 + 0.4 * k})`); glow.addColorStop(1, 'rgba(120,180,255,0)');
    ctx.fillStyle = glow; ctx.fillRect(0, 0, W, H);
    ctx.save(); ctx.translate(W / 2, H / 2); ctx.strokeStyle = 'rgba(160,210,255,.9)'; ctx.lineWidth = 6;
    for (let i = 0; i < 3; i++) { ctx.rotate(t * (1 + i * 0.5)); ctx.beginPath(); ctx.ellipse(0, 0, 300 + i * 50 + k * 80, 120 + i * 60, 0, 0, Math.PI * 1.4); ctx.stroke(); }
    ctx.restore();
    const set = this.g.assets.frames.transform;
    const idx = Math.min(set.length - 1, Math.floor(k * set.length));
    const img = set[idx];
    if (img?.naturalWidth) {
      // feather the square panel edges so the bust frames blend into the glow
      const h = 640, w = img.naturalWidth * (h / img.naturalHeight);
      const m = (this.mask ||= document.createElement('canvas'));
      if (m.width !== Math.ceil(w) || m.height !== h) { m.width = Math.ceil(w); m.height = h; }
      const mg = m.getContext('2d');
      mg.globalCompositeOperation = 'source-over'; mg.clearRect(0, 0, m.width, m.height);
      mg.drawImage(img, 0, 0, w, h);
      const rg = mg.createRadialGradient(w / 2, h / 2, Math.min(w, h) * 0.28, w / 2, h / 2, Math.min(w, h) * 0.56);
      rg.addColorStop(0, 'rgba(0,0,0,1)'); rg.addColorStop(1, 'rgba(0,0,0,0)');
      mg.globalCompositeOperation = 'destination-in'; mg.fillStyle = rg; mg.fillRect(0, 0, m.width, m.height);
      ctx.drawImage(m, W / 2 - w / 2, H / 2 - h / 2);
    }
    if (k > 0.82) { ctx.fillStyle = `rgba(255,255,255,${Math.min(1, (k - 0.82) * 5.5) * (k > 0.95 ? (1 - k) * 20 : 1)})`; ctx.fillRect(0, 0, W, H); }
    this.particles.draw(ctx, 0);
  }
}

// local DOM helper (avoids circular import of ui)
function el_(tag, attrs = {}, ...kids) {
  const n = document.createElement(tag);
  for (const [k, v] of Object.entries(attrs || {})) {
    if (v == null || v === false) continue;
    if (k === 'class') n.className = v; else if (k.startsWith('on')) n.addEventListener(k.slice(2), v); else n.setAttribute(k, v);
  }
  for (const kid of kids.flat()) { if (kid == null || kid === false) continue; n.append(kid.nodeType ? kid : document.createTextNode(String(kid))); }
  return n;
}
