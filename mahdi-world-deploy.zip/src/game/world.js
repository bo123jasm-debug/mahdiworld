import { overlap } from '../engine/util.js';

export const GRAVITY = 2700;

/** Static solids, pushable crates and climb zones for one level. */
export class World {
  constructor(def) {
    this.def = def;
    this.width = def.width;
    this.solids = def.solids.map((s) => ({ ...s }));
    this.crates = (def.crates || []).map((c) => ({ ...c, vy: 0, home: { x: c.x, y: c.y } }));
    this.climb = (def.climb || []).map((z) => ({ ...z }));
  }

  /** Move a rect on X, pushing crates. Returns {pushing}. */
  moveX(p, r, dx) {
    r.x += dx;
    let pushing = false;
    for (const s of this.solids) {
      if (overlap(r, s)) { r.x = dx > 0 ? s.x - r.w : s.x + s.w; p.vx = 0; }
    }
    for (const c of this.crates) {
      if (!overlap(r, c)) continue;
      const moved = { x: c.x + dx, y: c.y, w: c.w, h: c.h };
      const blockers = this.solids.concat(this.crates.filter((o) => o !== c));
      if (!blockers.some((s) => overlap(moved, s))) { c.x = moved.x; pushing = true; }
      else { r.x = dx > 0 ? c.x - r.w : c.x + c.w; p.vx = 0; }
    }
    return pushing;
  }

  /** Move a rect on Y. Returns 'ground' | 'ceiling' | null. */
  moveY(p, r, dy) {
    r.y += dy;
    let hit = null;
    for (const s of this.solids.concat(this.crates)) {
      if (!overlap(r, s)) continue;
      if (dy > 0) { r.y = s.y - r.h; hit = 'ground'; }
      else if (dy < 0) { r.y = s.y + s.h; hit = 'ceiling'; }
      p.vy = 0;
    }
    return hit;
  }

  updateCrates(dt) {
    for (const c of this.crates) {
      c.vy += GRAVITY * dt;
      c.y += c.vy * dt;
      for (const s of this.solids) {
        if (overlap(c, s)) { c.y = s.y - c.h; c.vy = 0; }
      }
      if (c.y > 1500) { c.x = c.home.x; c.y = c.home.y; c.vy = 0; }
    }
  }

  climbZoneAt(r) { return this.climb.find((z) => overlap(r, z)) || null; }
}
