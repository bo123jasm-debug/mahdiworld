// Level definitions for stage 1: «سر المكتبة القديمة». Coordinates are design pixels (1920x1080 view).
export const GROUND_Y = 900;

export const ROOM = {
  width: 1920,
  solids: [
    { x: 0, y: GROUND_Y, w: 1920, h: 180, kind: 'floor' },
  ],
  crates: [],
  climb: [],
  start: { x: 330, y: GROUND_Y },
  interactables: [
    { id: 'desk', x: 840, label: 'اقرأ' },
    { id: 'oldbook', x: 1285, label: 'افحص الكتاب' },
  ],
  barrierX: 1590, // invisible wall until the secret passage opens
  passageX: 1720, // walking past this enters the library
};

export const LIBRARY = {
  width: 6200,
  solids: [
    { x: 0, y: GROUND_Y, w: 1400, h: 200, kind: 'ground' },
    // floating books over the first gap
    { x: 1430, y: 830, w: 120, h: 26, kind: 'books', seed: 3 },
    { x: 1580, y: 770, w: 120, h: 26, kind: 'books', seed: 4 },
    { x: 1720, y: GROUND_Y, w: 4480, h: 200, kind: 'ground' },
    // challenge A: the wall that needs the crate
    { x: 2700, y: 650, w: 70, h: 250, kind: 'wall' },
    // ledge holding the first knowledge key (reached by the bookshelf ladder)
    { x: 3040, y: 560, w: 330, h: 30, kind: 'books', seed: 9 },
    // optional platforms with sparks
    { x: 3560, y: 770, w: 150, h: 26, kind: 'books', seed: 11 },
    { x: 3780, y: 650, w: 150, h: 26, kind: 'books', seed: 12 },
    { x: 4520, y: 740, w: 170, h: 26, kind: 'books', seed: 14 },
  ],
  crates: [{ x: 2300, y: GROUND_Y - 130, w: 130, h: 130 }],
  climb: [{ x: 2900, y: 540, w: 110, h: 360, exitDir: 1 }],
  checkpoints: [
    { x: 1790, y: GROUND_Y },
    { x: 3300, y: GROUND_Y },
    { x: 4560, y: GROUND_Y },
  ],
  start: { x: 140, y: GROUND_Y },
  sparks: [
    { id: 'sp1', x: 1635, y: 690 },
    { id: 'sp2', x: 3635, y: 690 },
    { id: 'sp3', x: 3855, y: 570 },
    { id: 'sp4', x: 4605, y: 660 },
    { id: 'sp5', x: 3300, y: 490 },
  ],
  keys: [{ id: 'key1', x: 3150, y: 490, lesson: 's1-movement' }],
  interactables: [
    { id: 'tablet', x: 4000, label: 'افحص اللوح' },
    { id: 'companion', x: 4980, label: 'تحدّث' },
    { id: 'door', x: 5800, label: 'افتح الباب' },
  ],
  hints: [
    { x: 2230, text: 'ادفع الصندوق بالمشي نحوه' },
  ],
};
