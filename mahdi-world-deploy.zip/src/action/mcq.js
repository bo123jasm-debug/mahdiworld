import { el, sleep } from '../engine/util.js';

const LETTERS = ['أ', 'ب', 'ج'];
export const CAT_NAMES = {
  math: 'الحساب', arabic: 'اللغة العربية', memory: 'الذاكرة', focus: 'التركيز', logic: 'المنطق',
  general: 'معلومات عامة', book: 'من كتاب «بداية المعرفة»',
};

/** Question bank = data/questions.json (team-written) + the quiz items of the book lessons (kept with their page refs). */
export function buildBank(questions, bookList) {
  const bank = questions.questions.map((q) => ({ ...q }));
  for (const l of bookList) {
    l.adventure.quiz.forEach((q, i) => bank.push({
      id: `book:${l.id}:${i}`, cat: 'book', level: 1, q: q.question, options: q.options.slice(0, 3), answer: q.answer,
      explain: q.explanation, hint: q.hint, pageRef: l.pageRef, reviewStatus: l.reviewStatus, source: l.source,
    }));
  }
  return bank;
}

const shuffle = (a) => { const r = [...a]; for (let i = r.length - 1; i > 0; i--) { const j = Math.floor(Math.random() * (i + 1)); [r[i], r[j]] = [r[j], r[i]]; } return r; };

/** Picks a question of a category, avoiding recently used ones. */
export function pickQuestion(game, cat, level = 3) {
  const used = (game.usedQ ||= new Set());
  let pool = game.bank.filter((q) => q.cat === cat && q.level <= level);
  if (!pool.length) pool = game.bank.filter((q) => q.cat === cat);
  let fresh = pool.filter((q) => !used.has(q.id));
  if (!fresh.length) { pool.forEach((q) => used.delete(q.id)); fresh = pool; }
  const q = fresh[Math.floor(Math.random() * fresh.length)];
  used.add(q.id);
  return q;
}

/**
 * Shows one three-option question. Wrong picks call opts.onWrong() (the game takes a star / some energy), show a short
 * explanation and let the child try again; the child always ends up at the right answer, so no level can dead-end.
 * Resolves { firstTry, tries, cat }.
 */
export function askQuestion(game, q, { title = 'سؤال المعرفة', reward = '' } = {}) {
  const { ui, audio, save } = game;
  return new Promise((resolve) => {
    let tries = 0, locked = false;
    // options are shuffled for every showing, the right one is tracked by text
    const rightText = q.options[q.answer];
    const opts = shuffle(q.options);
    const fb = el('div', { class: 'fb' }, '');
    const showBox = q.show ? el('div', { class: 'show' }, q.show) : null;
    const list = el('div', { class: 'choices' });
    const stats = save.data.action;
    const bump = (ok) => {
      const c = (stats.byCat[q.cat] ||= { right: 0, wrong: 0 });
      ok ? (c.right++, stats.correct++) : (c.wrong++, stats.wrong++);
      save.commit();
    };
    opts.forEach((text, i) => {
      const b = el('button', { class: 'choice', 'data-text': text }, el('b', {}, LETTERS[i]), el('span', {}, text));
      b.onclick = async () => {
        if (locked || b.disabled) return;
        audio.unlock();
        if (text === rightText) {
          locked = true; b.classList.add('good'); audio.play('ok'); bump(true);
          list.querySelectorAll('button').forEach((x) => (x.disabled = true));
          fb.textContent = '✔ ' + q.explain + (q.pageRef ? ` (من الكتاب ص ${q.pageRef})` : '');
          await sleep(900);
          const go = el('button', { class: 'btn', onclick: () => { ui.hide(); resolve({ firstTry: tries === 0, tries, cat: q.cat }); } }, reward ? 'خذ المكافأة' : 'متابعة');
          panel.append(go);
        } else {
          tries++; b.classList.add('bad'); b.disabled = true; audio.play('wrong'); bump(false);
          const note = game.onWrongAnswer?.() || '';
          fb.textContent = '✖ ' + (tries >= 2 ? `الإجابة الصحيحة: «${rightText}». ${q.explain}` : (q.hint || 'ليست هذه. جرّب مرة أخرى، ستنجح!')) + (note ? `  (${note})` : '');
        }
      };
      list.append(b);
    });
    const hdr = [el('span', { class: 'cat' }, CAT_NAMES[q.cat] || ''), el('h2', {}, title)];
    const panel = ui.panel(
      ...hdr,
      q.source ? el('div', { class: 'tag book' }, `مبسّط من الكتاب ص ${q.pageRef} — بانتظار المراجعة العلمية`) : null,
      reward ? el('div', { class: 'reward' }, reward) : null,
      el('div', { class: 'q' }, q.q), showBox, list, fb);
    panel.classList.add('mcq');
    if (q.show && q.showMs) {
      // memory question: show the sequence first, then hide it and reveal the choices
      list.style.visibility = 'hidden';
      ui.show(panel);
      fb.textContent = 'تذكّر جيداً…';
      setTimeout(() => { showBox.textContent = '❓'; list.style.visibility = ''; fb.textContent = ''; }, q.showMs);
    } else ui.show(panel);
  });
}
