import { rng } from '../engine/util.js';

// ----------------------------------------------------------------------------------------------------------
// Procedural placeholder art for the action stages. Everything here is meant to be replaced by hand-painted
// sprites / backgrounds (see docs/ASSETS_NEEDED.md). Layered parallax, drawn in 1080x1920 screen space.
// ----------------------------------------------------------------------------------------------------------
const VW = 1080, VH = 1920;
const cv = (w, h) => { const c = document.createElement('canvas'); c.width = w; c.height = h; return c; };
const rr = (g, x, y, w, h, r) => { g.beginPath(); g.roundRect(x, y, w, h, r); };

const THEMES = {
  city: {
    sky: ['#0a0726', '#1b1250', '#3a1f73', '#8a3b8f', '#ff9a7a'], tile: 2160,
    ground: ['#3a3f66', '#262a4c', '#14172e'], line: '#8d93d6', plat: ['#4b4f80', '#2b2e55'], mote: '255,220,180',
    far(g, r, W) {
      for (let i = 0; i < 140; i++) { g.fillStyle = `rgba(255,255,255,${0.3 + r() * 0.6})`; const s = 2 + r() * 3; g.fillRect(r() * W, r() * 900, s, s); }
      g.fillStyle = '#fff4d0'; g.beginPath(); g.arc(W * 0.7, 420, 120, 0, 7); g.fill();
      g.fillStyle = 'rgba(255,244,208,.14)'; g.beginPath(); g.arc(W * 0.7, 420, 230, 0, 7); g.fill();
      g.fillStyle = '#251a5a';
      for (let x = 0; x < W; x += 90) { const h = 260 + r() * 520; g.fillRect(x, VH - 420 - h, 84, h + 420); }
    },
    mid(g, r, W) {
      for (let x = 0; x < W; x += 170) {
        const h = 380 + r() * 620, y = VH - 300 - h;
        g.fillStyle = '#17123d'; g.fillRect(x, y, 160, h + 300);
        for (let wy = y + 30; wy < y + h; wy += 60) for (let wx = x + 20; wx < x + 140; wx += 40) {
          if (r() < 0.45) { g.fillStyle = r() < 0.2 ? '#7fe3ff' : '#ffd873'; g.fillRect(wx, wy, 20, 28); }
        }
        if (r() < 0.3) { g.strokeStyle = '#17123d'; g.lineWidth = 5; g.beginPath(); g.moveTo(x + 80, y); g.lineTo(x + 80, y - 90); g.stroke(); g.fillStyle = '#ff5d6e'; g.beginPath(); g.arc(x + 80, y - 92, 7, 0, 7); g.fill(); }
      }
    },
    near(g, r, W) {
      for (let x = 60; x < W; x += 420 + r() * 260) {
        g.fillStyle = '#0d0a26';
        if (r() < 0.5) { g.fillRect(x, VH - 760, 120, 100); g.fillRect(x + 20, VH - 660, 12, 120); g.fillRect(x + 88, VH - 660, 12, 120); }
        else { g.fillRect(x + 50, VH - 900, 8, 260); g.fillRect(x, VH - 880, 110, 6); g.fillRect(x + 20, VH - 840, 70, 6); }
      }
    },
  },
  tunnel: {
    sky: ['#0b0a14', '#1a1426', '#241a36', '#2b1e3d'], tile: 2160,
    ground: ['#6b5a7a', '#463a55', '#24192f'], line: '#b49ad0', plat: ['#6a5a78', '#3a2d48'], mote: '150,230,255',
    far(g, r, W) {
      g.fillStyle = '#0f0b1a'; g.fillRect(0, 0, W, VH);
      for (let x = 0; x < W; x += 140) { const h = 150 + r() * 380; g.fillStyle = '#17112a'; g.beginPath(); g.moveTo(x, 0); g.lineTo(x + 70, h); g.lineTo(x + 140, 0); g.fill(); }
      for (let x = 0; x < W; x += 260) { g.fillStyle = '#17112a'; const h = 300 + r() * 500; g.beginPath(); g.moveTo(x, VH); g.lineTo(x + 110, VH - h); g.lineTo(x + 220, VH); g.fill(); }
    },
    mid(g, r, W) {
      for (let x = 40; x < W; x += 200 + r() * 140) {
        const base = VH - 280 - r() * 160, col = r() < 0.5 ? ['#7fe3ff', '#2aa6c9'] : ['#ff8ae6', '#a2399a'];
        for (let k = 0; k < 4; k++) {
          const h = 80 + r() * 190, w = 26 + r() * 22, ox = (k - 1.5) * 34;
          const gr = g.createLinearGradient(0, base - h, 0, base); gr.addColorStop(0, col[0]); gr.addColorStop(1, col[1]);
          g.fillStyle = gr; g.beginPath(); g.moveTo(x + ox, base); g.lineTo(x + ox + w / 2, base - h); g.lineTo(x + ox + w, base); g.fill();
        }
        const rg = g.createRadialGradient(x, base - 80, 8, x, base - 80, 190); rg.addColorStop(0, col[0] + '55'); rg.addColorStop(1, '#0000');
        g.fillStyle = rg; g.fillRect(x - 200, base - 280, 400, 400);
      }
    },
    near(g, r, W) {
      for (let x = 0; x < W; x += 330 + r() * 200) {
        g.fillStyle = '#0a0713'; g.fillRect(x, 0, 36 + r() * 40, 260 + r() * 360);
        g.fillStyle = '#0a0713'; g.fillRect(x + 100, VH - 700, 60, 460);
      }
    },
  },
  castle: {
    sky: ['#05030f', '#120a2a', '#2a1448', '#4a2060'], tile: 2160,
    ground: ['#6e6a8e', '#45425f', '#222038'], line: '#aaa6d6', plat: ['#5c5880', '#34314f'], mote: '200,160,255',
    far(g, r, W) {
      for (let i = 0; i < 120; i++) { g.fillStyle = `rgba(255,255,255,${0.2 + r() * 0.6})`; const s = 2 + r() * 3; g.fillRect(r() * W, r() * 800, s, s); }
      g.fillStyle = '#e8dcff'; g.beginPath(); g.arc(W * 0.3, 360, 100, 0, 7); g.fill();
      g.fillStyle = 'rgba(232,220,255,.12)'; g.beginPath(); g.arc(W * 0.3, 360, 220, 0, 7); g.fill();
      g.fillStyle = '#150d30';
      [[180, 700, 200], [700, 560, 240], [1300, 780, 180], [1800, 620, 220]].forEach(([x, y, w]) => {
        g.fillRect(x, y, w, VH - y); g.beginPath(); g.moveTo(x - 14, y); g.lineTo(x + w / 2, y - 190); g.lineTo(x + w + 14, y); g.fill();
        g.fillStyle = '#ffd873'; g.fillRect(x + w / 2 - 12, y + 70, 24, 56); g.fillStyle = '#150d30';
      });
    },
    mid(g, r, W) {
      for (let x = 0; x < W; x += 240) {
        g.fillStyle = '#1d1440'; const h = 520 + r() * 340; g.fillRect(x, VH - 300 - h, 200, h + 300);
        for (let by = VH - 300 - h; by < VH; by += 22) { g.fillStyle = 'rgba(0,0,0,.25)'; g.fillRect(x, by, 200, 3); }
        for (let tx = x; tx < x + 200; tx += 50) { g.fillStyle = '#1d1440'; g.fillRect(tx, VH - 300 - h - 24, 30, 26); }
        g.fillStyle = '#3a2a6e'; rr(g, x + 74, VH - 300 - h + 110, 52, 90, [26, 26, 0, 0]); g.fill();
      }
    },
    near(g, r, W) {
      for (let x = 100; x < W; x += 520 + r() * 220) { g.fillStyle = '#0b0720'; g.fillRect(x, VH - 880, 26, 420); g.fillRect(x - 24, VH - 900, 74, 28); }
    },
  },
};

const cache = {};
export function getActionTheme(name) {
  if (cache[name]) return cache[name];
  const T = THEMES[name];
  const W = T.tile, mk = (fn, seed, bg) => { const c = cv(W, VH), g = c.getContext('2d'); if (bg) { g.fillStyle = bg; g.fillRect(0, 0, W, VH); } fn(g, rng(seed), W); return c; };
  const sky = cv(8, VH), sg = sky.getContext('2d'); const gr = sg.createLinearGradient(0, 0, 0, VH);
  T.sky.forEach((c, i) => gr.addColorStop(i / (T.sky.length - 1), c)); sg.fillStyle = gr; sg.fillRect(0, 0, 8, VH);
  return (cache[name] = { ...T, name, skyImg: sky, far: mk(T.far, 7), mid: mk(T.mid, 21), near: mk(T.near, 33), farFn: null });
}

/** Background in screen space. camX/camY are world coordinates of the view's top-left (before zoom). */
export function drawActionBackground(ctx, th, camX, camY, t) {
  ctx.fillStyle = th.sky[0]; ctx.fillRect(0, -700, VW, 720);
  ctx.drawImage(th.skyImg, 0, 0, VW, VH);
  const layer = (img, par, yShift, alpha = 1) => {
    const W = th.tile, x = -(((camX * par) % W) + W) % W;
    ctx.globalAlpha = alpha;
    for (let px = x; px < VW; px += W) ctx.drawImage(img, px, yShift - camY * par * 0.25);
    ctx.globalAlpha = 1;
  };
  // far layer drawn with a taller-than-screen offset so parallax up/down never exposes empty sky
  layer(th.far, 0.06, 0); layer(th.mid, 0.22, 60); layer(th.near, 0.5, 120);
  if (th.name === 'castle') { // slow drifting fog bands
    for (let i = 0; i < 3; i++) {
      const y = 900 + i * 280 - camY * 0.08, x = ((t * 14 * (i + 1) + i * 400) % 1600) - 400;
      const g = ctx.createLinearGradient(0, y, 0, y + 180); g.addColorStop(0, 'rgba(190,170,255,0)'); g.addColorStop(0.5, 'rgba(190,170,255,.14)'); g.addColorStop(1, 'rgba(190,170,255,0)');
      ctx.fillStyle = g; ctx.fillRect(x - 400, y, 2400, 180);
    }
  }
}

export function drawActionSolid(ctx, th, s, camX) {
  const x = s.x - camX;
  if (x > 1200 || x + s.w < -200) return;
  if (s.kind === 'ground' || s.kind === 'step') {
    const h = Math.max(s.h, 400);
    const g = ctx.createLinearGradient(0, s.y, 0, s.y + 400);
    g.addColorStop(0, th.ground[0]); g.addColorStop(0.15, th.ground[1]); g.addColorStop(1, th.ground[2]);
    ctx.fillStyle = g; ctx.fillRect(x, s.y, s.w, h);
    ctx.fillStyle = th.line; ctx.fillRect(x, s.y, s.w, 8);
    ctx.fillStyle = 'rgba(0,0,0,.2)';
    if (th.name === 'city') { for (let wx = x + 40; wx < x + s.w - 30; wx += 120) { ctx.fillStyle = 'rgba(255,216,115,.55)'; ctx.fillRect(wx, s.y + 90, 44, 64); ctx.fillStyle = 'rgba(0,0,0,.25)'; ctx.fillRect(wx, s.y + 220, 44, 64); } ctx.fillStyle = th.line; ctx.fillRect(x, s.y - 14, 10, 14); ctx.fillRect(x + s.w - 10, s.y - 14, 10, 14); }
    else { for (let by = s.y + 40; by < s.y + 400; by += 56) { ctx.fillRect(x, by, s.w, 3); for (let bx = x + ((by / 56) % 2 ? 0 : 60); bx < x + s.w; bx += 120) ctx.fillRect(bx, by, 3, 56); } }
  } else if (s.kind === 'wall' || s.kind === 'box') {
    ctx.fillStyle = s.kind === 'box' ? '#8a6a3a' : th.ground[1]; ctx.fillRect(x, s.y, s.w, s.h);
    ctx.strokeStyle = s.kind === 'box' ? '#4a3418' : th.ground[2]; ctx.lineWidth = 4;
    if (s.kind === 'box') { ctx.strokeRect(x + 3, s.y + 3, s.w - 6, s.h - 6); ctx.beginPath(); ctx.moveTo(x, s.y); ctx.lineTo(x + s.w, s.y + s.h); ctx.moveTo(x + s.w, s.y); ctx.lineTo(x, s.y + s.h); ctx.stroke(); }
    else for (let by = s.y; by < s.y + s.h; by += 56) ctx.strokeRect(x, by, s.w, 56);
    ctx.fillStyle = th.line; ctx.fillRect(x, s.y, s.w, 6);
  } else { // plat / moving / crumble
    ctx.fillStyle = s.crumbling ? '#8a5a3a' : th.plat[0]; ctx.fillRect(x, s.y, s.w, s.h);
    ctx.fillStyle = th.plat[1]; ctx.fillRect(x, s.y + s.h - 9, s.w, 9);
    ctx.fillStyle = 'rgba(255,255,255,.5)'; ctx.fillRect(x, s.y, s.w, 4);
    if (s.mover) { ctx.fillStyle = '#7fe3ff'; ctx.fillRect(x + 8, s.y + 8, 10, 6); ctx.fillRect(x + s.w - 18, s.y + 8, 10, 6); }
  }
}

// ----------------------------------------------------------------------------------------------------------
// Characters (placeholders) — feet at (x, y), facing `dir` (+1 right)
// ----------------------------------------------------------------------------------------------------------
const PALS = {
  runner: { body: '#5b1d2b', hood: '#7a2236', trim: '#ff5d6e', eye: '#ffe27a' },
  jumper: { body: '#1d4b3a', hood: '#23604a', trim: '#7fe3a6', eye: '#e9ff9a' },
  shield: { body: '#3a2563', hood: '#4d3282', trim: '#c9a7ff', eye: '#ffd1ff' },
  guard: { body: '#4a4f66', hood: '#6a7090', trim: '#d6ddff', eye: '#7fe3ff' },
};

export function drawThief(ctx, e, camX, t) {
  const sx = e.x - camX, sy = e.y, d = e.dir, P = PALS[e.type] || PALS.runner;
  const w = e.w, h = e.h, ph = e.walkT * 10;
  ctx.save(); ctx.translate(sx, sy);
  ctx.globalAlpha = e.dead ? Math.max(0, 1 - e.deadT * 2.2) : 1;
  ctx.fillStyle = 'rgba(0,0,0,.3)'; ctx.beginPath(); ctx.ellipse(0, 2, w * 0.7, 9, 0, 0, 7); ctx.fill();
  if (e.dead) { ctx.rotate(e.deadT * 4 * d); ctx.translate(0, -e.deadT * 40); }
  ctx.scale(d, 1);
  if (e.flash > 0) ctx.filter = 'brightness(2.2)';
  const bob = e.onGround && e.moving ? Math.abs(Math.sin(ph)) * 5 : 0;
  // legs
  ctx.fillStyle = '#16121f'; const l1 = Math.sin(ph) * 14 * (e.onGround ? 1 : 0.2), l2 = -l1;
  rr(ctx, -18 + l1, -h * 0.28 - bob, 20, h * 0.28, 8); ctx.fill(); rr(ctx, 0 + l2, -h * 0.28 - bob, 20, h * 0.28, 8); ctx.fill();
  // body
  ctx.fillStyle = P.body; rr(ctx, -w * 0.5, -h * 0.68 - bob, w, h * 0.46, 16); ctx.fill();
  ctx.fillStyle = P.trim; ctx.fillRect(-w * 0.5, -h * 0.42 - bob, w, 8);
  // arm + weapon
  const sw = e.atkT > 0 ? -1.2 + (0.35 - e.atkT) * 7 : Math.sin(ph) * 0.4;
  ctx.save(); ctx.translate(w * 0.38, -h * 0.58 - bob); ctx.rotate(sw);
  ctx.fillStyle = P.body; rr(ctx, -9, 0, 18, 46, 8); ctx.fill();
  if (e.type === 'guard') { ctx.fillStyle = '#cfd6ee'; ctx.fillRect(-3, 40, 6, 90); ctx.beginPath(); ctx.moveTo(-9, 128); ctx.lineTo(0, 154); ctx.lineTo(9, 128); ctx.fill(); }
  else { ctx.fillStyle = '#d6ddff'; ctx.beginPath(); ctx.moveTo(-4, 42); ctx.lineTo(4, 42); ctx.lineTo(0, 86); ctx.fill(); }
  ctx.restore();
  if (e.type === 'shield') { ctx.fillStyle = '#7e5ad0'; ctx.strokeStyle = '#e9dcff'; ctx.lineWidth = 5; ctx.beginPath(); ctx.ellipse(w * 0.55, -h * 0.45 - bob, 20, 46, 0, 0, 7); ctx.fill(); ctx.stroke(); ctx.fillStyle = '#e9dcff'; ctx.beginPath(); ctx.arc(w * 0.55, -h * 0.45 - bob, 9, 0, 7); ctx.fill(); }
  // head + hood + mask
  const hy = -h * 0.8 - bob;
  ctx.fillStyle = '#e9b98f'; ctx.beginPath(); ctx.arc(0, hy, 30, 0, 7); ctx.fill();
  ctx.fillStyle = P.hood; ctx.beginPath(); ctx.arc(-2, hy - 6, 34, Math.PI * 1.02, Math.PI * 2.05); ctx.lineTo(30, hy + 10); ctx.lineTo(-32, hy + 10); ctx.fill();
  if (e.type === 'guard') { ctx.fillStyle = '#9aa3c8'; ctx.beginPath(); ctx.arc(0, hy - 4, 33, Math.PI, 0); ctx.fill(); ctx.fillRect(-33, hy - 6, 66, 10); }
  ctx.fillStyle = '#14101e'; ctx.fillRect(-30, hy + 2, 60, 16);
  ctx.fillStyle = P.eye; ctx.beginPath(); ctx.ellipse(10, hy + 9, 8, 5, 0, 0, 7); ctx.ellipse(-6, hy + 9, 8, 5, 0, 0, 7); ctx.fill();
  ctx.fillStyle = P.trim; ctx.beginPath(); ctx.moveTo(-26, hy + 20); ctx.lineTo(-52 - Math.sin(t * 8) * 6, hy + 34); ctx.lineTo(-24, hy + 30); ctx.fill();
  ctx.restore();
  ctx.filter = 'none';
}

export function drawRobot(ctx, b, camX, t) {
  const sx = b.x - camX, sy = b.y, d = b.dir;
  ctx.save(); ctx.translate(sx, sy); ctx.scale(d, 1);
  ctx.fillStyle = 'rgba(0,0,0,.35)'; ctx.beginPath(); ctx.ellipse(0, 3, 140, 16, 0, 0, 7); ctx.fill();
  if (b.flash > 0) ctx.filter = 'brightness(2)';
  const step = Math.sin(b.walkT * 6) * 10, sq = b.atkT > 0 ? Math.sin((0.8 - b.atkT) * 4) * 24 : 0;
  ctx.fillStyle = '#44506e'; rr(ctx, -90, -110 + step * 0.2, 60, 110, 14); ctx.fill(); rr(ctx, 30, -110 - step * 0.2, 60, 110, 14); ctx.fill();
  const bodyG = ctx.createLinearGradient(0, -330, 0, -100); bodyG.addColorStop(0, '#9aa8c9'); bodyG.addColorStop(1, '#4b5878');
  ctx.fillStyle = bodyG; rr(ctx, -110, -300 + sq, 220, 200, 30); ctx.fill();
  ctx.strokeStyle = '#1f2740'; ctx.lineWidth = 5; ctx.stroke();
  ctx.fillStyle = '#ffd873'; ctx.fillRect(-60, -240 + sq, 120, 16); ctx.fillRect(-60, -210 + sq, 120, 16);
  // core (opens when lightning-vulnerable)
  ctx.fillStyle = b.exposed ? '#7fe3ff' : '#2a3350'; ctx.beginPath(); ctx.arc(0, -170 + sq, 30, 0, 7); ctx.fill();
  if (b.exposed) { ctx.fillStyle = 'rgba(127,227,255,.35)'; ctx.beginPath(); ctx.arc(0, -170 + sq, 52 + Math.sin(t * 10) * 6, 0, 7); ctx.fill(); }
  // head
  ctx.fillStyle = '#7d8cb0'; rr(ctx, -64, -380 + sq, 128, 90, 22); ctx.fill(); ctx.stroke();
  ctx.fillStyle = '#ff3b4a'; ctx.fillRect(-46, -352 + sq, 92, 22);
  ctx.fillStyle = '#fff'; ctx.fillRect(-46 + ((t * 120) % 80), -352 + sq, 12, 22);
  ctx.strokeStyle = '#1f2740'; ctx.beginPath(); ctx.moveTo(0, -380 + sq); ctx.lineTo(0, -420 + sq); ctx.stroke(); ctx.fillStyle = '#ff3b4a'; ctx.beginPath(); ctx.arc(0, -424 + sq, 9, 0, 7); ctx.fill();
  // arms
  const arm = b.atkT > 0 ? -1.4 + (0.8 - b.atkT) * 3.4 : Math.sin(b.walkT * 6) * 0.3;
  ctx.save(); ctx.translate(108, -270 + sq); ctx.rotate(arm); ctx.fillStyle = '#5c6b92'; rr(ctx, -22, 0, 44, 120, 14); ctx.fill(); ctx.stroke(); ctx.fillStyle = '#3a4468'; rr(ctx, -34, 110, 68, 62, 18); ctx.fill(); ctx.restore();
  ctx.save(); ctx.translate(-108, -270 + sq); ctx.rotate(-Math.sin(b.walkT * 6) * 0.3); ctx.fillStyle = '#5c6b92'; rr(ctx, -22, 0, 44, 120, 14); ctx.fill(); ctx.fillStyle = '#3a4468'; rr(ctx, -34, 110, 68, 62, 18); ctx.fill(); ctx.restore();
  if (!b.exposed) { ctx.strokeStyle = `rgba(255,120,120,${0.35 + 0.25 * Math.sin(t * 8)})`; ctx.lineWidth = 8; ctx.beginPath(); ctx.ellipse(0, -220, 150, 215, 0, 0, 7); ctx.stroke(); }
  ctx.restore(); ctx.filter = 'none';
}

export function drawKing(ctx, b, camX, t) {
  const sx = b.x - camX, sy = b.y, d = b.dir;
  ctx.save(); ctx.translate(sx, sy); ctx.scale(d, 1);
  ctx.fillStyle = 'rgba(0,0,0,.35)'; ctx.beginPath(); ctx.ellipse(0, 3, 120, 14, 0, 0, 7); ctx.fill();
  if (b.flash > 0) ctx.filter = 'brightness(2)';
  const air = b.airborne ? -20 : 0;
  ctx.fillStyle = '#231a3a'; rr(ctx, -66, -100, 50, 100, 14); ctx.fill(); rr(ctx, 16, -100, 50, 100, 14); ctx.fill();
  ctx.fillStyle = '#4a2a5e'; rr(ctx, -96, -270 + air, 192, 190, 36); ctx.fill();
  ctx.fillStyle = '#d6a43a'; ctx.fillRect(-96, -170 + air, 192, 16);
  ctx.fillStyle = '#e9b98f'; ctx.beginPath(); ctx.arc(0, -315 + air, 44, 0, 7); ctx.fill();
  ctx.fillStyle = '#d6a43a'; ctx.beginPath(); ctx.moveTo(-52, -330 + air); ctx.lineTo(-40, -392 + air); ctx.lineTo(-18, -346 + air); ctx.lineTo(0, -402 + air); ctx.lineTo(18, -346 + air); ctx.lineTo(40, -392 + air); ctx.lineTo(52, -330 + air); ctx.fill();
  ctx.fillStyle = '#14101e'; ctx.fillRect(-44, -316 + air, 88, 20); ctx.fillStyle = '#ff9a3a'; ctx.beginPath(); ctx.ellipse(16, -306 + air, 10, 6, 0, 0, 7); ctx.ellipse(-14, -306 + air, 10, 6, 0, 0, 7); ctx.fill();
  // hammer
  const sw = b.atkT > 0 ? -2.2 + (1 - b.atkT) * 3.4 : -0.5 + Math.sin(b.walkT * 5) * 0.12;
  ctx.save(); ctx.translate(94, -240 + air); ctx.rotate(sw);
  ctx.fillStyle = '#5a3a1a'; ctx.fillRect(-8, 0, 16, 190); ctx.fillStyle = '#9aa3c8'; rr(ctx, -62, 170, 124, 84, 14); ctx.fill(); ctx.strokeStyle = '#2a3350'; ctx.lineWidth = 5; ctx.stroke(); ctx.restore();
  ctx.fillStyle = '#4a2a5e'; rr(ctx, -118, -250 + air, 36, 110, 14); ctx.fill();
  if (b.shieldLayers > 0) {
    for (let i = 0; i < b.shieldLayers; i++) { ctx.strokeStyle = `rgba(255,216,115,${0.55 + 0.25 * Math.sin(t * 6 + i)})`; ctx.lineWidth = 7; ctx.beginPath(); ctx.ellipse(0, -210, 150 + i * 16, 230 + i * 16, 0, 0, 7); ctx.stroke(); }
  }
  ctx.restore(); ctx.filter = 'none';
}

export function drawBeast(ctx, b, camX, t) {
  const sx = b.x - camX, sy = b.y, d = b.dir;
  ctx.save(); ctx.translate(sx, sy); ctx.scale(d, 1);
  if (b.flash > 0) ctx.filter = 'brightness(2)';
  const pul = Math.sin(t * 3) * 8;
  for (let i = 0; i < 14; i++) { // smoky body
    const a = i / 14 * 6.28 + t * 0.6, r0 = 120 + Math.sin(t * 2 + i) * 14;
    const g = ctx.createRadialGradient(Math.cos(a) * 60, -200 + Math.sin(a) * 90, 10, Math.cos(a) * 60, -200 + Math.sin(a) * 90, r0);
    g.addColorStop(0, 'rgba(60,20,110,.75)'); g.addColorStop(1, 'rgba(20,6,50,0)');
    ctx.fillStyle = g; ctx.beginPath(); ctx.arc(Math.cos(a) * 60, -200 + Math.sin(a) * 90, r0, 0, 7); ctx.fill();
  }
  ctx.fillStyle = '#1a0a36'; rr(ctx, -120, -330 + pul, 240, 300, 80); ctx.fill();
  ctx.fillStyle = '#1a0a36'; ctx.beginPath(); ctx.moveTo(-96, -330 + pul); ctx.lineTo(-130, -420 + pul); ctx.lineTo(-56, -350 + pul); ctx.fill(); ctx.beginPath(); ctx.moveTo(96, -330 + pul); ctx.lineTo(130, -420 + pul); ctx.lineTo(56, -350 + pul); ctx.fill();
  ctx.fillStyle = '#d96bff'; ctx.shadowColor = '#d96bff'; ctx.shadowBlur = 24;
  ctx.beginPath(); ctx.moveTo(-84, -250 + pul); ctx.lineTo(-24, -236 + pul); ctx.lineTo(-52, -204 + pul); ctx.fill(); ctx.beginPath(); ctx.moveTo(84, -250 + pul); ctx.lineTo(24, -236 + pul); ctx.lineTo(52, -204 + pul); ctx.fill();
  ctx.shadowBlur = 0; ctx.strokeStyle = '#d96bff'; ctx.lineWidth = 6; ctx.beginPath(); ctx.moveTo(-60, -150 + pul); for (let i = 0; i < 6; i++) ctx.lineTo(-60 + i * 24, -150 + pul + (i % 2 ? 18 : -4)); ctx.stroke();
  const arm = b.atkT > 0 ? -1.2 + (1 - b.atkT) * 2.8 : Math.sin(t * 2) * 0.2;
  ctx.save(); ctx.translate(112, -230); ctx.rotate(arm); ctx.fillStyle = '#26104a'; rr(ctx, -24, 0, 48, 190, 24); ctx.fill(); ctx.fillStyle = '#d96bff'; for (let i = -1; i <= 1; i++) { ctx.beginPath(); ctx.moveTo(i * 14 - 6, 190); ctx.lineTo(i * 14, 230); ctx.lineTo(i * 14 + 6, 190); ctx.fill(); } ctx.restore();
  if (b.armor > 0) { ctx.strokeStyle = `rgba(217,107,255,${0.5 + 0.3 * Math.sin(t * 7)})`; ctx.lineWidth = 10; ctx.setLineDash([22, 14]); ctx.beginPath(); ctx.ellipse(0, -200, 190, 250, 0, 0, 7); ctx.stroke(); ctx.setLineDash([]); }
  ctx.restore(); ctx.filter = 'none';
}

export function drawProp(ctx, p, camX, t) {
  const sx = p.x - camX; if (sx < -200 || sx > 1300) return;
  ctx.save(); ctx.translate(sx, p.y);
  switch (p.kind) {
    case 'chest': {
      const open = p.open;
      ctx.fillStyle = open ? '#6a4a1a' : '#a8741a'; rr(ctx, -50, -70, 100, 70, 10); ctx.fill();
      ctx.fillStyle = open ? '#4a3210' : '#c98e2a'; rr(ctx, -50, open ? -118 : -96, 100, 40, 12); ctx.fill();
      ctx.strokeStyle = '#3a2610'; ctx.lineWidth = 4; ctx.strokeRect(-50, -70, 100, 70);
      ctx.fillStyle = '#7fe3ff'; ctx.beginPath(); ctx.arc(0, -64, 11, 0, 7); ctx.fill();
      if (!open) { ctx.fillStyle = `rgba(127,227,255,${0.25 + 0.2 * Math.sin(t * 4)})`; ctx.beginPath(); ctx.arc(0, -60, 78, 0, 7); ctx.fill(); }
      break;
    }
    case 'crystal': {
      if (p.done) { ctx.globalAlpha = 0.3; }
      const c = p.color || '#7fe3ff';
      const y = -90 + Math.sin(t * 2 + p.x) * 10;
      const g = ctx.createRadialGradient(0, y, 6, 0, y, 110); g.addColorStop(0, c + 'cc'); g.addColorStop(1, c + '00'); ctx.fillStyle = g; ctx.beginPath(); ctx.arc(0, y, 110, 0, 7); ctx.fill();
      ctx.fillStyle = c; ctx.beginPath(); ctx.moveTo(0, y - 56); ctx.lineTo(34, y); ctx.lineTo(0, y + 56); ctx.lineTo(-34, y); ctx.fill();
      ctx.fillStyle = 'rgba(255,255,255,.6)'; ctx.beginPath(); ctx.moveTo(0, y - 56); ctx.lineTo(14, y - 4); ctx.lineTo(0, y + 6); ctx.fill();
      ctx.fillStyle = '#3a3f66'; rr(ctx, -44, -30, 88, 30, 6); ctx.fill();
      break;
    }
    case 'terminal': {
      ctx.fillStyle = '#2a3350'; rr(ctx, -52, -150, 104, 150, 10); ctx.fill(); ctx.strokeStyle = '#7fe3ff'; ctx.lineWidth = 4; ctx.stroke();
      ctx.fillStyle = p.done ? '#5fe09a' : '#7fe3ff'; rr(ctx, -38, -132, 76, 56, 6); ctx.fill();
      ctx.fillStyle = '#0b1230'; ctx.font = '800 38px sans-serif'; ctx.textAlign = 'center'; ctx.fillText(p.done ? '✔' : '⚡', 0, -92);
      break;
    }
    case 'key': {
      if (p.got) break;
      const y = -80 + Math.sin(t * 3 + p.x) * 8;
      ctx.fillStyle = '#ffd873'; ctx.strokeStyle = '#8a5a10'; ctx.lineWidth = 4; ctx.translate(0, y); ctx.rotate(-0.5);
      ctx.beginPath(); ctx.arc(-18, 0, 15, 0, 7); ctx.fill(); ctx.stroke(); ctx.fillRect(-4, -5, 44, 10); ctx.strokeRect(-4, -5, 44, 10); ctx.fillRect(22, 5, 7, 14); ctx.fillRect(32, 5, 7, 10);
      break;
    }
    case 'spikes': {
      ctx.fillStyle = '#c8cfe8'; ctx.strokeStyle = '#4a506e'; ctx.lineWidth = 3;
      for (let x = 0; x < p.w; x += 30) { ctx.beginPath(); ctx.moveTo(x, 0); ctx.lineTo(x + 15, -50); ctx.lineTo(x + 30, 0); ctx.fill(); ctx.stroke(); }
      break;
    }
    case 'fire': {
      const on = p.on;
      ctx.fillStyle = '#3a3f66'; ctx.fillRect(-18, -24, 36, 24);
      if (on) { for (let i = 0; i < 6; i++) { ctx.fillStyle = i % 2 ? '#ffb13a' : '#ff5d3a'; ctx.globalAlpha = 0.8; ctx.beginPath(); ctx.ellipse(Math.sin(t * 14 + i) * 8, -40 - i * 30, 22 - i * 2, 40, 0, 0, 7); ctx.fill(); } ctx.globalAlpha = 1; }
      else { ctx.fillStyle = `rgba(255,120,60,${0.3 + 0.3 * Math.sin(t * 6)})`; ctx.beginPath(); ctx.arc(0, -30, 10, 0, 7); ctx.fill(); }
      break;
    }
    case 'door': {
      ctx.fillStyle = '#2a2f4a'; rr(ctx, -80, -300, 160, 300, [80, 80, 0, 0]); ctx.fill(); ctx.strokeStyle = '#c9a25a'; ctx.lineWidth = 6; ctx.stroke();
      const op = p.open || 0;
      ctx.fillStyle = '#3a2a1a'; ctx.fillRect(-70, -290 - op * 280, 140, 290); ctx.fillStyle = '#c9a25a'; ctx.fillRect(-4, -290 - op * 280, 8, 290);
      for (let i = 0; i < p.need; i++) { ctx.fillStyle = i < p.have ? '#ffd873' : 'rgba(20,10,50,.8)'; ctx.beginPath(); ctx.arc((i - (p.need - 1) / 2) * 56, -330, 20, 0, 7); ctx.fill(); ctx.strokeStyle = '#c9a25a'; ctx.stroke(); }
      break;
    }
    case 'star': break;
    default: break;
  }
  ctx.restore();
}

export function drawStar(ctx, x, y, s = 1, t = 0) {
  ctx.save(); ctx.translate(x, y + Math.sin(t * 4 + x * 0.01) * 5); ctx.scale(s, s);
  const g = ctx.createRadialGradient(0, 0, 4, 0, 0, 38); g.addColorStop(0, 'rgba(255,230,120,.9)'); g.addColorStop(1, 'rgba(255,230,120,0)');
  ctx.fillStyle = g; ctx.beginPath(); ctx.arc(0, 0, 38, 0, 7); ctx.fill();
  ctx.fillStyle = '#ffd23a'; ctx.strokeStyle = '#a8741a'; ctx.lineWidth = 3; ctx.beginPath();
  for (let i = 0; i < 10; i++) { const a = -Math.PI / 2 + i * Math.PI / 5, r = i % 2 ? 11 : 26; ctx.lineTo(Math.cos(a) * r, Math.sin(a) * r); }
  ctx.closePath(); ctx.fill(); ctx.stroke(); ctx.restore();
}
