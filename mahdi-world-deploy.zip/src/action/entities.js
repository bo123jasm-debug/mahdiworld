import { GRAVITY } from '../game/world.js';
import { overlap } from '../engine/util.js';

const TYPES = {
  runner: { w: 60, h: 150, hp: 1, speed: 270, dmg: 10, name: 'لصّ راكض' },
  jumper: { w: 60, h: 140, hp: 1, speed: 230, dmg: 10, name: 'لصّ قفّاز' },
  shield: { w: 74, h: 160, hp: 3, speed: 150, dmg: 12, name: 'لصّ الدرع' },
  guard: { w: 74, h: 170, hp: 2, speed: 190, dmg: 12, name: 'حارس' },
  robot: { w: 240, h: 340, hp: 8, speed: 90, dmg: 12, name: 'الروبوت العملاق', boss: true },
  king: { w: 200, h: 300, hp: 10, speed: 110, dmg: 14, name: 'زعيم اللصوص', boss: true },
  beast: { w: 260, h: 340, hp: 9, speed: 100, dmg: 16, name: 'وحش الظلال', boss: true },
};

export class Enemy {
  constructor(def) {
    const T = TYPES[def.type];
    Object.assign(this, { type: def.type, ...T, x: def.x, y: def.y, dir: -1, vx: 0, vy: 0, onGround: false, maxHp: T.hp });
    this.patrol = def.patrol || null; this.chase = !!def.chase; this.home = { x: def.x, y: def.y };
    this.t = 0; this.walkT = 0; this.atkT = 0; this.atkCd = 1 + Math.random(); this.flash = 0; this.stun = 0;
    this.dead = false; this.deadT = 0; this.moving = false; this.lastSafe = { x: def.x, y: def.y };
    this.hopCd = 0.6; this.state = 'idle'; this.cd1 = 2.2; this.cd2 = 5; this.exposed = false;
    this.shieldLayers = def.type === 'king' ? 3 : 0; this.armor = def.type === 'beast' ? 3 : 0;
    this.airborne = false; this.vulnT = 0; this.minions = false;
  }

  rect() { return { x: this.x - this.w / 2, y: this.y - this.h, w: this.w, h: this.h }; }
  hurtRect() { return { x: this.x - this.w * 0.4, y: this.y - this.h * 0.95, w: this.w * 0.8, h: this.h * 0.9 }; }

  /** kind: 'melee' | 'fist' | 'zap'. Returns 'hit' | 'blocked'. */
  hit(dmg, kind, heroX, c) {
    if (this.dead) return 'none';
    const fromFront = Math.sign(heroX - this.x) === this.dir;
    let blocked = false;
    if (this.type === 'robot') blocked = kind !== 'zap';
    else if (this.type === 'king') blocked = this.shieldLayers > 0;
    else if (this.type === 'beast') blocked = this.armor > 0;
    else if (this.type === 'shield') blocked = fromFront && kind === 'melee';
    if (blocked) { this.flash = 0.06; c.sfx('enemy'); c.burst(this.x + this.dir * 30, this.y - this.h * 0.55, 8, { color: '#ffe27a', speed: 260, life: 0.35 }); return 'blocked'; }
    this.hp -= dmg; this.flash = 0.14; this.stun = this.boss ? (kind === 'zap' ? 0.55 : 0.12) : 0.25;
    if (this.type === 'robot') this.exposed = true;
    this.vx = Math.sign(this.x - heroX) * (this.boss ? 90 : 320);
    c.sfx(kind === 'zap' ? 'zap' : 'hit'); c.burst(this.x, this.y - this.h * 0.55, 14, { color: kind === 'zap' ? '#9ff' : '#fff', speed: 340, life: 0.5 });
    if (this.hp <= 0) { this.dead = true; this.deadT = 0; c.onKill(this); }
    return 'hit';
  }

  groundAhead(world, dist) {
    const px = this.x + this.dir * dist, py = this.y + 10;
    return world.solids.some((s) => px >= s.x && px <= s.x + s.w && py >= s.y && py <= s.y + s.h + 60 && !s.hidden);
  }

  physics(dt, world, fallY) {
    this.vy = Math.min(this.vy + GRAVITY * dt, 1700);
    const r = this.rect();
    world.moveX(this, r, this.vx * dt);
    const hit = world.moveY(this, r, this.vy * dt);
    this.onGround = hit === 'ground';
    this.x = r.x + r.w / 2; this.y = r.y + r.h;
    if (this.onGround) this.lastSafe = { x: this.x, y: this.y };
    if (this.y > fallY) { this.x = this.lastSafe.x; this.y = this.lastSafe.y - 4; this.vy = 0; }
  }

  update(dt, c) {
    const { hero, world } = c;
    if (this.dead) { this.deadT += dt; return; }
    this.t += dt; this.flash = Math.max(0, this.flash - dt); this.stun = Math.max(0, this.stun - dt);
    this.atkCd = Math.max(0, this.atkCd - dt); this.atkT = Math.max(0, this.atkT - dt);
    const dx = hero.x - this.x, adx = Math.abs(dx), dy = hero.y - this.y;
    if (this.stun > 0) { this.vx *= 0.9; this.physics(dt, world, c.fallY); return; }
    if (this.boss) return this.bossUpdate(dt, c, dx, adx);
    const aggro = this.chase || (adx < 700 && Math.abs(dy) < 360);
    let want = 0;
    if (aggro) { this.dir = dx >= 0 ? 1 : -1; want = adx > 90 ? this.dir : 0; }
    else if (this.patrol) {
      if (this.x <= this.patrol[0]) this.dir = 1; else if (this.x >= this.patrol[1]) this.dir = -1;
      want = this.dir * 0.45;
    }
    const sp = this.speed * (aggro ? 1 : 0.6);
    // attack wind-up
    if (aggro && this.atkCd === 0 && adx < (this.type === 'guard' ? 190 : 120) && Math.abs(dy) < 140 && this.onGround) { this.atkT = 0.35; this.atkCd = 1.6; c.sfx('enemy'); }
    if (this.atkT > 0.12 && this.atkT < 0.28) {
      const reach = this.type === 'guard' ? 200 : 110;
      const hb = { x: this.dir > 0 ? this.x : this.x - reach, y: this.y - 130, w: reach, h: 120 };
      if (overlap(hb, hero.rect())) c.hurtHero(this.dmg, this.x);
    }
    if (this.atkT > 0) want = 0;
    // hop / jump logic
    if (this.type === 'jumper') {
      this.hopCd -= dt;
      if (aggro && this.onGround && this.hopCd <= 0 && adx > 120) { this.vy = -1000; this.vx = this.dir * 330; this.hopCd = 1.1 + Math.random() * 0.4; }
    } else if (want !== 0 && this.onGround) {
      if (!this.groundAhead(world, 50)) {
        if (aggro && adx > 140 && this.type !== 'shield') { this.vy = -1100; this.vx = this.dir * 440; }
        else { want = 0; this.dir *= -1; }
      } else if (Math.abs(this.vx) < 30 && this.moving && aggro) { this.vy = -950; }
    }
    if (this.onGround || Math.abs(want) > 0) {
      if (this.onGround && !(this.type === 'jumper' && this.vy < 0)) this.vx += (want * sp - this.vx) * Math.min(1, dt * 9);
    }
    this.moving = Math.abs(this.vx) > 20 && this.onGround;
    this.walkT += dt * (this.moving ? Math.abs(this.vx) / 260 : 0);
    this.physics(dt, world, c.fallY);
  }

  // ----------------------------------------------------------------------------------------- bosses
  bossUpdate(dt, c, dx, adx) {
    const { hero, world } = c;
    this.walkT += dt * 0.6;
    const A = c.arena;
    if (!this.active) { this.physics(dt, world, c.fallY); return; }
    this.dir = dx >= 0 ? 1 : -1;
    this.cd1 -= dt; this.cd2 -= dt;
    let want = 0;
    if (this.type === 'robot') {
      this.exposed = this.exposed && this.stun > 0;
      if (this.atkT === 0 && adx > 380) want = this.dir;
      if (this.atkT === 0 && this.cd1 <= 0 && adx < 700) { this.atkT = 0.8; this.cd1 = 3.4; this.waveDone = false; c.sfx('enemy'); }
      if (this.atkT > 0 && this.atkT < 0.35 && !this.waveDone) {
        this.waveDone = true; c.sfx('boom'); c.shake(14);
        for (const d of [-1, 1]) c.spawnProj({ kind: 'wave', x: this.x + d * 120, y: this.y, vx: d * 380, vy: 0, w: 100, h: 70, dmg: 14, life: 2.6 });
      }
      if (this.cd2 <= 0) { this.cd2 = 6.5; c.sfx('alarm'); c.spawnProj({ kind: 'missile', x: hero.x, y: this.y - 1000, gy: this.y, vx: 0, vy: 0, w: 70, h: 90, dmg: 16, life: 3, delay: 0.9 }); if (this.hp <= this.maxHp / 2) c.spawnProj({ kind: 'missile', x: hero.x + 260 * -this.dir, y: this.y - 1000, gy: this.y, vx: 0, vy: 0, w: 70, h: 90, dmg: 16, life: 3, delay: 1.2 }); }
    } else if (this.type === 'king') {
      this.airborne = !this.onGround;
      if (this.state === 'leap') {
        if (this.onGround && this.vy >= 0 && this.t - this.leapT > 0.25) { this.state = 'idle'; c.sfx('boom'); c.shake(16); for (const d of [-1, 1]) c.spawnProj({ kind: 'wave', x: this.x + d * 110, y: this.y, vx: d * 340, vy: 0, w: 90, h: 64, dmg: 14, life: 2.2 }); }
      } else {
        if (this.atkT === 0 && adx > 320) want = this.dir;
        if (this.atkT === 0 && this.cd1 <= 0 && adx < 480) { this.atkT = 0.9; this.cd1 = 3.0; this.waveDone = false; c.sfx('enemy'); }
        if (this.atkT > 0 && this.atkT < 0.4 && !this.waveDone) {
          this.waveDone = true; c.sfx('boom'); c.shake(14);
          for (const d of [-1, 1]) c.spawnProj({ kind: 'wave', x: this.x + d * 130, y: this.y, vx: d * 360, vy: 0, w: 100, h: 68, dmg: 14, life: 2.4 });
          for (const o of [-170, 150]) c.spawnProj({ kind: 'rock', x: hero.x + o, y: this.y - 900, gy: this.y, vx: 0, vy: 0, w: 70, h: 70, dmg: 12, life: 3, delay: 0.7 });
        }
        if (this.atkT === 0 && this.cd2 <= 0 && this.onGround) { this.cd2 = 7; this.state = 'leap'; this.leapT = this.t; this.vy = -1300; this.vx = Math.max(-520, Math.min(520, dx * 0.9)); c.sfx('jump'); }
      }
    } else if (this.type === 'beast') {
      if (this.atkT === 0 && adx > 300) want = this.dir * (this.armor > 0 ? 0.7 : 1);
      if (this.atkT === 0 && this.atkCd === 0 && adx < 330 && Math.abs(hero.y - this.y) < 200) { this.atkT = 0.7; this.atkCd = 2.2; c.sfx('enemy'); this.clawDone = false; }
      if (this.atkT > 0 && this.atkT < 0.3 && !this.clawDone) {
        this.clawDone = true; c.shake(8);
        const hb = { x: this.dir > 0 ? this.x : this.x - 330, y: this.y - 240, w: 330, h: 240 };
        if (overlap(hb, hero.rect())) c.hurtHero(this.dmg, this.x);
      }
      if (this.cd1 <= 0 && this.atkT === 0) { this.cd1 = 3.6; c.sfx('zap'); c.spawnProj({ kind: 'orb', x: this.x + this.dir * 160, y: this.y - 90, vx: this.dir * 420, vy: 0, w: 70, h: 70, dmg: 12, life: 3.2 }); }
      if (this.hp <= this.maxHp / 2 && !this.minions) { this.minions = true; c.spawnMinions(this); }
    }
    this.vx += (want * this.speed - this.vx) * Math.min(1, dt * 6);
    this.moving = Math.abs(this.vx) > 20;
    this.physics(dt, world, c.fallY);
    // stay inside the arena
    if (A) { if (this.x < A.x0 + this.w / 2) this.x = A.x0 + this.w / 2; if (this.x > A.x1 - this.w / 2) this.x = A.x1 - this.w / 2; }
    // touching the boss hurts a little
    if (overlap(this.hurtRect(), hero.rect())) c.hurtHero(10, this.x);
  }
}

/** Enemy / boss projectiles. Player projectiles (lightning bolts) use kind 'bolt'. */
export class Proj {
  constructor(o) { Object.assign(this, { delay: 0, life: 3, gy: 0, from: 'enemy', t: 0, hitDone: false }, o); }
  rect() { return { x: this.x - this.w / 2, y: this.y - this.h, w: this.w, h: this.h }; }
  update(dt, c) {
    this.t += dt; this.life -= dt;
    if (this.kind === 'missile' || this.kind === 'rock') {
      if (this.t < this.delay) { this.y = this.gy - 1000; return; }
      this.vy = 1250; this.y += this.vy * dt;
      if (this.y >= this.gy) { this.life = 0; c.sfx('boom'); c.shake(10); c.burst(this.x, this.gy - 20, 24, { color: '#ffb13a', speed: 420, life: 0.6 }); const ex = { x: this.x - 100, y: this.gy - 140, w: 200, h: 140 }; if (overlap(ex, c.hero.rect())) c.hurtHero(this.dmg, this.x); }
      return;
    }
    this.x += this.vx * dt; this.y += this.vy * dt;
  }
}
