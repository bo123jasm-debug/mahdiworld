import { World } from '../game/world.js';
import { Player } from '../game/player.js';
import * as R from '../game/render.js';
import { clamp, lerp, sleep, overlap, el } from '../engine/util.js';
import { STAGES, STAGE_LIST } from './levels.js';
import { Enemy, Proj } from './entities.js';
import { pickQuestion, askQuestion } from './mcq.js';
import { getActionTheme, drawActionBackground, drawActionSolid, drawThief, drawRobot, drawKing, drawBeast, drawProp, drawStar } from './art.js';

const VW = 1080, VH = 1920, Z = 1.7;
const WVIEW = VW / Z, HVIEW = VH / Z;
const POWER_NAMES = { speed: 'سرعة البرق', zap: 'الضربة الكهربائية', shield: 'الدرع الواقي', jump: 'القفزة العملاقة', fist: 'قبضة القوة' };
const PERM_ORDER = ['speed', 'power', 'jump', 'energy', 'ninja'];
const PERM_MAX = { speed: 3, power: 3, jump: 3, energy: 3, ninja: 2 };
const PERM_NAMES = { speed: 'سرعة الحركة', power: 'قوة الضربة', jump: 'قوة القفز', energy: 'الطاقة القصوى', ninja: 'حركة نينجا جديدة' };

/**
 * Vertical (9:16) action stage: chase, combat, powers earned through three-option questions, bosses.
 * Everything visual here is a procedural placeholder; the hero uses the approved ninja frames.
 */
export class ActionStage {
  constructor(game) {
    this.g = game;
    this.player = new Player(game.assets, game.audio);
    this.particles = new R.Particles();
    this.scene = 'none'; this.cine = null; this.t = 0;
    this.state = { sparks: new Set(), keys: new Set() };
  }

  // ---------------------------------------------------------------- setup
  async begin({ stageId, resume = false }) {
    const g = this.g, def = (this.def = STAGES[stageId]);
    this.theme = getActionTheme(def.theme);
    this.stageId = stageId;
    this.world = new World({ width: def.width, solids: def.solids.map((s) => ({ ...s })), crates: [], climb: def.climb || [] });
    this.setupDynamics();
    this.enemies = []; this.projs = []; this.pops = []; this.shakeT = 0; this.shakeA = 0;
    this.collected = new Set(); this.stars = 0; this.keys = new Set(); this.faints = 0; this.wrongs = 0; this.kills = 0; this.permGained = [];
    this.props = this.buildProps();
    this.boss = null; this.arena = null; this.bossDead = false; this.keyProp = null;
    this.fired = new Set(); this.freeze = true; this.t = 0; this.rockT = {}; this.fireT = {};
    this.cpIndex = -1; this.flashRed = 0; this.regen = 0;
    const perm = g.save.data.action.perm;
    this.maxEnergy = 100 + 20 * perm.energy; this.energy = this.maxEnergy;
    this.hero = { speedT: 0, jumpT: 0, fistT: 0, shieldT: 0, shieldHits: 0, zap: 0, invuln: 0, atkCd: 0, swingT: 0, swingHit: null, boltCd: 0 };
    const p = this.player; p.setMode('ninja'); p.locked = false; p.fx = null; p.alpha = 1; p.canSlide = true;
    // resume from the last saved checkpoint of this stage (progress is never lost on retry)
    const run = g.save.data.action.run;
    let sp = { ...def.start };
    if (resume && run && run.id === stageId) {
      this.cpIndex = run.cp; this.stars = run.stars || 0; run.collected?.forEach((i) => this.collected.add(i)); run.keys?.forEach((k) => this.keys.add(k));
      const c = def.checkpoints[run.cp]; if (c) sp = { x: c.x, y: c.y };
      this.props.forEach((q) => { if (q.id && run.done?.includes(q.id)) { q.done = true; q.open = true; q.got = true; } });
      def.events.forEach((e) => { if (e.x < sp.x) this.fired.add(e.id); });
    }
    p.respawn(sp.x, sp.y); this.applyStats();
    this.spawnStatic(sp.x);
    this.camX = clamp(sp.x - WVIEW * 0.4, 0, def.width - WVIEW); this.camY = sp.y - HVIEW * 0.62;
    this.scene = 'play'; this.state.sparks = new Set(this.collected);
    g.ui.setMode('action'); g.ui.setStageName(def.short); g.ui.setGoal(def.mission); g.ui.showHud(true); g.ui.hide();
    g.onWrongAnswer = () => this.penalty();
    g.audio.music(true);
    this.syncHud();
    if (!resume || !run || run.id !== stageId) await this.say(def.intro);
    this.freeze = false;
  }

  setupDynamics() {
    const def = this.def, w = this.world;
    this.movers = (def.movers || []).map((m) => { const o = { x: m.x, y: m.y, w: m.w, h: m.h, kind: 'plat', mover: true }; w.solids.push(o); return { o, ...m, bx: m.x, by: m.y, ph: Math.random() * 3, dx: 0, dy: 0 }; });
    this.crumbles = (def.crumbles || []).map((c) => { const o = { x: c.x, y: c.y, w: c.w, h: c.h, kind: 'plat', crumbling: true }; w.solids.push(o); return { o, c, state: 'idle', timer: 0, shakeX: 0 }; });
    this.doorSolid = null;
    if (def.door) { this.doorSolid = { x: def.door.x - 36, y: def.door.y - 300, w: 72, h: 300, kind: 'wall', hidden: true }; w.solids.push(this.doorSolid); }
  }

  buildProps() {
    const d = this.def, a = [];
    d.chests?.forEach((c) => a.push({ ...c, kind: 'chest', open: false }));
    d.crystals?.forEach((c) => a.push({ ...c, kind: 'crystal', done: false }));
    d.terminals?.forEach((c) => a.push({ ...c, kind: 'terminal', done: false }));
    d.keys?.forEach((k) => a.push({ ...k, kind: 'key', got: false }));
    if (d.door) a.push({ ...d.door, kind: 'door', id: 'door', open: 0, need: d.door.need, have: 0 });
    if (d.arenaCrystal) a.push({ ...d.arenaCrystal, kind: 'crystal', id: 'arena', arena: true, done: true, cool: 0, color: '#d9a7ff', title: 'بلورة النور' });
    return a;
  }

  spawnStatic(fromX) {
    this.def.enemies.forEach((e) => { if (e.x > fromX + 200) this.enemies.push(new Enemy({ ...e })); });
  }

  applyStats() {
    const perm = this.g.save.data.action.perm, h = this.hero, p = this.player;
    p.speedMul = (1 + 0.06 * perm.speed) * (h.speedT > 0 ? 1.45 : 1);
    p.jumpMul = (1 + 0.04 * perm.jump) * (h.jumpT > 0 ? 1.3 : 1);
    p.doubleJumpUnlocked = perm.ninja >= 1;
  }

  async say(lines) {
    this.freeze = true;
    for (const [who, text] of lines) await this.g.ui.dialog(who, [text]);
    this.freeze = false;
  }

  // ---------------------------------------------------------------- questions & rewards
  async ask(cat, { title, reward }) {
    this.freeze = true; this.player.vx = 0;
    const q = pickQuestion(this.g, cat, 3 - (this.def.id === 'a1' ? 1 : 0));
    const res = await askQuestion(this.g, q, { title, reward });
    this.freeze = false;
    this.checkPerm();
    return res;
  }

  checkPerm() {
    const A = this.g.save.data.action;
    if (A.correct > 0 && A.correct % 3 === 0 && A.permAt !== A.correct) {
      A.permAt = A.correct;
      const start = Math.floor(A.correct / 3 - 1) % PERM_ORDER.length;
      for (let i = 0; i < PERM_ORDER.length; i++) {
        const k = PERM_ORDER[(start + i) % PERM_ORDER.length];
        if (A.perm[k] < PERM_MAX[k]) {
          A.perm[k]++; this.g.save.commit(); this.permGained.push(k);
          if (k === 'energy') { this.maxEnergy += 20; this.energy = Math.min(this.maxEnergy, this.energy + 20); }
          this.applyStats(); this.g.audio.play('power');
          const txt = k === 'ninja' && A.perm[k] === 1 ? 'مهارة دائمة جديدة: القفز المزدوج!' : `مهارة دائمة: ${PERM_NAMES[k]} ↑`;
          this.pop(this.player.x, this.player.y - 260, txt, '#9ff', 2.6); this.g.ui.setGoal(txt);
          break;
        }
      }
    }
  }

  grantPower(name, firstTry) {
    const h = this.hero, m = firstTry ? 1 : 0.66, p = this.player;
    this.g.audio.play('power');
    this.particles.burst(p.x, p.y - 90, 40, { color: '#7fe3ff', speed: 460, life: 0.9 });
    switch (name) {
      case 'zap': h.zap += firstTry ? 6 : 4; break;
      case 'speed': h.speedT = Math.max(h.speedT, 14 * m); break;
      case 'jump': h.jumpT = Math.max(h.jumpT, 16 * m); break;
      case 'fist': h.fistT = Math.max(h.fistT, 16 * m); break;
      case 'shield': h.shieldT = 18 * m; h.shieldHits = firstTry ? 4 : 3; break;
      default: break;
    }
    this.applyStats();
    this.pop(p.x, p.y - 250, `قوة جديدة: ${POWER_NAMES[name]}!`, '#7fe3ff', 2.4);
    this.syncHud();
  }

  penalty() {
    this.wrongs++;
    if (this.stars > 0) { this.stars--; this.syncHud(); return 'خسرتَ نجمة'; }
    this.energy = Math.max(this.maxEnergy * 0.1, this.energy - this.maxEnergy * 0.2); this.syncHud();
    return 'نقصت بعض الطاقة';
  }

  // ---------------------------------------------------------------- hero damage / respawn
  hurtHero(dmg, fromX) {
    const h = this.hero, p = this.player;
    if (h.invuln > 0 || this.scene !== 'play') return;
    if (h.shieldHits > 0) {
      h.shieldHits--; h.invuln = 0.5; this.g.audio.play('enemy');
      this.particles.burst(p.x, p.y - 90, 18, { color: '#9dff9a', speed: 300, life: 0.5 });
      if (h.shieldHits === 0) h.shieldT = 0;
      this.syncHud(); return;
    }
    this.energy -= dmg; h.invuln = 1.1; this.flashRed = 0.35;
    p.playFx('hurt', 0.4); p.vx = Math.sign(p.x - fromX || 1) * 380; p.vy = -420; p.onGround = false;
    this.g.audio.play('hurt'); this.shake(8);
    this.particles.burst(p.x, p.y - 90, 12, { color: '#ff9aa8', speed: 260, life: 0.5 });
    if (this.energy <= 0) this.faint();
    this.syncHud();
  }

  faint() {
    this.faints++;
    if (this.stars > 0) this.stars--;
    this.energy = this.maxEnergy * 0.6; this.hero.invuln = 1.6;
    this.respawnAtCheckpoint();
    this.pop(this.player.x, this.player.y - 250, 'عاد مهدي إلى نقطة قريبة', '#ffd873', 2.2);
  }

  respawnAtCheckpoint() {
    const c = this.def.checkpoints[this.cpIndex] || this.def.start;
    this.player.respawn(c.x, c.y - 2); this.player.fx = null;
    this.camX = clamp(c.x - WVIEW * 0.4, 0, this.def.width - WVIEW); this.camY = c.y - HVIEW * 0.62;
    this.projs = [];
  }

  pop(x, y, text, color = '#fff', life = 1.2) { this.pops.push({ x, y, text, color, life, max: life }); }
  shake(a) { this.shakeT = 0.3; this.shakeA = a; }
  sfx(n) { this.g.audio.play(n); }

  syncHud() {
    const ui = this.g.ui, h = this.hero;
    ui.setSparks(this.stars); ui.setEnergy(this.energy / this.maxEnergy);
    const chips = [];
    if (h.zap > 0) chips.push(`⚡ كهرباء ×${h.zap}`);
    if (h.shieldHits > 0) chips.push(`🛡 درع ×${h.shieldHits}`);
    if (h.speedT > 0) chips.push(`💨 سرعة ${Math.ceil(h.speedT)}`);
    if (h.jumpT > 0) chips.push(`⤴ قفز ${Math.ceil(h.jumpT)}`);
    if (h.fistT > 0) chips.push(`👊 قبضة ${Math.ceil(h.fistT)}`);
    if (this.def.door) chips.push(`🔑 ${this.keys.size}/${this.def.door.need}`);
    ui.setPowers(chips);
  }

  // ---------------------------------------------------------------- the frame
  ctxApi() {
    return {
      hero: this.player, world: this.world, fallY: this.def.fallY, arena: this.arena,
      sfx: (n) => this.sfx(n), shake: (a) => this.shake(a), burst: (x, y, n, o) => this.particles.burst(x, y, n, o),
      spawnProj: (o) => this.projs.push(new Proj(o)), hurtHero: (d, x) => this.hurtHero(d, x),
      onKill: (e) => this.onKill(e), spawnMinions: (b) => this.spawnMinions(b),
    };
  }

  update(dt) {
    const g = this.g, p = this.player, h = this.hero;
    this.t += dt;
    this.particles.update(dt);
    this.pops.forEach((q) => { q.life -= dt; q.y -= 30 * dt; }); this.pops = this.pops.filter((q) => q.life > 0);
    this.shakeT = Math.max(0, this.shakeT - dt); this.flashRed = Math.max(0, this.flashRed - dt);
    if (this.scene !== 'play') return;
    if (this.freeze) { this.camera(dt); return; }

    // timers & buffs
    for (const k of ['speedT', 'jumpT', 'fistT', 'shieldT']) if (h[k] > 0) { h[k] = Math.max(0, h[k] - dt); }
    if (h.shieldT === 0) h.shieldHits = 0;
    h.invuln = Math.max(0, h.invuln - dt); h.atkCd = Math.max(0, h.atkCd - dt); h.boltCd = Math.max(0, h.boltCd - dt);
    p.alpha = h.invuln > 0 ? (Math.floor(this.t * 14) % 2 ? 0.4 : 1) : 1;
    this.applyStats();
    this.regen += dt; if (this.regen > 1.6) { this.regen = 0; }
    if (Math.floor(this.t * 4) !== this._hudTick) { this._hudTick = Math.floor(this.t * 4); this.syncHud(); }

    this.updateDynamics(dt);
    p.update(dt, g.input, this.world);
    if (p.y > this.def.fallY) { this.energy = Math.max(this.maxEnergy * 0.1, this.energy - this.maxEnergy * 0.08); this.respawnAtCheckpoint(); this.pop(p.x, p.y - 250, 'حاول مرة أخرى!', '#ffd873', 1.6); this.syncHud(); }

    // actions
    const act = g.input.pressed('attack') || g.input.pressed('interact');
    const near = this.nearestInteract();
    this.near = near;
    if (act && h.atkCd === 0) {
      if (near && !this.enemyClose(300)) this.interact(near); else this.attack();
    }
    this.updateSwing(dt);

    // enemies, projectiles
    const api = this.ctxApi();
    for (const e of this.enemies) e.update(dt, api);
    this.enemies = this.enemies.filter((e) => !(e.dead && e.deadT > 0.7));
    this.updateProjs(dt, api);
    this.updateHazards(dt);
    this.updateEnemyContact();
    this.pickups();
    this.checkEvents();
    this.checkpoints();
    this.camera(dt);
    // prompt
    if (near && !this.freeze) {
      const sx = (near.x - this.camX) * Z, sy = (near.y - 190 - this.camY) * Z;
      const touch = document.body.classList.contains('is-touch');
      g.ui.setPrompt(`${near.label}${touch ? '' : '  (E)'}`, sx, sy);
    } else g.ui.setPrompt(null);
  }

  camera(dt) {
    const p = this.player, def = this.def;
    let tx = p.x - WVIEW * (p.facing > 0 ? 0.38 : 0.62);
    if (this.arena) { tx = clamp(tx, this.arena.x0 - 60, this.arena.x1 + 60 - WVIEW); }
    tx = clamp(tx, 0, def.width - WVIEW);
    const ty = p.y - HVIEW * 0.62;
    const k = 1 - Math.pow(0.0004, dt);
    this.camX = lerp(this.camX, tx, k); this.camY = lerp(this.camY, ty, 1 - Math.pow(0.002, dt));
  }

  updateDynamics(dt) {
    const p = this.player, w = this.world;
    for (const m of this.movers) {
      const o = m.o, px = o.x, py = o.y;
      const s = Math.sin(this.t * m.speed + m.ph) * m.range;
      if (m.axis === 'x') o.x = m.bx + s; else o.y = m.by + s;
      const dx = o.x - px, dy = o.y - py;
      const onTop = p.onGround && Math.abs(p.y - py) < 6 && p.x > px - 10 && p.x < px + o.w + 10;
      if (onTop) { p.x += dx; p.y += dy; }
    }
    for (const c of this.crumbles) {
      const o = c.o;
      if (c.state === 'idle') {
        const onTop = p.onGround && Math.abs(p.y - o.y) < 6 && p.x > o.x - 10 && p.x < o.x + o.w + 10;
        if (onTop) { c.state = 'shake'; c.timer = 0.55; this.sfx('crumble'); }
      } else if (c.state === 'shake') {
        c.timer -= dt; o.shake = Math.sin(this.t * 60) * 4;
        if (c.timer <= 0) { c.state = 'gone'; c.timer = 2.8; const i = w.solids.indexOf(o); if (i >= 0) w.solids.splice(i, 1); this.particles.burst(o.x + o.w / 2, o.y, 16, { color: '#c9a25a', speed: 240, life: 0.7, grav: 900 }); p.onGround = false; }
      } else {
        c.timer -= dt; if (c.timer <= 0) { c.state = 'idle'; o.shake = 0; w.solids.push(o); }
      }
    }
    if (this.doorSolid && this.props.find((q) => q.kind === 'door')?.open > 0.8 && w.solids.includes(this.doorSolid)) w.solids.splice(w.solids.indexOf(this.doorSolid), 1);
    for (const q of this.props) if (q.kind === 'door' && q.opening) q.open = Math.min(1, q.open + dt * 0.7);
    // falling rocks
    (this.def.rocks || []).forEach((r, i) => {
      this.rockT[i] = (this.rockT[i] || 0) + dt;
      if (this.rockT[i] >= r.period && Math.abs(r.x - p.x) < 900) {
        this.rockT[i] = 0; this.projs.push(new Proj({ kind: 'rock', x: r.x, y: 0, gy: r.ground || 1000, vx: 0, vy: 0, w: 70, h: 70, dmg: 10, life: 2.5, delay: 0.9 }));
      }
    });
    (this.def.fires || []).forEach((f, i) => { f.on = ((this.t + (f.phase || 0)) % f.period) > f.period - 1.2; });
  }

  nearestInteract() {
    const p = this.player; let best = null, bd = 150;
    for (const q of this.props) {
      let label = null;
      if (q.kind === 'chest' && !q.open) label = 'افتح الصندوق';
      else if (q.kind === 'crystal' && !q.done && !q.arena) label = 'المس البلورة';
      else if (q.kind === 'crystal' && q.arena && this.boss && this.boss.armor > 0 && q.cool <= 0) label = 'بلورة النور';
      else if (q.kind === 'terminal') label = q.done ? (this.hero.zap === 0 ? 'اشحن البرق' : null) : 'لوحة البرق';
      if (!label) continue;
      const d = Math.abs(q.x - p.x); if (d < bd && Math.abs(q.y - p.y) < 200) { best = { ...q, ref: q, label }; bd = d; }
    }
    return best;
  }

  enemyClose(r) { const p = this.player; return this.enemies.some((e) => !e.dead && !e.boss && Math.abs(e.x - p.x) < r && Math.abs(e.y - p.y) < 200); }

  async interact(near) {
    const q = near.ref, h = this.hero; h.atkCd = 0.5;
    if (q.kind === 'chest') {
      this.sfx('chest');
      if (q.cat) { const r = await this.ask(q.cat, { title: q.title, reward: `الجائزة: ${POWER_NAMES[q.reward]}` }); q.open = true; this.grantPower(q.reward, r.firstTry); }
      else if (q.reward) { q.open = true; this.grantPower(q.reward, true); }
      else { q.open = true; this.stars += q.n; this.pop(q.x, q.y - 160, `+${q.n} ⭐`, '#ffd873', 1.6); this.particles.burst(q.x, q.y - 60, 30, { color: '#ffd23a', speed: 380, life: 0.9 }); this.syncHud(); }
      this.sfx('collect');
    } else if (q.kind === 'terminal') {
      if (!q.done) { const r = await this.ask(q.cat, { title: q.title, reward: 'الجائزة: الضربة الكهربائية ⚡' }); q.done = true; this.grantPower(q.reward, r.firstTry); this.g.ui.setGoal('اضغط هجوم لإطلاق البرق على الروبوت!'); }
      else if (h.zap === 0) { h.zap = 3; this.sfx('power'); this.pop(q.x, q.y - 200, 'شحنة برق جديدة ⚡×3', '#7fe3ff', 1.6); this.syncHud(); }
    } else if (q.kind === 'crystal') {
      if (q.arena) { await this.askArenaCrystal(q); return; }
      const r = await this.ask(q.cat, { title: q.title, reward: `الجائزة: ${POWER_NAMES[q.reward]}` });
      q.done = true; this.grantPower(q.reward, r.firstTry);
      if (this.boss && this.boss.type === 'king' && this.boss.shieldLayers > 0) { this.boss.shieldLayers--; this.sfx('zap'); this.shake(8); this.pop(this.boss.x, this.boss.y - 330, 'انكسرت طبقة من درع الزعيم!', '#ffd873', 2); }
      this.saveRun();
    }
  }

  async askArenaCrystal(q) {
    const b = this.boss; if (!b || b.armor <= 0) return;
    const cats = ['math', 'logic', 'arabic', 'book', 'general', 'focus'];
    const cat = cats[(3 - b.armor + (this.wrongs % 2)) % cats.length];
    const r = await this.ask(cat, { title: 'بلورة النور', reward: 'تكسر درعاً من دروع الظلال!' });
    q.cool = r.firstTry ? 0.5 : 2.5;
    b.armor--; b.flash = 0.3; this.sfx('zap'); this.shake(12);
    this.particles.burst(b.x, b.y - 200, 40, { color: '#d9a7ff', speed: 520, life: 0.8 });
    this.pop(b.x, b.y - 380, b.armor > 0 ? `انكسر درع! بقي ${b.armor}` : 'انكسرت كل الدروع! اضربه الآن!', '#d9a7ff', 2.4);
    this.grantPower(['shield', 'fist', 'zap'][b.armor % 3], r.firstTry);
    if (b.armor === 0) this.g.ui.setGoal('وحش الظلال ضعيف الآن! اضربه بكل قوتك!');
  }

  // ---------------------------------------------------------------- combat
  attack() {
    const h = this.hero, p = this.player, perm = this.g.save.data.action.perm;
    const bossAlive = this.boss && !this.boss.dead;
    if (h.zap > 0 && bossAlive && this.boss.active) {
      if (h.boltCd > 0) return;
      h.zap--; h.boltCd = 0.45; h.atkCd = 0.4; p.playFx('throw', 0.3); this.sfx('zap');
      this.projs.push(new Proj({ kind: 'bolt', from: 'hero', x: p.x + p.facing * 70, y: p.y - 100, vx: p.facing * 1400, vy: 0, w: 120, h: 40, dmg: 2, life: 1.0 }));
      this.syncHud(); return;
    }
    h.atkCd = 0.34 - 0.03 * perm.power; h.swingT = 0.3; h.swingHit = new Set(); p.playFx('sword', 0.3); this.sfx('swing');
  }

  updateSwing(dt) {
    const h = this.hero, p = this.player;
    if (h.swingT <= 0) return;
    h.swingT -= dt;
    const el_ = 0.3 - h.swingT;
    if (el_ > 0.06 && el_ < 0.22) {
      const perm = this.g.save.data.action.perm, reach = 130 + 14 * perm.power + (h.fistT > 0 ? 40 : 0);
      const hb = { x: p.facing > 0 ? p.x : p.x - reach, y: p.y - 170, w: reach, h: 170 };
      const kind = h.fistT > 0 ? 'fist' : 'melee', dmg = h.fistT > 0 ? 2 : 1;
      const api = this.ctxApi();
      for (const e of this.enemies) {
        if (e.dead || h.swingHit.has(e) || !overlap(hb, e.hurtRect())) continue;
        h.swingHit.add(e); e.hit(dmg, kind, p.x, api);
      }
      for (const pr of this.projs) if (pr.kind === 'orb' && overlap(hb, pr.rect())) { pr.life = 0; this.particles.burst(pr.x, pr.y, 14, { color: '#d9a7ff', speed: 300, life: 0.4 }); }
    }
  }

  onKill(e) {
    this.kills++; this.sfx('collect');
    const n = e.boss ? 5 : 1; this.stars += n;
    this.pop(e.x, e.y - e.h - 20, `+${n} ⭐`, '#ffd873', 1.4);
    this.particles.burst(e.x, e.y - e.h / 2, e.boss ? 80 : 24, { color: '#ffd23a', speed: e.boss ? 700 : 420, life: 1.0 });
    if (e.boss) { this.bossDead = true; this.shake(20); this.sfx('boom'); this.onBossDead(e); }
    this.syncHud();
  }

  spawnMinions(b) {
    for (const d of [-1, 1]) { const m = new Enemy({ type: 'jumper', x: b.x + d * 300, y: b.y, chase: true }); this.enemies.push(m); }
    this.pop(b.x, b.y - 380, 'استدعى الوحش مساعدين!', '#d9a7ff', 2);
  }

  updateProjs(dt, api) {
    const p = this.player;
    for (const pr of this.projs) {
      pr.update(dt, api);
      if (pr.from === 'hero') {
        for (const e of this.enemies) if (!e.dead && !pr.hitDone && overlap(pr.rect(), e.hurtRect())) {
          pr.hitDone = true; pr.life = 0; e.hit(pr.dmg, 'zap', p.x, api);
        }
        if (Math.random() < 0.6) this.particles.burst(pr.x, pr.y - 20, 1, { color: '#9ff', speed: 80, life: 0.25, size: 5, grav: 0 });
      } else if (pr.kind === 'wave' || pr.kind === 'orb') {
        if (overlap(pr.rect(), p.rect())) { this.hurtHero(pr.dmg, pr.x); if (pr.kind === 'orb') pr.life = 0; }
      } else if ((pr.kind === 'missile' || pr.kind === 'rock') && pr.t > pr.delay && overlap(pr.rect(), p.rect())) { this.hurtHero(pr.dmg, pr.x); pr.life = 0; this.particles.burst(pr.x, pr.y, 18, { color: '#ffb13a', speed: 360, life: 0.5 }); }
    }
    this.projs = this.projs.filter((q) => q.life > 0);
  }

  updateEnemyContact() {
    const p = this.player;
    for (const e of this.enemies) {
      if (e.dead || e.boss) continue;
      if (overlap(e.hurtRect(), p.rect()) && e.stun === 0) this.hurtHero(e.dmg, e.x);
    }
  }

  updateHazards(dt) {
    const p = this.player, r = p.rect();
    for (const s of this.def.spikes || []) if (overlap({ x: s.x, y: s.y - 45, w: s.w, h: 45 }, r)) { this.hurtHero(10, s.x + s.w / 2); }
    for (const f of this.def.fires || []) if (f.on && overlap({ x: f.x - 26, y: f.y - 200, w: 52, h: 200 }, r)) this.hurtHero(10, f.x);
  }

  pickups() {
    const p = this.player, def = this.def;
    for (const s of def.stars) {
      if (this.collected.has(s.id)) continue;
      if (Math.hypot(s.x - p.x, s.y - (p.y - 90)) < 70) {
        this.collected.add(s.id); this.stars++; this.state.sparks.add(s.id); this.sfx('collect');
        this.particles.burst(s.x, s.y, 8, { color: '#ffd23a', speed: 240, life: 0.5 }); this.syncHud();
      }
    }
    for (const q of this.props) {
      if (q.kind === 'key' && q.id !== 'drop' && !q.got && Math.hypot(q.x - p.x, q.y - 80 - (p.y - 90)) < 90) {
        q.got = true; this.keys.add(q.id); this.sfx('key'); this.particles.burst(q.x, q.y - 80, 30, { color: '#ffd873', speed: 420, life: 0.9 });
        this.pop(q.x, q.y - 160, 'مفتاح سرّي!', '#ffd873', 1.6); this.syncHud(); this.saveRun();
      }
      if (q.kind === 'door' && !q.opening && this.keys.size >= q.need && Math.abs(q.x - p.x) < 260) {
        q.opening = true; this.sfx('door'); this.shake(8);
      } else if (q.kind === 'door' && !q.opening && Math.abs(q.x - p.x) < 260 && !q.warned) {
        q.warned = true; this.pop(q.x, q.y - 330, `الباب يحتاج ${q.need} مفاتيح (معك ${this.keys.size})`, '#ffd873', 2.4);
        setTimeout(() => { q.warned = false; }, 3500);
      }
      if (q.kind === 'crystal' && q.arena) q.cool = Math.max(0, q.cool - 0.016);
    }
    if (this.keyProp && !this.keyProp.got && Math.hypot(this.keyProp.x - p.x, this.keyProp.y - 80 - (p.y - 90)) < 100) { this.keyProp.got = true; this.finish(); }
  }

  checkpoints() {
    const p = this.player, cps = this.def.checkpoints;
    for (let i = cps.length - 1; i > this.cpIndex; i--) {
      if (p.x > cps[i].x && Math.abs(p.y - cps[i].y) < 300) { this.cpIndex = i; this.pop(p.x, p.y - 250, 'نقطة حفظ ✔', '#9dff9a', 1.4); this.sfx('ok'); this.saveRun(); break; }
    }
  }

  saveRun() {
    const A = this.g.save.data.action;
    A.run = { id: this.stageId, cp: this.cpIndex, stars: this.stars, collected: [...this.collected], keys: [...this.keys], done: this.props.filter((q) => q.done || q.open === true || q.got).map((q) => q.id).filter(Boolean) };
    this.g.save.commit();
  }

  async checkEvents() {
    const p = this.player;
    for (const ev of this.def.events) {
      if (this.fired.has(ev.id) || p.x < ev.x) continue;
      this.fired.add(ev.id);
      if (ev.id === 'alarm') await this.evAlarm(); else if (ev.id === 'chase') await this.evChase(); else if (ev.id === 'arena') await this.evArena();
    }
  }

  async evAlarm() {
    this.sfx('alarm'); await this.say(this.def.alarmLines);
    const p = this.player; ['runner', 'runner', 'jumper'].forEach((t, i) => this.enemies.push(new Enemy({ type: t, x: 90 + i * 70, y: 1000, chase: true })));
    this.g.ui.setGoal('اهرب من اللصوص! اضرب من يقترب بزر الهجوم.');
  }

  async evChase() {
    this.sfx('alarm'); await this.say(this.def.chaseLines);
    ['guard', 'runner'].forEach((t, i) => this.enemies.push(new Enemy({ type: t, x: 3480 + i * 60, y: 1000, chase: true })));
  }

  async evArena() {
    const def = this.def, A = (this.arena = { x0: def.boss.x0, x1: def.boss.x1 });
    this.world.solids.push({ x: A.x0 - 80, y: -600, w: 80, h: 2600, kind: 'wall', hidden: true }, { x: A.x1, y: -600, w: 80, h: 2600, kind: 'wall', hidden: true });
    await this.say(def.arenaLines);
    this.boss = new Enemy({ type: def.boss.type, x: def.boss.x, y: def.boss.y }); this.boss.active = true; this.boss.dir = -1;
    this.enemies.push(this.boss);
    this.g.ui.setGoal(def.id === 'a1' ? 'أجب عن سؤال لوحة البرق ثم اهزم الروبوت!' : def.id === 'a2' ? 'اجمع البلورات الثلاث لتكسر درع الزعيم!' : 'المس بلورة النور لتكسر دروع الوحش!');
  }

  async onBossDead(b) {
    this.freeze = true; await sleep(1500);
    if (this.def.keyDrop) {
      const k = this.def.keyDrop; this.keyProp = { kind: 'key', x: k.x, y: k.y, got: false, id: 'drop' }; this.props.push(this.keyProp);
      this.freeze = false; this.g.ui.setGoal(`خذ ${k.name}!`);
      await this.say(this.def.outro);
    } else { await this.say(this.def.outro); this.freeze = false; await this.finish(); }
  }

  // ---------------------------------------------------------------- finish
  async finish() {
    if (this.scene === 'end') return;
    const g = this.g, id = this.stageId, def = this.def, A = g.save.data.action;
    this.scene = 'end'; this.freeze = true; g.ui.setPrompt(null); g.audio.play('success');
    const frac = this.collected.size / def.stars.length;
    let rating = 1; if (frac >= 0.6) rating++; if (this.faints === 0 && this.wrongs <= 1) rating++;
    const st = (A.stages[id] ||= { done: false, stars: 0, best: 0 });
    const first = !st.done; st.done = true; st.stars = Math.max(st.stars, rating); st.best = Math.max(st.best, this.stars);
    A.run = null; g.save.data.xp += 100; g.save.commit();
    g.audio.music(false);
    const idx = STAGE_LIST.findIndex((s) => s.id === id), next = STAGE_LIST[idx + 1];
    const mk = (n) => el('div', { class: 'stars' }, [1, 2, 3].map((i) => el('span', { class: i <= n ? 'on' : '' }, '★')));
    const last = !next;
    g.ui.show(g.ui.panel(
      el('h1', {}, last ? 'انتصر مهدي!' : 'أحسنت يا مهدي!'), el('p', {}, `أنهيتَ «${def.short}»`), mk(rating),
      el('p', { class: 'sub' }, `النجوم المجموعة: ${this.stars} · اللصوص المهزومون: ${this.kills} · الأسئلة الصحيحة: ${A.correct}`),
      this.permGained.length ? el('p', {}, 'مهارات جديدة: ' + this.permGained.map((k) => PERM_NAMES[k]).join('، ')) : null,
      last ? el('p', {}, 'لكن خلف سرقة بلورات الطاقة عدوٌّ أخطر… تابع المغامرة في المراحل القادمة!') : (first ? el('p', {}, `فُتحت مرحلة جديدة: «${next.short}»`) : null),
      el('div', {},
        next ? el('button', { class: 'btn', onclick: () => g.startAction(next.id, false) }, 'المرحلة التالية') : null,
        el('button', { class: next ? 'btn ghost' : 'btn', onclick: () => g.openMap() }, 'خريطة المغامرة'),
        el('button', { class: 'btn ghost', onclick: () => g.startAction(id, false) }, 'العب مرة أخرى'))));
  }

  // ---------------------------------------------------------------- render
  render(ctx) {
    ctx.clearRect(0, 0, VW, VH);
    if (this.scene === 'none') { ctx.fillStyle = '#0b1230'; ctx.fillRect(0, 0, VW, VH); return; }
    const th = this.theme, t = this.t, cam = this.camX, p = this.player;
    const sh = this.shakeT > 0 ? (Math.random() - 0.5) * this.shakeA : 0;
    drawActionBackground(ctx, th, cam, this.camY, t);
    ctx.save(); ctx.translate(sh, sh * 0.6); ctx.scale(Z, Z); ctx.translate(0, -this.camY);
    for (const z of this.world.climb) this.drawClimb(ctx, z, cam, t);
    this.def.checkpoints.forEach((c, i) => R.drawCheckpoint(ctx, c, cam, t, i === this.cpIndex));
    for (const s of this.world.solids) if (!s.hidden) { if (s.shake) { ctx.save(); ctx.translate(s.shake, 0); drawActionSolid(ctx, th, s, cam); ctx.restore(); } else drawActionSolid(ctx, th, s, cam); }
    for (const s of this.def.spikes || []) drawProp(ctx, { kind: 'spikes', x: s.x, y: s.y, w: s.w }, cam, t);
    for (const f of this.def.fires || []) drawProp(ctx, { kind: 'fire', x: f.x, y: f.y, on: f.on }, cam, t);
    for (const q of this.props) drawProp(ctx, q, cam, t);
    for (const s of this.def.stars) if (!this.collected.has(s.id)) { const sx = s.x - cam; if (sx > -60 && sx < WVIEW + 60) drawStar(ctx, sx, s.y, 0.9, t); }
    for (const e of this.enemies) { if (e.type === 'robot') drawRobot(ctx, e, cam, t); else if (e.type === 'king') drawKing(ctx, e, cam, t); else if (e.type === 'beast') drawBeast(ctx, e, cam, t); else drawThief(ctx, e, cam, t); }
    p.draw(ctx, cam, 0);
    if (this.hero.shieldHits > 0) { ctx.strokeStyle = `rgba(157,255,154,${0.5 + 0.3 * Math.sin(t * 8)})`; ctx.lineWidth = 6; ctx.beginPath(); ctx.ellipse(p.x - cam, p.y - 90, 70, 110, 0, 0, 7); ctx.stroke(); }
    if (this.hero.fistT > 0) { ctx.fillStyle = 'rgba(255,170,80,.25)'; ctx.beginPath(); ctx.arc(p.x - cam + p.facing * 55, p.y - 85, 38, 0, 7); ctx.fill(); }
    if (this.hero.speedT > 0 && Math.abs(p.vx) > 100) { ctx.fillStyle = 'rgba(127,227,255,.25)'; for (let i = 1; i <= 3; i++) ctx.fillRect(p.x - cam - p.facing * i * 36 - 20, p.y - 150, 36, 140); }
    for (const pr of this.projs) this.drawProj(ctx, pr, cam, t);
    this.particles.draw(ctx, cam);
    ctx.textAlign = 'center'; ctx.font = '800 34px "Segoe UI",Tahoma,sans-serif'; ctx.direction = 'rtl';
    for (const q of this.pops) { ctx.globalAlpha = Math.min(1, q.life / (q.max * 0.5)); ctx.lineWidth = 6; ctx.strokeStyle = 'rgba(0,0,0,.7)'; ctx.strokeText(q.text, q.x - cam, q.y); ctx.fillStyle = q.color; ctx.fillText(q.text, q.x - cam, q.y); }
    ctx.globalAlpha = 1;
    ctx.restore();
    if (this.flashRed > 0) { const g = ctx.createRadialGradient(VW / 2, VH / 2, 400, VW / 2, VH / 2, 1100); g.addColorStop(0, 'rgba(255,0,40,0)'); g.addColorStop(1, `rgba(255,0,40,${this.flashRed})`); ctx.fillStyle = g; ctx.fillRect(0, 0, VW, VH); }
    this.drawBossBar(ctx);
  }

  drawClimb(ctx, z, camX, t) {
    const x = z.x - camX;
    ctx.fillStyle = 'rgba(40,60,40,.55)'; ctx.fillRect(x + 30, z.y, 50, z.h);
    ctx.strokeStyle = '#5da05a'; ctx.lineWidth = 6;
    for (let y = z.y; y < z.y + z.h; y += 46) { ctx.beginPath(); ctx.moveTo(x + 30, y); ctx.lineTo(x + 80, y + 24); ctx.stroke(); ctx.fillStyle = '#7fcf6a'; ctx.beginPath(); ctx.ellipse(x + 55, y + 12, 14, 7, 0.5, 0, 7); ctx.fill(); }
  }

  drawProj(ctx, pr, cam, t) {
    const sx = pr.x - cam;
    if (pr.kind === 'bolt') {
      ctx.save(); ctx.strokeStyle = '#bff'; ctx.shadowColor = '#7fe3ff'; ctx.shadowBlur = 24; ctx.lineWidth = 7; ctx.beginPath();
      const dir = Math.sign(pr.vx);
      ctx.moveTo(sx - dir * 130, pr.y - 20); for (let i = 0; i <= 8; i++) ctx.lineTo(sx - dir * 130 + dir * i * 20, pr.y - 20 + (i % 2 ? -22 : 22) * (i === 8 ? 0 : 1)); ctx.stroke(); ctx.restore();
    } else if (pr.kind === 'wave') {
      ctx.fillStyle = 'rgba(255,150,60,.85)'; ctx.beginPath(); ctx.moveTo(sx - pr.w / 2, pr.y); ctx.quadraticCurveTo(sx, pr.y - pr.h * 1.6, sx + pr.w / 2, pr.y); ctx.fill();
    } else if (pr.kind === 'orb') {
      const g = ctx.createRadialGradient(sx, pr.y - 36, 4, sx, pr.y - 36, 50); g.addColorStop(0, '#fff'); g.addColorStop(0.4, '#d96bff'); g.addColorStop(1, 'rgba(120,20,200,0)'); ctx.fillStyle = g; ctx.beginPath(); ctx.arc(sx, pr.y - 36, 50, 0, 7); ctx.fill();
    } else if (pr.kind === 'missile' || pr.kind === 'rock') {
      if (pr.t < pr.delay) { ctx.strokeStyle = `rgba(255,70,70,${0.4 + 0.4 * Math.sin(this.t * 18)})`; ctx.lineWidth = 6; ctx.beginPath(); ctx.ellipse(sx, pr.gy - 4, 70, 14, 0, 0, 7); ctx.stroke(); }
      else { ctx.fillStyle = pr.kind === 'rock' ? '#7a6a8a' : '#ff5d3a'; ctx.beginPath(); ctx.arc(sx, pr.y - 35, 38, 0, 7); ctx.fill(); ctx.fillStyle = 'rgba(255,200,80,.5)'; ctx.fillRect(sx - 14, pr.y - 140, 28, 100); }
    }
  }

  drawBossBar(ctx) {
    const b = this.boss; if (!b || b.dead || !b.active) return;
    const w = 760, x = (VW - w) / 2, y = 300;
    ctx.fillStyle = 'rgba(0,0,0,.6)'; ctx.beginPath(); ctx.roundRect(x - 6, y - 6, w + 12, 44, 14); ctx.fill();
    ctx.fillStyle = '#3a1020'; ctx.fillRect(x, y, w, 32);
    const g = ctx.createLinearGradient(x, 0, x + w, 0); g.addColorStop(0, '#ff5d6e'); g.addColorStop(1, '#ffb36b'); ctx.fillStyle = g; ctx.fillRect(x, y, w * Math.max(0, b.hp / b.maxHp), 32);
    ctx.font = '800 30px "Segoe UI",Tahoma,sans-serif'; ctx.textAlign = 'center'; ctx.direction = 'rtl'; ctx.fillStyle = '#fff'; ctx.strokeStyle = '#000'; ctx.lineWidth = 5;
    ctx.strokeText(b.name, VW / 2, y + 74); ctx.fillText(b.name, VW / 2, y + 74);
    const lay = b.type === 'king' ? b.shieldLayers : b.type === 'beast' ? b.armor : 0;
    if (lay > 0) { ctx.fillStyle = '#ffd873'; ctx.font = '800 28px sans-serif'; ctx.fillText('🛡'.repeat(lay), VW / 2, y + 112); }
  }
}
