import { el } from '../engine/util.js';
import { srcTag, shuffle, successPanel } from './common.js';

/** Single-choice challenge. Wrong answers never end the game: they give a progressive hint and allow another try. */
export function runChoose(game, ch) {
  const { save, audio, ui } = game;
  return new Promise((resolve) => {
    let wrong = 0;
    const hint = el('div', { class: 'hintbox' }, 'فكّر ثم اختر.');
    const opts = el('div', { class: 'opts' });
    const order = shuffle(ch.options.map((text, i) => ({ text, i })));
    order.forEach((o) => {
      const b = el('button', { class: 'opt', 'data-i': o.i }, o.text);
      b.onclick = () => {
        if (o.i === ch.answer) {
          save.attempt(ch.id, true); audio.play('ok'); b.classList.add('good');
          opts.querySelectorAll('button').forEach((x) => (x.disabled = true));
          setTimeout(() => successPanel(content, { explain: ch.explain, example: ch.example, done: () => { ui.hide(); resolve(true); } }), 700);
        } else {
          wrong++; save.attempt(ch.id, false); save.hint(ch.id);
          audio.play('wrong'); b.classList.add('bad'); b.disabled = true;
          hint.textContent = 'ليس بعد، جرّب مرة أخرى. ' + ch.hints[Math.min(wrong - 1, ch.hints.length - 1)];
        }
      };
      opts.append(b);
    });
    const close = el('button', { class: 'puz-x', 'aria-label': 'إغلاق', onclick: () => { ui.hide(); resolve(false); } }, '✕');
    const content = ui.panel(
      el('div', { class: 'puz-top' }, el('h2', {}, ch.title), close),
      srcTag(ch), el('p', {}, ch.prompt), opts, hint);
    ui.show(content);
  });
}
