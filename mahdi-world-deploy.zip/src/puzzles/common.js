import { el } from '../engine/util.js';

/** Source tag shown on every puzzle so test content is never mistaken for book content. */
export function srcTag(l) {
  if (!l || !l.reviewStatus || l.reviewStatus === 'placeholder-not-from-book') {
    return el('span', { class: 'tag warn' }, 'محتوى تجريبي — ليس من الكتاب');
  }
  const label = l.reviewStatus === 'approved' ? 'معتمد' : 'بانتظار المراجعة العلمية';
  return el('span', { class: 'tag book' }, `مبسّط من الكتاب ${l.pageRef || ''} — ${label}`);
}

export const shuffle = (a) => {
  const r = a.slice();
  for (let i = r.length - 1; i > 0; i--) { const j = Math.floor(Math.random() * (i + 1)); [r[i], r[j]] = [r[j], r[i]]; }
  return r;
};

/** Shared success panel: explanation + the key button. */
export function successPanel(content, { title = 'أحسنت يا مهدي!', explain, example, btn = 'خذ مفتاح المعرفة', done }) {
  content.replaceChildren(
    el('h2', {}, title),
    el('p', {}, explain),
    example ? el('p', { class: 'sub' }, example) : null,
    el('button', { class: 'btn', onclick: done }, btn),
  );
}
