import { el } from '../engine/util.js';
import { srcTag } from './common.js';

/** Card-sorting challenge: tap a card, then tap the box it belongs in. */
export function runClassify(game, lesson) {
  const { save, audio, ui } = game;
  return new Promise((resolve) => {
    let selected = null, wrong = 0, placed = 0;
    const total = lesson.cards.length;

    const hintBox = el('div', { class: 'hintbox' }, 'اختر بطاقة، ثم اختر المكان المناسب لها.');
    const cardsBox = el('div', { class: 'cards' });
    const bins = lesson.bins.map((b) => {
      const holder = el('div', {});
      const node = el('button', { class: 'bin', 'data-bin': b.id, onclick: () => drop(b.id, node, holder) },
        el('b', {}, b.label), el('small', {}, b.sub), holder);
      return { id: b.id, node, holder };
    });

    const order = lesson.cards.map((c, i) => ({ ...c, i })).sort(() => Math.random() - 0.5);
    order.forEach((c) => {
      const n = el('button', { class: 'card', 'data-i': c.i, onclick: () => select(c, n) }, c.text);
      c.node = n; cardsBox.append(n);
    });

    const close = el('button', { class: 'puz-x', 'aria-label': 'إغلاق', onclick: () => { ui.hide(); resolve(false); } }, '✕');
    const content = ui.panel(
      el('div', { class: 'puz-top' }, el('h2', {}, lesson.puzTitle || ('لغز التفكير: ' + lesson.lessonTitle)), close),
      srcTag(lesson),
      el('p', { class: 'sub' }, lesson.simpleExplanation),
      cardsBox,
      el('div', { class: 'bins', style: `grid-template-columns:repeat(${bins.length},1fr)` }, bins.map((b) => b.node)),
      hintBox,
    );
    ui.show(content);

    function select(c, n) {
      audio.play('tap');
      cardsBox.querySelectorAll('.card').forEach((x) => x.classList.remove('sel'));
      selected = { c, n }; n.classList.add('sel');
      bins.forEach((b) => b.node.classList.add('target'));
      hintBox.textContent = 'أين تضع هذه البطاقة؟';
    }

    function drop(binId, binNode, holder) {
      if (!selected) { hintBox.textContent = 'اختر بطاقة أولاً.'; return; }
      const { c, n } = selected;
      bins.forEach((b) => b.node.classList.remove('target', 'glow'));
      if (c.bin === binId) {
        if (placed + 1 === total) save.attempt(lesson.id, true); // "done" only when every card is sorted
        audio.play('ok');
        holder.append(el('span', { class: 'card' }, c.text));
        n.remove(); selected = null; placed++;
        hintBox.textContent = 'صحيح!';
        if (placed === total) finish();
      } else {
        wrong++;
        save.attempt(lesson.id, false); save.hint(lesson.id);
        audio.play('wrong');
        n.classList.remove('sel'); n.classList.add('shake'); setTimeout(() => n.classList.remove('shake'), 450);
        selected = null;
        hintBox.textContent = 'ليس بعد، جرّب مرة أخرى. ' + lesson.hints[Math.min(wrong - 1, lesson.hints.length - 1)];
        if (wrong >= 3) { // third hint: point to the right box when the card is tapped again
          bins.find((b) => b.id === c.bin)?.node.classList.add('glow');
        }
      }
    }

    function finish() {
      audio.play('success');
      content.replaceChildren(
        el('h2', {}, 'أحسنت يا مهدي!'),
        el('p', {}, lesson.answerExplanation),
        lesson.childExample ? el('p', { class: 'sub' }, lesson.childExample) : null,
        el('button', { class: 'btn', onclick: () => { ui.hide(); resolve(true); } }, 'خذ مفتاح المعرفة'),
      );
    }
  });
}
