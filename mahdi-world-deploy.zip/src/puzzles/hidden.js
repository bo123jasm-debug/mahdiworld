import { el } from '../engine/util.js';
import { srcTag, successPanel } from './common.js';

/**
 * Hidden-object scene. `ch.items` are the targets ({emoji,label,x,y} with x,y in %), `ch.decoys` are harmless extras.
 * A hint button makes one remaining target pulse. No timer, no penalty.
 */
export function runHidden(game, ch) {
  const { save, audio, ui } = game;
  return new Promise((resolve) => {
    let found = 0, hints = 0;
    const counter = el('b', {}, `0 من ${ch.items.length}`);
    const hint = el('div', { class: 'hintbox' }, ch.prompt);
    const list = el('div', { class: 'found' });
    const scene = el('div', { class: 'scene ' + (ch.scene || '') });
    const target = (it) => {
      const b = el('button', { class: 'hid', style: `left:${it.x}%;top:${it.y}%`, 'aria-label': 'شيء مخبأ', 'data-id': it.label }, it.emoji);
      b.onclick = () => {
        if (b.classList.contains('got')) return;
        b.classList.add('got'); found++; audio.play('collect');
        counter.textContent = `${found} من ${ch.items.length}`;
        list.append(el('span', { class: 'chip' }, `${it.emoji} ${it.label}`));
        hint.textContent = it.say || 'وجدتها!';
        if (found === ch.items.length) {
          save.attempt(ch.id, true); audio.play('success');
          setTimeout(() => successPanel(content, { explain: ch.explain, example: ch.example, done: () => { ui.hide(); resolve(true); } }), 900);
        }
      };
      return b;
    };
    const decoy = (it) => {
      const b = el('button', { class: 'hid decoy', style: `left:${it.x}%;top:${it.y}%`, 'aria-label': 'زينة' }, it.emoji);
      b.onclick = () => { audio.play('tap'); hint.textContent = it.say || 'هذه للزينة فقط. واصل البحث!'; };
      return b;
    };
    ch.decoys?.forEach((d) => scene.append(decoy(d)));
    ch.items.forEach((it) => scene.append(target(it)));
    const helpBtn = el('button', { class: 'btn ghost sm', onclick: () => {
      const left = [...scene.querySelectorAll('.hid:not(.decoy):not(.got)')];
      if (!left.length) return;
      hints++; save.hint(ch.id); audio.play('tap');
      const b = left[0]; b.classList.add('pulse'); setTimeout(() => b.classList.remove('pulse'), 2200);
      hint.textContent = ch.hints[Math.min(hints - 1, ch.hints.length - 1)];
    } }, 'ساعدني');
    const close = el('button', { class: 'puz-x', 'aria-label': 'إغلاق', onclick: () => { ui.hide(); resolve(false); } }, '✕');
    const content = ui.panel(
      el('div', { class: 'puz-top' }, el('h2', {}, ch.title), close),
      srcTag(ch), el('div', { class: 'sub' }, 'وجدتَ: ', counter, ' '), scene, list, hint, el('div', {}, helpBtn));
    ui.show(content);
  });
}
