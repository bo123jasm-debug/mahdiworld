import { el } from '../engine/util.js';
import { srcTag, shuffle, successPanel } from './common.js';

/** Put the steps in order: tap the step that comes next. `ch.items` is in the correct order. */
export function runOrder(game, ch) {
  const { save, audio, ui } = game;
  return new Promise((resolve) => {
    let next = 0, wrong = 0;
    const hint = el('div', { class: 'hintbox' }, 'اضغط الخطوة التي تأتي أولاً.');
    const slots = el('div', { class: 'slots' }, ch.items.map((_, i) => el('div', { class: 'slot' }, el('i', {}, String(i + 1)))));
    const pool = el('div', { class: 'cards' });
    let list = shuffle(ch.items.map((text, i) => ({ text, i })));
    if (list.every((x, k) => x.i === k)) list = list.reverse();
    list.forEach((o) => {
      const n = el('button', { class: 'card', 'data-i': o.i }, o.text);
      n.onclick = () => {
        if (o.i === next) {
          audio.play('ok');
          const slot = slots.children[next]; slot.classList.add('filled'); slot.append(el('span', {}, o.text));
          n.remove(); next++;
          hint.textContent = 'صحيح!';
          if (next === ch.items.length) {
            save.attempt(ch.id, true); audio.play('success');
            setTimeout(() => successPanel(content, { explain: ch.explain, example: ch.example, done: () => { ui.hide(); resolve(true); } }), 800);
          }
        } else {
          wrong++; save.attempt(ch.id, false); save.hint(ch.id);
          audio.play('wrong'); n.classList.add('shake'); setTimeout(() => n.classList.remove('shake'), 450);
          hint.textContent = 'ليست هذه الخطوة الآن. ' + ch.hints[Math.min(wrong - 1, ch.hints.length - 1)];
          if (wrong >= 3) pool.querySelector(`[data-i="${next}"]`)?.classList.add('sel');
        }
      };
      pool.append(n);
    });
    const close = el('button', { class: 'puz-x', 'aria-label': 'إغلاق', onclick: () => { ui.hide(); resolve(false); } }, '✕');
    const content = ui.panel(
      el('div', { class: 'puz-top' }, el('h2', {}, ch.title), close),
      srcTag(ch), el('p', { class: 'sub' }, ch.prompt), slots, pool, hint);
    ui.show(content);
  });
}
