import { el } from '../engine/util.js';
import { srcTag } from './common.js';

/** Interactive review. Wrong answers show a hint and allow retry; returns the number of mistakes. */
export function runReview(game, items, meta = null) {
  const { audio, ui } = game;
  return new Promise((resolve) => {
    let qi = 0, mistakes = 0;
    const box = ui.panel();
    ui.show(box);

    function render() {
      const q = items[qi];
      const hint = el('div', { class: 'hintbox' }, 'فكّر ثم اختر الإجابة.');
      const opts = el('div', { class: 'opts' });
      q.options.forEach((text, i) => {
        const b = el('button', { class: 'opt' }, text);
        b.onclick = () => {
          if (i === q.answer) {
            audio.play('ok'); b.classList.add('good');
            hint.textContent = q.explanation;
            opts.querySelectorAll('button').forEach((x) => (x.disabled = true));
            const next = el('button', { class: 'btn', onclick: () => { qi++; qi >= items.length ? resolve({ mistakes }) : render(); } },
              qi + 1 >= items.length ? 'انتهينا!' : 'السؤال التالي');
            box.append(next);
          } else {
            mistakes++; audio.play('wrong'); b.classList.add('bad');
            hint.textContent = 'جرّب مرة أخرى. ' + q.hint;
          }
        };
        opts.append(b);
      });
      box.replaceChildren(
        el('h2', {}, `${meta?.quizTitle || 'مراجعة سريعة'} (${qi + 1} من ${items.length})`),
        srcTag(meta),
        el('p', {}, q.question), opts, hint);
    }
    render();
  });
}
