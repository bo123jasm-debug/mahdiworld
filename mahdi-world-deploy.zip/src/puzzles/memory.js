import { el, sleep } from '../engine/util.js';
import { srcTag } from './common.js';

const SVG = {
  circle: '<circle cx="50" cy="50" r="34" fill="#7fd6ff"/>',
  triangle: '<polygon points="50,14 88,82 12,82" fill="#ffb86b"/>',
  square: '<rect x="18" y="18" width="64" height="64" rx="8" fill="#a9f08a"/>',
  star: '<polygon points="50,10 61,38 91,38 67,56 76,86 50,68 24,86 33,56 9,38 39,38" fill="#ffe27a"/>',
  moon: '<path d="M64 12 A40 40 0 1 0 64 88 A32 32 0 1 1 64 12Z" fill="#d8b4ff"/>',
  diamond: '<polygon points="50,8 90,50 50,92 10,50" fill="#ff8fb1"/>',
};
const icon = (k) => `<svg viewBox="0 0 100 100" aria-hidden="true">${SVG[k]}</svg>`;

/** Memory challenge: watch a sequence of symbols, then repeat it. Wrong answers give a hint and a replay. */
export async function runMemory(game, lesson) {
  const { save, audio, ui } = game;
  return new Promise((resolve) => {
    let closed = false, busy = false, misses = 0, hintIdx = 0, seq = [], pos = 0;
    const symbols = lesson.symbols;
    const names = lesson.symbolNames;

    const status = el('p', {}, 'شاهد الرموز بهدوء...');
    const hintBox = el('div', { class: 'hintbox' }, 'ركّز وانتبه للترتيب.');
    const dots = el('div', { class: 'seqdots' });
    const grid = el('div', { class: 'symgrid' });
    const cells = symbols.map((k, i) => {
      const b = el('button', { class: 'sym', 'aria-label': names[k], 'data-sym': k, html: icon(k) });
      b.onclick = () => tap(k, i, b);
      grid.append(b);
      return b;
    });
    const replay = el('button', { class: 'btn ghost', onclick: () => play() }, 'شاهد مرة أخرى');
    const close = el('button', { class: 'puz-x', 'aria-label': 'إغلاق', onclick: () => { closed = true; ui.hide(); resolve(false); } }, '✕');
    ui.show(ui.panel(
      el('div', { class: 'puz-top' }, el('h2', {}, 'لغز الذاكرة: ' + lesson.lessonTitle), close),
      srcTag(lesson),
      status, dots, grid, hintBox, el('div', {}, replay),
    ));

    const newSeq = () => {
      const len = misses >= 2 ? lesson.assistLengthAfterMisses : lesson.sequenceLength;
      const pool = symbols.slice();
      seq = [];
      for (let i = 0; i < len; i++) seq.push(pool.splice(Math.floor(Math.random() * pool.length), 1)[0]);
      dots.replaceChildren(...seq.map(() => el('i')));
    };

    async function play() {
      if (busy || closed) return;
      busy = true; pos = 0;
      [...dots.children].forEach((d) => d.classList.remove('on'));
      status.textContent = 'شاهد الرموز بهدوء...';
      cells.forEach((c) => (c.disabled = true));
      await sleep(500);
      const dur = misses >= 1 ? 1000 : 780;
      for (const k of seq) {
        if (closed) return;
        const i = symbols.indexOf(k);
        cells[i].classList.add('lit'); audio.play('sym' + i);
        await sleep(dur);
        cells[i].classList.remove('lit');
        await sleep(220);
      }
      if (closed) return;
      status.textContent = 'دورك! اضغط الرموز بالترتيب.';
      cells.forEach((c) => (c.disabled = false));
      busy = false;
    }

    async function tap(k, i, b) {
      if (busy || closed) return;
      audio.play('sym' + i);
      b.classList.add('lit'); setTimeout(() => b.classList.remove('lit'), 180);
      if (k === seq[pos]) {
        dots.children[pos]?.classList.add('on');
        pos++;
        if (pos === seq.length) {
          busy = true;
          save.attempt(lesson.id, true);
          audio.play('ok');
          status.textContent = 'أحسنت! تذكّرت الترتيب كاملاً.';
          hintBox.textContent = lesson.answerExplanation;
          await sleep(900);
          if (closed) return;
          ui.hide(); resolve(true);
        }
      } else {
        misses++;
        save.attempt(lesson.id, false);
        audio.play('wrong');
        b.classList.add('bad'); setTimeout(() => b.classList.remove('bad'), 400);
        save.hint(lesson.id);
        hintBox.textContent = 'لا بأس، جرّب مرة أخرى. ' + lesson.hints[Math.min(hintIdx, lesson.hints.length - 1)];
        hintIdx++;
        if (misses === 2) { hintBox.textContent += ' سنجعل اللغز أقصر قليلاً.'; newSeq(); }
        await play();
      }
    }

    newSeq();
    play();
  });
}
