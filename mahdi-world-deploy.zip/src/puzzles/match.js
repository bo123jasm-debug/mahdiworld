import { el } from '../engine/util.js';
import { srcTag, shuffle, successPanel } from './common.js';

/** Pair matching: tap an item on the right, then its partner on the left. */
export function runMatch(game, ch) {
  const { save, audio, ui } = game;
  return new Promise((resolve) => {
    let sel = null, done = 0, wrong = 0;
    const hint = el('div', { class: 'hintbox' }, 'اختر عنصراً ثم اختر ما يناسبه.');
    const mk = (side, text, i) => {
      const b = el('button', { class: 'mt ' + side, 'data-i': i, 'data-side': side }, text);
      b.onclick = () => tap(side, i, b);
      return b;
    };
    const L = shuffle(ch.pairs.map((p, i) => ({ t: p.l, i }))).map((o) => mk('l', o.t, o.i));
    const R = shuffle(ch.pairs.map((p, i) => ({ t: p.r, i }))).map((o) => mk('r', o.t, o.i));
    const cols = el('div', { class: 'match' }, el('div', { class: 'col' }, L), el('div', { class: 'col' }, R));

    function tap(side, i, b) {
      if (b.classList.contains('ok')) return;
      audio.play('tap');
      if (!sel || sel.side === side) {
        cols.querySelectorAll('.mt.sel').forEach((x) => x.classList.remove('sel'));
        sel = { side, i, b }; b.classList.add('sel'); return;
      }
      if (sel.i === i) {
        sel.b.classList.remove('sel'); sel.b.classList.add('ok'); b.classList.add('ok'); sel = null; done++;
        audio.play('ok'); hint.textContent = 'صحيح!';
        if (done === ch.pairs.length) {
          save.attempt(ch.id, true); audio.play('success');
          setTimeout(() => successPanel(content, { explain: ch.explain, example: ch.example, done: () => { ui.hide(); resolve(true); } }), 800);
        }
      } else {
        wrong++; save.attempt(ch.id, false); save.hint(ch.id); audio.play('wrong');
        const a = sel.b; a.classList.remove('sel'); a.classList.add('shake'); b.classList.add('shake');
        setTimeout(() => { a.classList.remove('shake'); b.classList.remove('shake'); }, 450);
        sel = null;
        hint.textContent = 'ليسا مناسبَين لبعضهما. ' + ch.hints[Math.min(wrong - 1, ch.hints.length - 1)];
      }
    }
    const close = el('button', { class: 'puz-x', 'aria-label': 'إغلاق', onclick: () => { ui.hide(); resolve(false); } }, '✕');
    const content = ui.panel(
      el('div', { class: 'puz-top' }, el('h2', {}, ch.title), close),
      srcTag(ch), el('p', { class: 'sub' }, ch.prompt), cols, hint);
    ui.show(content);
  });
}
