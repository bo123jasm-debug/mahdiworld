import { Input } from './engine/input.js';
import { AudioManager } from './engine/audio.js';
import { Save } from './engine/save.js';
import { loadAssets } from './engine/assets.js';
import { UI } from './ui/ui.js';
import { Stage1 } from './game/stage1.js';
import { LessonStage } from './game/lessonStage.js';
import { ActionStage } from './action/stage.js';
import { buildBank } from './action/mcq.js';
import { el } from './engine/util.js';

const canvas = document.getElementById('game');
const ctx = canvas.getContext('2d');

const game = {
  input: new Input(),
  save: new Save(),
  audio: null,
  ui: null,
  assets: null,
  curriculum: null,
  book: null, bookList: [], bookLessons: {}, bank: [], view: { w: 1080, h: 1920 },
  stage: null,
  mode: 'loading', // loading | title | play
  paused: false,
  muteBtn: document.getElementById('btn-mute'),
};
game.audio = new AudioManager(game.save);
game.ui = new UI(game);
window.__game = game; // handy for automated tests / debugging

if (new URLSearchParams(location.search).has('touch')) document.body.classList.add('force-touch');

game.setMuted = (m) => { game.audio.setMuted(m); game.refreshHud(); };
game.refreshHud = () => {
  if (game.stage === game.actionStage && game.actionStage?.scene !== 'none') game.actionStage.syncHud();
  else game.ui.setSparks(game.stage ? game.stage.state.sparks.size : 0);
  game.muteBtn.classList.toggle('off', game.audio.muted);
};
game.muteBtn.onclick = () => { game.audio.unlock(); game.setMuted(!game.audio.muted); };

game.toTitle = () => {
  game.mode = 'title'; game.paused = false;
  game.audio.music(false);
  game.ui.showHud(false);
  const A = game.save.data.action;
  game.ui.title({
    hasProgress: Object.keys(A.stages).length > 0 || !!A.run || !!game.save.data.stages.stage1 || Object.keys(game.save.data.lessons).length > 0,
    onStart: () => { game.audio.unlock(); game.startAction('a1', false); },
    onContinue: () => { game.audio.unlock(); game.openMap(); },
    onParent: () => game.openParent(() => game.toTitle()),
  });
};

game.startAction = async (id, resume) => {
  game.stage = game.actionStage; game.audio.unlock();
  game.mode = 'play'; game.paused = false; game.ui.hide();
  await game.stage.begin({ stageId: id, resume });
};

game.startStage = async ({ fresh }) => {
  game.stage = game.prologue; game.ui.setMode('lesson'); game.audio.music(false);
  game.mode = 'play'; game.paused = false;
  game.ui.hide();
  await game.stage.begin({ fresh });
};

// ---- book lessons: unlocked one after another (prologue → b1-1 → b1-2 ...)
game.lessonUnlocked = (id) => {
  const i = game.bookList.findIndex((l) => l.id === id);
  if (i < 0) return false;
  return i === 0 ? true : !!game.save.stage(game.bookList[i - 1].id).done;
};
game.startLesson = async (id) => {
  if (!game.lessonUnlocked(id)) return;
  game.stage = game.lessonStage;
  game.mode = 'play'; game.paused = false;
  game.ui.hide();
  await game.stage.begin({ lessonId: id });
};
game.openMap = () => {
  game.mode = 'title'; game.paused = false; game.ui.showHud(false);
  game.ui.stageMap(game, {
    onPrologue: () => { game.audio.unlock(); game.startStage({ fresh: false }); },
    onAction: (id, resume) => { game.audio.unlock(); game.startAction(id, resume); },
    onLesson: (id) => { game.audio.unlock(); game.startLesson(id); },
    onTitle: () => game.toTitle(),
  });
};

game.openParent = (back) => game.ui.parentPanel(game.save, game.curriculum, back);

game.openPause = () => {
  if (game.mode !== 'play' || game.stage.scene === 'end') return;
  game.paused = true;
  const resume = () => { game.paused = false; game.ui.hide(); };
  game.ui.pause({
    onResume: resume,
    onRestart: () => { game.paused = false; game.stage === game.actionStage ? game.startAction(game.actionStage.stageId, false) : game.stage === game.lessonStage ? game.startLesson(game.lessonStage.lesson.id) : game.startStage({ fresh: false }); },
    onMap: () => { game.openMap(); },
    onParent: () => game.openParent(() => game.openPause()),
    onTitle: () => { game.toTitle(); },
  });
};

// --------------------------------------------------------------------------------------------
let last = performance.now(), tickAcc = 0;
function frame(now) {
  const dt = Math.min(1 / 30, (now - last) / 1000);
  last = now;
  const input = game.input;

  if (input.rawPressed('pause') && game.mode === 'play') {
    if (game.paused) { game.paused = false; game.ui.hide(); } else if (!game.ui.isOpen) game.openPause();
  }

  if (game.mode === 'play' && !game.paused) {
    game.stage.update(dt);
    if (!game.ui.isOpen || game.stage.cine) { tickAcc += dt; }
    if (tickAcc >= 1) { game.save.tick(tickAcc); tickAcc = 0; game.save.commit(); }
    renderStage();
  } else if (game.mode === 'title' || game.mode === 'loading') {
    drawTitleBackdrop(now / 1000);
  } else if (game.mode === 'play' && game.paused) {
    renderStage();
  }
  input.endFrame();
  requestAnimationFrame(frame);
}

/** The old landscape prologue is letterboxed inside the portrait canvas; every other stage is natively vertical. */
function renderStage() {
  const ex = game.view.extra || 0;
  ctx.fillStyle = '#05081a'; ctx.fillRect(0, 0, 1080, 1920 + ex);
  ctx.save(); ctx.translate(0, ex);
  renderStage2();
  ctx.restore();
}

function renderStage2() {
  if (game.stage === game.prologue) {
    ctx.fillStyle = '#0b1230'; ctx.fillRect(0, 0, 1080, 1920);
    ctx.save(); ctx.translate(0, (1920 - 607.5) / 2); ctx.scale(0.5625, 0.5625); game.stage.render(ctx); ctx.restore();
  } else game.stage.render(ctx);
}

function drawTitleBackdrop(t) {
  const H = game.view.h;
  ctx.fillStyle = '#0b1230'; ctx.fillRect(0, 0, 1080, H);
  const img = game.assets?.title;
  if (img?.naturalWidth) {
    const s = Math.max(1080 / img.naturalWidth, H / img.naturalHeight) * 1.04;
    const w = img.naturalWidth * s, h = img.naturalHeight * s;
    ctx.drawImage(img, (1080 - w) / 2 + Math.sin(t * 0.2) * 14, (H - h) / 2, w, h);
  }
}

// --------------------------------------------------------------------------------------------
async function boot() {
  requestAnimationFrame(frame);
  const bar = el('div', { style: 'height:calc(var(--u)*1.4);background:rgba(255,255,255,.15);border-radius:99px;overflow:hidden;margin-top:calc(var(--u)*1.4)' },
    el('div', { id: 'bar', style: 'height:100%;width:0;background:#f2c04b;transition:width .15s' }));
  game.ui.show(game.ui.panel(el('h1', {}, 'عالم مهدي'), el('p', {}, 'جارٍ تجهيز المغامرة...'), bar));
  try {
    const [assets, curriculum, book, questions] = await Promise.all([
      loadAssets((p) => { const b = document.getElementById('bar'); if (b) b.style.width = Math.round(p * 100) + '%'; }),
      fetch('data/curriculum.json').then((r) => r.json()),
      fetch('data/book.json').then((r) => r.json()),
      fetch('data/questions.json').then((r) => r.json()),
    ]);
    game.assets = assets; game.curriculum = curriculum;
    game.book = book;
    game.bookList = book.units.flatMap((u) => u.lessons.map((l) => ({ ...l, unit: u.originalChapterTitle })));
    game.bookLessons = Object.fromEntries(game.bookList.map((l) => [l.id, l]));
    game.bank = buildBank(questions, game.bookList);
    game.prologue = new Stage1(game);
    game.actionStage = new ActionStage(game);
    game.lessonStage = new LessonStage(game);
    game.stage = game.prologue;
    game.refreshHud();
    game.ui.setKeys(0);
    game.toTitle();
  } catch (err) {
    console.error(err);
    game.ui.show(game.ui.panel(el('h1', {}, 'تعذّر التحميل'),
      el('p', {}, 'شغّل اللعبة من خادم ويب (وليس بفتح الملف مباشرة) ثم أعد المحاولة.'),
      el('button', { class: 'btn', onclick: () => location.reload() }, 'إعادة المحاولة')));
  }
}
boot();
