const KEYMAP = {
  ArrowLeft: 'left', KeyA: 'left',
  ArrowRight: 'right', KeyD: 'right',
  ArrowUp: 'up', KeyW: 'up',
  ArrowDown: 'down', KeyS: 'down',
  Space: 'jump',
  KeyE: 'interact', Enter: 'interact',
  KeyT: 'transform',
  KeyJ: 'attack', KeyK: 'attack', KeyF: 'attack',
  Escape: 'pause', KeyP: 'pause',
};

/** Keyboard + multi-touch input. Gameplay actions can be disabled while overlays are open. */
export class Input {
  constructor() {
    this.down = new Set();
    this.queue = new Set();
    this.enabled = true;
    this.virtual = new Map(); // pointerId -> action

    addEventListener('keydown', (e) => {
      const a = KEYMAP[e.code];
      if (!a) return;
      if (e.code === 'Space' || e.code.startsWith('Arrow')) e.preventDefault();
      if (!this.down.has(a)) this.queue.add(a);
      this.down.add(a);
    });
    addEventListener('keyup', (e) => {
      const a = KEYMAP[e.code];
      if (a) this.down.delete(a);
    });
    addEventListener('blur', () => this.clear());

    document.querySelectorAll('[data-act]').forEach((b) => {
      const act = b.dataset.act;
      const press = (e) => {
        e.preventDefault();
        try { b.setPointerCapture?.(e.pointerId); } catch (err) { /* pointer already gone */ }
        this.virtual.set(e.pointerId, act);
        if (!this.down.has(act)) this.queue.add(act);
        this.down.add(act);
        b.classList.add('active');
      };
      const release = (e) => {
        if (this.virtual.get(e.pointerId) !== act) return;
        this.virtual.delete(e.pointerId);
        if (![...this.virtual.values()].includes(act)) this.down.delete(act);
        b.classList.remove('active');
      };
      b.addEventListener('pointerdown', press);
      b.addEventListener('pointerup', release);
      b.addEventListener('pointercancel', release);
      b.addEventListener('lostpointercapture', release);
      b.addEventListener('contextmenu', (e) => e.preventDefault());
    });
  }
  clear() {
    this.down.clear(); this.queue.clear(); this.virtual.clear();
    document.querySelectorAll('[data-act].active').forEach((b) => b.classList.remove('active'));
  }
  held(a) { return this.enabled && this.down.has(a); }
  pressed(a) { return this.enabled && this.queue.has(a); }
  /** Always available, even when gameplay input is disabled (e.g. Esc to pause). */
  rawPressed(a) { return this.queue.has(a); }
  endFrame() { this.queue.clear(); }
}
