/**
 * Procedural sound effects (WebAudio). No audio files are shipped yet.
 * voice(id) is a hook: it will play assets/audio/voice/<id>.mp3 once recordings are added.
 */
export class AudioManager {
  constructor(save) {
    this.save = save;
    this.ctx = null;
    this.master = null;
    this.voiceCache = new Map();
  }
  get muted() { return !!this.save.data.muted; }
  setMuted(m) { this.save.data.muted = m; this.save.commit(); if (this.master) this.master.gain.value = m ? 0 : 0.9; }

  unlock() {
    if (!this.ctx) {
      try {
        this.ctx = new (window.AudioContext || window.webkitAudioContext)();
        this.master = this.ctx.createGain();
        this.master.gain.value = this.muted ? 0 : 0.9;
        this.master.connect(this.ctx.destination);
      } catch (e) { this.ctx = null; }
    }
    if (this.ctx && this.ctx.state === 'suspended') this.ctx.resume();
  }

  tone({ f = 440, f2 = null, t = 0.15, type = 'sine', vol = 0.12, delay = 0 }) {
    if (!this.ctx || this.muted) return;
    const c = this.ctx, now = c.currentTime + delay;
    const o = c.createOscillator(), g = c.createGain();
    o.type = type;
    o.frequency.setValueAtTime(f, now);
    if (f2) o.frequency.exponentialRampToValueAtTime(f2, now + t);
    g.gain.setValueAtTime(0.0001, now);
    g.gain.exponentialRampToValueAtTime(vol, now + 0.01);
    g.gain.exponentialRampToValueAtTime(0.0001, now + t);
    o.connect(g); g.connect(this.master);
    o.start(now); o.stop(now + t + 0.02);
  }

  noise({ t = 0.08, vol = 0.05, freq = 1200, delay = 0 }) {
    if (!this.ctx || this.muted) return;
    const c = this.ctx, now = c.currentTime + delay;
    const len = Math.max(1, Math.floor(c.sampleRate * t));
    const buf = c.createBuffer(1, len, c.sampleRate);
    const d = buf.getChannelData(0);
    for (let i = 0; i < len; i++) d[i] = (Math.random() * 2 - 1) * (1 - i / len);
    const s = c.createBufferSource(); s.buffer = buf;
    const flt = c.createBiquadFilter(); flt.type = 'bandpass'; flt.frequency.value = freq;
    const g = c.createGain(); g.gain.value = vol;
    s.connect(flt); flt.connect(g); g.connect(this.master);
    s.start(now);
  }

  play(name) {
    if (!this.ctx) return;
    switch (name) {
      case 'step': this.noise({ t: 0.05, vol: 0.035, freq: 700 + Math.random() * 300 }); break;
      case 'jump': this.tone({ f: 330, f2: 620, t: 0.16, type: 'triangle', vol: 0.1 }); break;
      case 'land': this.noise({ t: 0.09, vol: 0.06, freq: 300 }); break;
      case 'slide': this.noise({ t: 0.3, vol: 0.05, freq: 2000 }); break;
      case 'collect': this.tone({ f: 880, t: 0.1, vol: 0.09 }); this.tone({ f: 1320, t: 0.16, vol: 0.09, delay: 0.07 }); break;
      case 'key': [523, 659, 784, 1047].forEach((f, i) => this.tone({ f, t: 0.22, type: 'triangle', vol: 0.11, delay: i * 0.09 })); break;
      case 'transform':
        this.tone({ f: 180, f2: 1400, t: 1.6, type: 'sawtooth', vol: 0.05 });
        this.tone({ f: 360, f2: 2200, t: 1.8, type: 'sine', vol: 0.07, delay: 0.2 });
        this.noise({ t: 1.2, vol: 0.04, freq: 3000, delay: 1.4 });
        [880, 1175, 1568].forEach((f, i) => this.tone({ f, t: 0.5, vol: 0.08, delay: 2.4 + i * 0.1 }));
        break;
      case 'door': this.tone({ f: 90, f2: 55, t: 1.1, type: 'sawtooth', vol: 0.09 }); this.noise({ t: 1.0, vol: 0.05, freq: 250 }); break;
      case 'tap': this.tone({ f: 600, t: 0.06, vol: 0.06 }); break;
      case 'ok': this.tone({ f: 660, t: 0.12, vol: 0.09 }); this.tone({ f: 990, t: 0.2, vol: 0.09, delay: 0.1 }); break;
      case 'wrong': this.tone({ f: 260, f2: 200, t: 0.25, type: 'triangle', vol: 0.08 }); break;
      case 'success': [523, 659, 784, 1047, 1319].forEach((f, i) => this.tone({ f, t: 0.3, type: 'triangle', vol: 0.1, delay: i * 0.12 })); break;
      case 'sym0': case 'sym1': case 'sym2': case 'sym3': case 'sym4': case 'sym5':
        this.tone({ f: [392, 440, 494, 523, 587, 659][+name[3]], t: 0.28, vol: 0.12 }); break;
      case 'swing': this.noise({ t: 0.12, vol: 0.06, freq: 1800 }); this.tone({ f: 500, f2: 250, t: 0.1, type: 'sawtooth', vol: 0.05 }); break;
      case 'hit': this.noise({ t: 0.12, vol: 0.12, freq: 600 }); this.tone({ f: 180, f2: 90, t: 0.14, type: 'square', vol: 0.09 }); break;
      case 'zap': this.noise({ t: 0.3, vol: 0.09, freq: 3500 }); this.tone({ f: 1400, f2: 200, t: 0.3, type: 'sawtooth', vol: 0.08 }); break;
      case 'hurt': this.tone({ f: 300, f2: 120, t: 0.25, type: 'triangle', vol: 0.11 }); break;
      case 'power': [392, 523, 659, 784, 1047].forEach((f, i) => this.tone({ f, t: 0.18, type: 'square', vol: 0.06, delay: i * 0.06 })); break;
      case 'chest': this.tone({ f: 300, f2: 700, t: 0.2, type: 'triangle', vol: 0.1 }); this.tone({ f: 880, t: 0.2, vol: 0.09, delay: 0.15 }); break;
      case 'boom': this.noise({ t: 0.5, vol: 0.2, freq: 140 }); this.tone({ f: 80, f2: 40, t: 0.5, type: 'sawtooth', vol: 0.12 }); break;
      case 'alarm': for (let i = 0; i < 4; i++) this.tone({ f: i % 2 ? 620 : 880, t: 0.16, type: 'square', vol: 0.05, delay: i * 0.18 }); break;
      case 'enemy': this.tone({ f: 220, f2: 140, t: 0.12, type: 'sawtooth', vol: 0.06 }); break;
      case 'crumble': this.noise({ t: 0.4, vol: 0.1, freq: 250 }); break;
      default: break;
    }
  }

  /** Original adventure loop (generated, no copyrighted material). Respects mute. */
  music(on) {
    this.musicOn = on;
    if (!on) { clearInterval(this.musicTimer); this.musicTimer = null; return; }
    if (this.musicTimer) return;
    const bass = [110, 110, 131, 98], lead = [440, 523, 659, 523, 440, 392, 523, 587];
    let step = 0;
    this.musicTimer = setInterval(() => {
      if (!this.ctx || this.muted) return;
      const b = bass[Math.floor(step / 2) % 4];
      if (step % 2 === 0) this.tone({ f: b, t: 0.3, type: 'triangle', vol: 0.05 });
      this.tone({ f: lead[step % 8] * (Math.floor(step / 8) % 2 ? 1.25 : 1), t: 0.14, type: 'square', vol: 0.018 });
      step++;
    }, 190);
  }

  /** Optional Arabic narration. Silent no-op until real recordings exist. */
  voice(id) {
    if (this.muted) return;
    let a = this.voiceCache.get(id);
    if (a === undefined) {
      a = new Audio(`assets/audio/voice/${id}.mp3`);
      a.addEventListener('error', () => this.voiceCache.set(id, null));
      this.voiceCache.set(id, a);
    }
    if (a) a.play().catch(() => {});
  }
}
