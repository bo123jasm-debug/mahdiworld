const KEY = 'mahdi-world-v1';

const fresh = () => ({
  v: 1,
  muted: false,
  xp: 0,
  stars: 0,
  sparks: 0,
  badges: [],
  lessons: {},
  stages: {},
  playSeconds: 0,
  action: { stages: {}, perm: { speed: 0, power: 0, jump: 0, energy: 0, ninja: 0 }, correct: 0, wrong: 0, byCat: {} },
});

/** Progress lives only in this browser's localStorage. No data leaves the device. */
export class Save {
  constructor() {
    this.data = fresh();
    try {
      const raw = localStorage.getItem(KEY);
      if (raw) this.data = { ...fresh(), ...JSON.parse(raw) };
    } catch (e) { /* private mode etc. */ }
  }
  commit() {
    try { localStorage.setItem(KEY, JSON.stringify(this.data)); } catch (e) { /* ignore */ }
  }
  lesson(id) {
    return (this.data.lessons[id] ??= { done: false, attempts: 0, wrong: 0, hints: 0, firstTry: false });
  }
  attempt(id, ok) {
    const l = this.lesson(id);
    l.attempts++;
    if (!ok) l.wrong++;
    if (ok && !l.done) {
      l.done = true;
      l.firstTry = l.wrong === 0 && l.hints === 0;
    }
    this.commit();
  }
  hint(id) { this.lesson(id).hints++; this.commit(); }
  addXp(n) { this.data.xp += n; this.commit(); }
  addBadge(id) {
    if (this.data.badges.includes(id)) return false;
    this.data.badges.push(id); this.commit(); return true;
  }
  stage(id) { return (this.data.stages[id] ??= { done: false, stars: 0 }); }
  tick(sec) { this.data.playSeconds += sec; }
  reset() { this.data = fresh(); this.commit(); }
}
