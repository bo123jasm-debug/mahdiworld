/** Loads the per-frame character PNGs (sliced from the approved character sheet) and backdrops. */
export async function loadAssets(onProgress = () => {}) {
  const meta = await (await fetch('assets/sprites/frames.json')).json();
  const frames = {};
  const jobs = [];
  let done = 0;
  const total = Object.values(meta).reduce((a, b) => a + b, 0) + 2;
  const tick = () => onProgress(++done / total);

  for (const [name, n] of Object.entries(meta)) {
    frames[name] = [];
    for (let i = 0; i < n; i++) {
      const im = new Image();
      im.src = `assets/sprites/${name}_${i}.png`;
      frames[name].push(im);
      jobs.push(im.decode().then(tick, tick));
    }
  }
  const town = new Image();
  town.src = 'assets/bg/town_sunset.jpg';
  jobs.push(town.decode().then(tick, tick));
  const title = new Image();
  title.src = 'assets/bg/title_vertical.jpg';
  jobs.push(title.decode().then(tick, tick));
  await Promise.all(jobs);
  return { frames, town, title };
}
