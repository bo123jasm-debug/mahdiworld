import { el, sleep } from '../engine/util.js';
import { STAGE_LIST } from '../action/levels.js';
import { CAT_NAMES } from '../action/mcq.js';

const $ = (s) => document.querySelector(s);

/** DOM overlay helpers. Arabic text lives in the DOM (correct shaping, RTL, touch friendly). */
export class UI {
  constructor(game) {
    this.game = game;
    this.overlay = $('#overlay');
    this.stage = $('#stage');
    this.fadeEl = $('#fade');
    this.openCount = 0;
    this.fit();
    addEventListener('resize', () => this.fit());
    document.body.classList.toggle('is-touch', matchMedia('(pointer:coarse)').matches);
  }

  fit() {
    const w = this.stage.clientWidth, h = this.stage.clientHeight;
    this.stage.style.setProperty('--u', w / 55 + 'px');
    // logical canvas: 1080 wide, as tall as the screen needs (>=1920). Extra height is added above the 1080x1920 design frame.
    const v = this.game.view, H = Math.max(1920, Math.min(2500, Math.round(1080 * h / Math.max(1, w))));
    v.h = H; v.extra = H - 1920;
    const cv = document.getElementById('game'); if (cv && cv.height !== H) cv.height = H;
  }

  get isOpen() { return !this.overlay.hidden; }

  show(node, cls = '') {
    this.overlay.className = cls;
    this.overlay.replaceChildren(node);
    this.overlay.hidden = false;
    this.game.input.enabled = false;
    this.game.input.clear();
  }
  hide() {
    this.overlay.hidden = true; this.overlay.replaceChildren(); this.overlay.className = '';
    this.game.input.enabled = true;
    this.game.input.clear();
  }

  async fade(fn) {
    this.fadeEl.classList.add('on');
    await sleep(470);
    await fn?.();
    await sleep(80);
    this.fadeEl.classList.remove('on');
    await sleep(300);
  }

  // ---------------- HUD ----------------
  setMode(m) { $('#hud-sparks').classList.toggle('star', m === 'action'); $('#controls').classList.toggle('action', m === 'action'); $('#hud-keys').style.display = m === 'action' ? 'none' : ''; $('#hud-energy').hidden = m !== 'action'; $('#hud-powers').replaceChildren(); if (m !== 'action') $('#hud-stage').textContent = ''; }
  setEnergy(f) { $('#hud-energy-fill').style.width = Math.max(0, Math.min(1, f)) * 100 + '%'; }
  setStageName(t) { $('#hud-stage').textContent = t || ''; }
  setPowers(list) { $('#hud-powers').replaceChildren(...list.map((t) => el('span', { class: 'pw' }, t))); }
  showHud(on) {
    $('#hud').hidden = !on; $('#controls').hidden = !on;
    if (!on) $('#prompt').hidden = true;
  }
  setGoal(text) { $('#hud-goal').textContent = text || ''; }
  setKeys(n) {
    const box = $('#hud-keys');
    if (!box.childElementCount) {
      for (let i = 0; i < 3; i++) box.append(el('canvas', { class: 'key-ico', width: 64, height: 64 }));
      box.childNodes.forEach((c) => this.drawKeyIcon(c));
    }
    box.childNodes.forEach((c, i) => c.classList.toggle('on', i < n));
  }
  drawKeyIcon(c) {
    const g = c.getContext('2d'); g.translate(32, 32); g.rotate(-0.6);
    g.fillStyle = '#ffd873'; g.strokeStyle = '#8a5a10'; g.lineWidth = 3;
    g.beginPath(); g.arc(-14, 0, 11, 0, 7); g.fill(); g.stroke();
    g.fillRect(-4, -4, 32, 8); g.strokeRect(-4, -4, 32, 8); g.fillRect(16, 4, 5, 10); g.fillRect(24, 4, 5, 8);
  }
  setSparks(n) { $('#hud-sparks-n').textContent = n; }
  setPrompt(text, sx, sy) {
    const p = $('#prompt');
    if (!text) { p.hidden = true; return; }
    p.hidden = false; p.textContent = text;
    const v = this.game.view;
    if (this.game.stage === this.game.prologue && this.game.prologue) { sx = sx * 0.5625; sy = sy * 0.5625 + (1920 - 607.5) / 2; }
    p.style.left = (sx / v.w) * 100 + '%'; p.style.top = ((sy + v.extra) / v.h) * 100 + '%';
  }
  glowTransform(on) { $('#ctl-transform').classList.toggle('glow', on); }

  // ---------------- dialog ----------------
  dialog(who, lines) {
    return new Promise((resolve) => {
      let i = 0;
      const line = el('div', { class: 'line' });
      const more = el('div', { class: 'more' });
      const box = el('div', { class: 'dialog' }, who && el('span', { class: 'who' }, who), line, more);
      const next = () => {
        this.game.audio.play('tap');
        if (i >= lines.length) { cleanup(); this.hide(); resolve(); return; }
        line.textContent = lines[i];
        more.textContent = i === lines.length - 1 ? 'اضغط للمتابعة ◂' : 'اضغط للمتابعة ◂';
        i++;
      };
      const onKey = (e) => { if (['Space', 'Enter', 'KeyE'].includes(e.code)) { e.preventDefault(); next(); } };
      const cleanup = () => removeEventListener('keydown', onKey);
      box.addEventListener('pointerdown', next);
      addEventListener('keydown', onKey);
      this.show(box, 'clear');
      next();
    });
  }

  // ---------------- generic panel ----------------
  panel(...kids) { return el('div', { class: 'panel' }, ...kids); }

  // ---------------- title ----------------
  title({ hasProgress, onStart, onContinue, onParent }) {
    const box = el('div', { class: 'title-box' },
      el('div', { class: 'logo' }, 'عالم مهدي'),
      el('div', { class: 'logo2' }, 'مغامرات المعرفة'),
      el('div', {},
        hasProgress && el('button', { class: 'btn', onclick: onContinue }, 'تابع المغامرة'),
        el('button', { class: hasProgress ? 'btn ghost' : 'btn', onclick: onStart }, hasProgress ? 'مغامرة جديدة' : 'ابدأ المغامرة'),
      ),
      el('div', {}, el('button', { class: 'btn ghost', onclick: onParent }, 'لوحة الوالدين')),
      el('div', { class: 'sm' }, 'نسخة اختبارية — لعبة أكشن تعليمية بثلاث مراحل'),
    );
    this.show(box, 'title');
  }

  // ---------------- pause ----------------
  pause({ onResume, onRestart, onParent, onTitle, onMap }) {
    const m = this.game.audio.muted;
    const muteBtn = el('button', { class: 'btn ghost' }, m ? 'تشغيل الصوت' : 'إيقاف الصوت');
    muteBtn.onclick = () => { this.game.setMuted(!this.game.audio.muted); muteBtn.textContent = this.game.audio.muted ? 'تشغيل الصوت' : 'إيقاف الصوت'; };
    this.show(this.panel(
      el('h1', {}, 'استراحة قصيرة'),
      el('p', { class: 'sub' }, 'تقدّمك يُحفظ تلقائياً في هذا المتصفح.'),
      el('div', {},
        el('button', { class: 'btn', onclick: onResume }, 'متابعة اللعب'),
        muteBtn,
      ),
      el('div', {},
        el('button', { class: 'btn ghost', onclick: onRestart }, 'إعادة المرحلة'),
        onMap && el('button', { class: 'btn ghost', onclick: onMap }, 'خريطة المغامرة'),
        el('button', { class: 'btn ghost', onclick: onParent }, 'لوحة الوالدين'),
        el('button', { class: 'btn ghost', onclick: onTitle }, 'القائمة الرئيسية'),
      ),
    ));
  }

  // ---------------- adventure map ----------------
  stageMap(game, { onPrologue, onLesson, onTitle, onAction }) {
    const save = game.save, book = game.book;
    const stars = (n) => '★'.repeat(n) + '☆'.repeat(3 - n);
    const A = save.data.action;
    const actionCards = STAGE_LIST.map((sg, i) => {
      const st = A.stages[sg.id], unlocked = i === 0 || A.stages[STAGE_LIST[i - 1].id]?.done, run = A.run?.id === sg.id;
      return el('div', {},
        el('button', { class: 'stagecard' + (st?.done ? ' done' : ''), disabled: !unlocked, 'data-stage': sg.id, onclick: () => onAction(sg.id, run) },
          el('span', {}, sg.name.replace(/^المرحلة \d: /, ''), el('small', {}, run ? 'تابع من نقطة الحفظ' : sg.mission)),
          el('span', { class: 'st' }, st?.done ? stars(st.stars) : unlocked ? '▶' : '🔒')),
        run ? el('button', { class: 'btn ghost sm', onclick: () => onAction(sg.id, false) }, 'ابدأ المرحلة من جديد') : null);
    });
    const pro = save.stage('stage1');
    const prologue = el('div', { class: 'map-unit' },
      el('h3', {}, 'التمهيد: سر المكتبة القديمة ', el('small', {}, '(نسخة قديمة أفقية، اختيارية)')),
      el('div', { class: 'lessons' }, el('button', { class: 'lbtn' + (pro.done ? ' done' : ''), onclick: onPrologue },
        el('span', {}, pro.done ? 'العب التمهيد مرة أخرى' : 'ابدأ هنا'), el('span', { class: 'st' }, pro.done ? stars(pro.stars) : '▶'))));
    const units = book.units.map((u) => el('div', { class: 'map-unit' },
      el('h3', {}, u.originalChapterTitle, ' ', el('small', {}, `(كتاب «بداية المعرفة» ص ${u.pages})`)),
      el('div', { class: 'lessons' }, u.lessons.map((l) => {
        const ok = game.lessonUnlocked(l.id), st = save.stage(l.id);
        return el('button', { class: 'lbtn' + (st.done ? ' done' : ''), disabled: !ok, 'data-lesson': l.id, onclick: () => onLesson(l.id) },
          el('span', {}, l.lessonTitle), el('span', { class: 'st' }, st.done ? stars(st.stars) : ok ? '▶' : '🔒'));
      }))));
    const soon = book.roadmap.filter((r) => r.status !== 'playable').map((r) => el('span', { class: 'chip' },
      `${r.unit} (ص ${r.pages}) — ${r.status === 'deferred' ? 'يحتاج مراجعة قبل البناء' : 'قريباً'}`));
    this.show(this.panel(
      el('div', { class: 'puz-top' }, el('h1', {}, 'خريطة المغامرة'), el('button', { class: 'puz-x', onclick: onTitle, 'aria-label': 'رجوع' }, '✕')),
      el('div', { class: 'map-unit' }, el('h3', {}, 'المغامرة الكبرى ', el('small', {}, '(أكشن + أسئلة)')), actionCards),
      el('p', { class: 'sub' }, 'دروس الكتاب: أكمل كل درس لتفتح الدرس الذي بعده.'),
      units, prologue,
      el('div', { class: 'map-unit soon' }, el('h3', {}, 'قادم قريباً'), el('div', { class: 'chips' }, soon)),
    ));
  }

  // ---------------- parent panel ----------------
  parentPanel(save, curriculum, onClose) {
    const rows = curriculum.lessons.map((l) => {
      const s = save.data.lessons[l.id];
      const mastered = s?.done && s.firstTry;
      const review = s && (s.wrong >= 2 || s.hints >= 2 || (s.attempts && !s.done));
      return el('tr', {},
        el('td', {}, l.lessonTitle),
        el('td', {}, s?.done ? 'مكتمل' : 'لم يبدأ'),
        el('td', {}, String(s?.attempts ?? 0)),
        el('td', { class: mastered ? 'good-t' : review ? 'warn-t' : '' }, mastered ? 'أتقنه' : review ? 'يحتاج مراجعة' : s?.done ? 'جيد' : '—'),
        el('td', {}, l.reviewStatus === 'placeholder-not-from-book' ? 'تجريبي' : l.reviewStatus),
      );
    });
    const REV = { 'extracted-pending-review': 'من الكتاب — بانتظار المراجعة', approved: 'معتمد', 'placeholder-not-from-book': 'تجريبي' };
    const bookRows = (this.game.bookList || []).map((l) => {
      const st = save.data.stages[l.id];
      let attempts = 0, wrong = 0, hints = 0;
      for (const [k, v] of Object.entries(save.data.lessons)) if (k.startsWith(l.id + ':')) { attempts += v.attempts; wrong += v.wrong; hints += v.hints; }
      const review = wrong >= 3 || hints >= 3;
      return el('tr', {},
        el('td', {}, l.lessonTitle), el('td', {}, st?.done ? `مكتمل ${'★'.repeat(st.stars)}` : 'لم يكتمل'),
        el('td', {}, String(attempts)), el('td', { class: review ? 'warn-t' : st?.done ? 'good-t' : '' }, review ? 'يحتاج مراجعة' : st?.done ? 'جيد' : '—'),
        el('td', {}, `${REV[l.reviewStatus] || l.reviewStatus} · ص ${l.pageRef}`));
    });
    const mins = Math.max(0, Math.round(save.data.playSeconds / 60));
    const st = save.data.stages['stage1'];
    const confirmReset = el('button', { class: 'btn danger', onclick: () => {
      if (confirm('هل تريد حذف كل تقدّم اللعبة في هذا المتصفح؟')) { save.reset(); this.game.refreshHud(); onClose(); }
    } }, 'حذف التقدّم');
    this.show(this.panel(
      el('div', { class: 'puz-top' }, el('h1', {}, 'لوحة الوالدين'), el('button', { class: 'puz-x', onclick: onClose, 'aria-label': 'إغلاق' }, '✕')),
      el('p', { class: 'sub' }, 'لا تُجمع أسماء ولا بيانات شخصية، ولا يُرسل شيء خارج هذا الجهاز. التقدم محفوظ في المتصفح فقط، وحذف بيانات المتصفح قد يمسحه.'),
      el('p', {}, `وقت اللعب التقريبي: ${mins} دقيقة · نقاط الخبرة: ${save.data.xp} · النجوم: ${save.data.stars}`),
      el('p', {}, st?.done ? 'المرحلة الأولى: مكتملة' : 'المرحلة الأولى: قيد التقدم'),
      el('table', { class: 'stats' },
        el('thead', {}, el('tr', {}, ...['الدرس', 'الحالة', 'المحاولات', 'التقييم', 'نوع المحتوى'].map((h) => el('th', {}, h)))),
        el('tbody', {}, rows)),
      el('h3', {}, 'لعبة الأكشن'),
      el('p', {}, `الأسئلة الصحيحة: ${save.data.action.correct} · الأخطاء: ${save.data.action.wrong} · المراحل المكتملة: ${Object.values(save.data.action.stages).filter((x) => x.done).length} من ${STAGE_LIST.length}`),
      el('table', { class: 'stats' }, el('thead', {}, el('tr', {}, ...['المجال', 'صحيحة', 'خاطئة', 'التقييم'].map((h) => el('th', {}, h)))),
        el('tbody', {}, Object.entries(CAT_NAMES).map(([k, v]) => { const c = save.data.action.byCat[k] || { right: 0, wrong: 0 }; const weak = c.wrong >= 3 && c.wrong > c.right; return el('tr', {}, el('td', {}, v), el('td', {}, String(c.right)), el('td', {}, String(c.wrong)), el('td', { class: weak ? 'warn-t' : c.right ? 'good-t' : '' }, weak ? 'يحتاج مراجعة' : c.right ? 'جيد' : '—')); }))),
      bookRows.length ? el('h3', {}, 'دروس الكتاب') : null,
      bookRows.length ? el('table', { class: 'stats' },
        el('thead', {}, el('tr', {}, ...['الدرس', 'الحالة', 'المحاولات', 'التقييم', 'المصدر والمراجعة'].map((h) => el('th', {}, h)))),
        el('tbody', {}, bookRows)) : null,
      el('p', { class: 'sub' }, 'درس التمهيد تجريبي وليس من نص الكتاب. دروس الكتاب مبسّطة منه مع رقم الصفحة، وتنتظر مراجعة علمية وتربوية قبل اعتمادها.'),
      el('div', {}, el('button', { class: 'btn', onclick: onClose }, 'رجوع'), confirmReset),
    ));
  }
}
